# MG-ETS Grade Dispatch & Pricing

电热联合系统热能分品级调度及定价方法 —— 算例数据与程序代码

Code and case data for the paper **"Multi-Grade Heat Energy Dispatch and Pricing Method for Integrated Electricity-Heat Systems"** (电热联合系统热能分品级调度及定价方法).

## 内容 / Contents

| 目录 | 说明 |
|---|---|
| [`matlab/`](matlab/) | 参考实现：YALMIP + Gurobi，对应论文第4节及附录B、C的全部算例 |
| [`python/`](python/) | 同一模型的 Python 实现（SCIP 求解 MIQP，HiGHS 求固定整数后的对偶价格），用于交叉核对与出图 |

两个目录各自带一份相同的算例数据 `case_14bus_6heat.xlsx`（IEEE 14 节点电网 + 16 节点居民供热管网，2 台多品级电蓄热装置），可以分别单独运行。

模型要点：
- 按温度将热负荷划分为发电级、工业级、建筑级；
- 电蓄热可供热品级随储热能量状态分段变化，经 Big-M 线性化纳入电热协同调度（MIQP）；
- 固定整数变量后求解连续子问题，以对偶变量作为分品级热价与节点电价；
- 目标函数计入单位弃电成本 `c_curt`（模板 Meta 表，373.1 元/MWh）。

## 快速开始 / Quick start

MATLAB（需 YALMIP 与 Gurobi，建议 R2020a 及以上）：
```matlab
cd matlab
main        % 论文4.1节基准日调度与定价 -> mat_results/results.mat
run_all     % 论文4.4~4.6节及附录B、C全部算例，约 2~3 h
```

Python（3.9+）：
```bash
cd python
pip install -r requirements.txt
python run_jobs.py case_14bus_6heat.xlsx runs_a.pkl paper degr winter summer
python run_jobs.py case_14bus_6heat.xlsx runs_b.pkl spring autumn
python fig_seasons.py case_14bus_6heat.xlsx figs runs_a.pkl runs_b.pkl
```

详见各子目录 README。

## 引用 / Citation

如使用本仓库的代码或数据，请引用：

> 张峻溥，仪忠凯，徐英，涂正宏，张弘鹏，李宝聚. 电热联合系统热能分品级调度及定价方法[J]. （期刊信息待补充）

> ZHANG Junpu, YI Zhongkai, XU Ying, TU Zhenghong, ZHANG Hongpeng, LI Baoju. Multi-Grade Heat Energy Dispatch and Pricing Method for Integrated Electricity-Heat Systems[J]. (journal info TBD)

## 许可 / License

[MIT](LICENSE)
