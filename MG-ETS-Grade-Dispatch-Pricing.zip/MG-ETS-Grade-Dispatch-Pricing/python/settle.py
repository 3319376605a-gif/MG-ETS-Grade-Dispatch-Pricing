"""Port of settlement_accounts.m: per-actor revenue / cost / net profit (元) for one dispatch result.
r needs the dispatch arrays plus prices pi_bus (NB,T), pi_tu (J,T), pi_in (K,T), pi_node (Nheat,T)."""
import numpy as np


def settle(r, d):
    dt = d['dt']
    pb, ptu, pin = r['pi_bus'], r['pi_tu'], np.nan_to_num(r['pi_in'])
    pn = np.nan_to_num(r['pi_node'])
    bus = lambda b: pb[int(b) - 1]
    node = lambda n: pn[int(n) - 1]
    a = {}
    a['Grid'] = (np.dot(d['price_buy'], r['Pbuy']) - np.dot(d['price_sell'], r['Psell'])) * dt
    a['ConvGen'] = sum((bus(d['busG'][g]) * r['Pg'][g]).sum() - (d['a_g'][g] * r['Pg'][g] + d['a2_g'][g] * r['Pg'][g] ** 2).sum()
                       for g in range(d['G'])) * dt
    a['RE'] = sum((bus(d['busG_N'][g]) * r['Pn'][g]).sum() - d['a_n'][g] * r['Pn'][g].sum() for g in range(d['G_N'])) * dt
    chp = 0.0
    for j in range(d['J']):
        Qc = r['Qtu_c'][j]
        chp += ((bus(d['busTu'][j]) * r['Ptu'][j]).sum() + (node(d['nTu'][j]) * r['Qtu_h'][j]).sum()
                - (d['CHP_a'][j] * Qc ** 2 + d['CHP_b'][j] * Qc).sum() - (ptu[j] * r['Qtu_r'][j]).sum())
    a['CHP'] = chp * dt
    ets = ets_rev = ets_pay = 0.0
    for i in range(d['I']):
        pay = (bus(d['busES'][i]) * r['Pes'][i]).sum()
        rev = (ptu * r['Q_i2j'][i]).sum() + (pin * r['Q_i2k'][i]).sum() + (node(d['nI'][i]) * r['Q_i2n'][i]).sum()
        om = (d['gamma_tu'][i] * r['Q_i2j'][i].sum() + d['gamma_in'][i] * r['Q_i2k'][i].sum()
              + d['gamma_re'][i] * r['Q_i2n'][i].sum())
        ets += rev - pay - om; ets_rev += rev; ets_pay += pay
    a['ETS'] = ets * dt; a['ETS_heat_rev'] = ets_rev * dt; a['ETS_elec_pay'] = ets_pay * dt
    a['ETS_degr'] = (ets_rev - ets_pay - ets) * dt
    a['BoInd'] = sum((pin * r['Q_s2k'][s]).sum() - (d['gamma_GB_ind'][s] * r['Qs'][s] + d['gamma_GB_ind_2'][s] * r['Qs'][s] ** 2).sum()
                     for s in range(d['S'])) * dt
    a['BoRes'] = sum((node(d['nW'][w]) * r['Qw'][w]).sum() - (d['gamma_GB_res'][w] * r['Qw'][w] + d['gamma_GB_res_2'][w] * r['Qw'][w] ** 2).sum()
                     for w in range(d['W'])) * dt
    a['IndPay'] = (pin * d['Qin_dem']).sum() * dt
    a['ResPay'] = sum((node(d['nM'][m]) * d['Qre_dem_m'][m]).sum() for m in range(len(d['nM']))) * dt
    return a


def mean_prices(r, d):
    """Load-weighted mean prices (元/MWh) by grade + mean nodal electricity price."""
    w = d['Qin_dem']
    tu_w = np.maximum(r['Qtu_r'] + r['Qtu_c'], 1e-9)
    res_nodes = np.asarray(d['nM']) - 1
    pn = r['pi_node'][res_nodes]
    return dict(Gen=float((r['pi_tu'] * tu_w).sum() / tu_w.sum()),
                Ind=float((r['pi_in'] * w).sum() / w.sum()),
                Bld=float((pn * d['Qre_dem_m']).sum() / d['Qre_dem_m'].sum()),
                Elec=float(np.mean(r['pi_bus'])),
                # same definition as price_mean_std in run_grade_comparison.m (paper Table 2)
                Gen_avg=float(np.mean(r['pi_tu'])), Ind_avg=float(np.mean(r['pi_in'])),
                Bld_avg=float(np.nanmean(r['pi_node'])))
