# Python 程序

与 `../matlab` 同一模型的 Python 实现：MIQP 用 SCIP（pyscipopt）求解，固定整数变量后的连续 QP 用 HiGHS 求解并取对偶作为价格。参考实现为 MATLAB/Gurobi 版本，本目录用于交叉核对与出图。

依赖（Python 3.9+）：
```bash
pip install -r requirements.txt
```

| 文件 | 作用 |
|---|---|
| `ets_model.py` | 读取算例数据、建模（含弃电成本 `c_curt`、可选周期性储能）、MIQP 求解、固定整数取对偶定价 |
| `seasons.py` / `run_cases.py` | 四季构造系数（论文表4）；无电蓄热与 7 种品级配置 |
| `run_jobs.py` | 批量求解（论文基准日 / 放热成本系数 / 四季），可断点续跑 |
| `settle.py` | 各主体结算，口径同 `settlement_accounts.m` |
| `lcc_season.py` | 全寿命周期核算（论文4.6节；年运行成本扣除放热成本项，设备费用只以投资 + 运维计入） |
| `fig_seasons.py` | 论文4.5、4.6节图（四季调度、成本与弃电、价格、各主体收益、全寿命周期） |
| `run_sens.py` | 关键参数敏感性分析（论文附录C 表C1、表C2），可断点续跑，输出 `summary.json` 与 `sens_tables.xlsx` |
| `fig_b1.py` | 论文附录B 图B1：四季典型日负荷与新能源可用出力曲线 |
| `compare_matlab.py` | 与 MATLAB `mat_results/` 逐工况对照 |
| `lcc_from_matlab.py` | 直接用 MATLAB 四季结果重算全寿命周期 |

```bash
X=case_14bus_6heat.xlsx
python run_jobs.py $X runs_a.pkl paper degr winter summer
python run_jobs.py $X runs_b.pkl spring autumn
python fig_seasons.py $X figs runs_a.pkl runs_b.pkl
python run_sens.py $X sens                 # 附录C，约 1~1.5 h
python fig_b1.py $X figs/figB1.png         # 附录B 图B1
python compare_matlab.py ../matlab/mat_results runs_a.pkl runs_b.pkl   # 需先运行 MATLAB run_all
```

说明：SCIP 与 Gurobi 的 MIP 间隙设置和退化对偶的选取可能不同，个别工况的价格可能与 MATLAB 结果有小幅差异，以 MATLAB 结果为准。
