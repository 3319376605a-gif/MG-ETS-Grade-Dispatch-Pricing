"""Key-parameter sensitivity analysis (paper Appendix C, Tables C1/C2). Resumable, 2 workers.
Paper base day (E0 fixed, curtailment cost included), three-grade case; one parameter changed at a time.
Usage: python run_sens.py <case.xlsx> <outdir>
Writes <outdir>/res/<case>.pkl, <outdir>/summary.json and <outdir>/sens_tables.xlsx (sheets C1, C2)."""
import sys, os, copy, pickle, time, json
import numpy as np
import pandas as pd
import ets_model as em, settle as st
from multiprocessing import Pool

C_CURT = 373.1
CASES = [('基准', 'base:1'),
         ('储热容量×0.6', 'cap:0.6'), ('储热容量×0.8', 'cap:0.8'), ('储热容量×1.2', 'cap:1.2'), ('储热容量×1.4', 'cap:1.4'),
         ('储热充电功率×0.6', 'pow:0.6'), ('储热充电功率×0.8', 'pow:0.8'), ('储热充电功率×1.2', 'pow:1.2'), ('储热充电功率×1.4', 'pow:1.4'),
         ('能量区阈值−20 MWh', 'thr:-20'), ('能量区阈值＋20 MWh', 'thr:20'),
         ('燃料成本×0.8', 'fuel:0.8'), ('燃料成本×0.9', 'fuel:0.9'), ('燃料成本×1.1', 'fuel:1.1'), ('燃料成本×1.2', 'fuel:1.2'),
         ('新能源出力×0.8', 'ren:0.8'), ('新能源出力×0.9', 'ren:0.9'), ('新能源出力×1.1', 'ren:1.1'), ('新能源出力×1.2', 'ren:1.2'),
         ('单位弃电成本0', 'curt:0'), ('单位弃电成本200', 'curt:200'), ('单位弃电成本500', 'curt:500'),
         ('Big-M=450', 'bigm:450')]
FUEL_KEYS = ['a_g', 'a2_g', 'CHP_b', 'CHP_a', 'gamma_GB_ind', 'gamma_GB_ind_2', 'gamma_GB_res', 'gamma_GB_res_2']


def case(base, name):
    kind, v = name.split(':'); v = float(v)
    d = copy.deepcopy(base)
    if kind == 'cap':     # storage capacity: limits, thresholds and E0 scaled together (same sensible-heat map)
        for k in ['Emax', 'Emin', 'EL', 'EH', 'E0']: d[k] = d[k] * v
    elif kind == 'pow':   # charging (electric input) power limit
        d['Pes_max'] = d['Pes_max'] * v
    elif kind == 'thr':   # low/high energy-region thresholds shifted (MWh)
        d['EL'] = d['EL'] + v; d['EH'] = d['EH'] + v
    elif kind == 'fuel':  # linear and quadratic fuel-cost coefficients of all coal-fired units/boilers
        for k in FUEL_KEYS: d[k] = d[k] * v
    elif kind == 'ren':
        d['Gen_New_P'] = d['Gen_New_P'] * v
    elif kind == 'curt':
        d['c_curt'] = v
    elif kind == 'bigm':
        d['BigM'] = v
    return d


def run(args):
    base, name, resdir = args
    f = os.path.join(resdir, name.replace(':', '_') + '.pkl')
    if os.path.exists(f): return name, 'cached'
    d = case(base, name); t0 = time.time()
    r = em.solve_priced(d, cyclic=False, time_limit=1800)
    s = dict(obj=r['obj'], gap=r['gap'], status=r['status'], obj_fixed=r['obj_fixed'],
             curt=float(d['Gen_New_P'].sum() - r['Pn'].sum()),
             P=float(r['Q_i2j'].sum()), I=float(r['Q_i2k'].sum()), B=float(r['Q_i2n'].sum()),
             E=r['E'], yL=r['yL'], yM=r['yM'], yH=r['yH'],
             pi_tu=r['pi_tu'], pi_in=r['pi_in'], pi_node=r['pi_node'], pi_bus=r['pi_bus'],
             mp=st.mean_prices(r, d), nM=np.asarray(d['nM']), secs=time.time() - t0)
    pickle.dump(s, open(f, 'wb'))
    return name, f"obj={r['obj'] / 1e4:.2f} gap={r['gap']:.1e} {time.time() - t0:.0f}s"


def summarize(resdir, outdir):
    R = {k: pickle.load(open(os.path.join(resdir, k.replace(':', '_') + '.pkl'), 'rb')) for _, k in CASES}
    b = R['base:1']; out = {}; t1 = []; t2 = []
    for lab, k in CASES:
        s = R[k]; mp = s['mp']
        nodes = np.unique(s['nM']) - 1
        pt, pin, pb = s['pi_tu'].mean(0), s['pi_in'].mean(0), np.nanmean(s['pi_node'][nodes], 0)
        lad = int(np.sum((pt >= pin - 1e-6) & (pin >= pb - 1e-6)))
        out[k] = dict(cost=s['obj'] / 1e4, dcost=100 * (s['obj'] / b['obj'] - 1), curt=s['curt'],
                      P=s['P'], I=s['I'], B=s['B'], gen=mp['Gen_avg'], ind=mp['Ind_avg'], bld=mp['Bld_avg'],
                      elec=mp['Elec'], ladder_hrs=lad, gap=s['gap'], Emin=float(s['E'].min()),
                      low_region_hrs=int(s['yL'].sum()))
        o = out[k]
        t1.append([lab, o['cost'], o['dcost'], o['curt'], o['P'], o['I'], o['B'], lad])
        t2.append([lab, o['gen'], o['ind'], o['bld'], o['elec']])
    json.dump(out, open(os.path.join(outdir, 'summary.json'), 'w'), ensure_ascii=False, indent=1, default=float)
    with pd.ExcelWriter(os.path.join(outdir, 'sens_tables.xlsx')) as w:
        pd.DataFrame(t1, columns=['工况', '总运行成本/万元', '变化率/%', '弃电量/MWh', '发电级放热/MWh',
                                  '工业级放热/MWh', '建筑级放热/MWh', '梯级成立时段数']).to_excel(w, sheet_name='C1', index=False)
        pd.DataFrame(t2, columns=['工况', '发电级', '工业级', '建筑级', '节点电价']).to_excel(w, sheet_name='C2', index=False)
    for row in t1: print(row)


if __name__ == '__main__':
    X, OUT = sys.argv[1], sys.argv[2]
    resdir = os.path.join(OUT, 'res'); os.makedirs(resdir, exist_ok=True)
    base = em.read_config(X); base['c_curt'] = C_CURT
    with Pool(2) as p:
        for n, msg in p.imap_unordered(run, [(base, k, resdir) for _, k in CASES]):
            print(n, msg, flush=True)
    summarize(resdir, OUT)
