"""Cross-check the MATLAB results (matlab/mat_results/) against the Python runs from run_jobs.py.
Usage: python compare_matlab.py <mat_results dir> runs_a.pkl runs_b.pkl"""
import sys, os, pickle
import numpy as np, scipy.io as sio

MR, paths = sys.argv[1], sys.argv[2:]
py = {}
for f in paths:
    py.update(pickle.load(open(f, 'rb')))


def ld(f, key=None):
    m = sio.loadmat(f, squeeze_me=True, struct_as_record=False)
    if key is None:
        key = [k for k in m if not k.startswith('__')][0]
    return m[key], m


def summ(R, avail=None):
    o = dict(obj=float(R.Objective) if hasattr(R, 'Objective') else float(R['obj']))
    get = (lambda k: np.asarray(getattr(R, k))) if hasattr(R, 'Objective') else (lambda k: np.asarray(R[k]))
    o['P'] = get('Q_i2j').sum(); o['I'] = get('Q_i2k').sum(); o['B'] = get('Q_i2n').sum()
    o['Pn'] = get('Pn').sum()
    if hasattr(R, 'HeatPrices'):
        o['Gen'] = np.mean(R.HeatPrices.pi_tu); o['Ind'] = np.mean(R.HeatPrices.pi_in)
        o['Bld'] = np.nanmean(R.HeatPrices.pi_node); o['El'] = np.mean(R.ElecPrices.pi_bus)
    elif 'pi_tu' in R:
        o['Gen'] = np.mean(R['pi_tu']); o['Ind'] = np.mean(R['pi_in'])
        o['Bld'] = np.nanmean(R['pi_node']); o['El'] = np.mean(R['pi_bus'])
    return o


def line(tag, m, p):
    d = 100 * (m['obj'] - p['obj']) / p['obj']
    s = f"{tag:20s} obj M={m['obj']/1e4:9.2f} P={p['obj']/1e4:9.2f} ({d:+.3f}%) | Pn M-P={m['Pn']-p['Pn']:+8.1f}"
    s += f" | P/I/B M-P = {m['P']-p['P']:+7.1f} {m['I']-p['I']:+7.1f} {m['B']-p['B']:+7.1f}"
    if 'Gen' in m and 'Gen' in p:
        s += f" | price M: {m['Gen']:7.2f} {m['Ind']:7.2f} {m['Bld']:7.2f} {m['El']:7.2f}" \
             f"  P: {p['Gen']:7.2f} {p['Ind']:7.2f} {p['Bld']:7.2f} {p['El']:7.2f}"
    print(s)


print('=== paper base day (curtailment cost) ===')
for n in ['PIB', 'IB', 'PB', 'PI', 'B', 'I', 'P']:
    R, _ = ld(os.path.join(MR, f'results_case_{n}.mat'))
    line(n, summ(R), summ(py[('paper', n)]))
for sc in ['standard', 'reuse']:
    for kind, mk in [('pool', 'rPool'), ('part', 'rPart')]:
        fn = os.path.join(MR, f'results_{"pool" if kind=="pool" else "partition"}_{sc}.mat')
        R, _ = ld(fn)
        line(f'{kind}_{sc}', summ(R), summ(py[('paper', f'{kind}_{sc}')]))
print('=== degradation coefficient runs ===')
for k, n in zip([2, 3, 4], ['derived', 'low', 'high']):
    R, _ = ld(os.path.join(MR, f'results_degr_{k}.mat'))
    line(n, summ(R), summ(py[('degr', n)]))
R, _ = ld(os.path.join(MR, 'results_degr_1.mat'))
line('adopted(vs PIB)', summ(R), summ(py[('paper', 'PIB')]))
print('=== four seasons ===')
for s in ['spring', 'summer', 'autumn', 'winter']:
    for n in ['NoETS', 'PIB', 'IB', 'PB', 'PI', 'B', 'I', 'P']:
        R, m = ld(os.path.join(MR, 'season', f'{s}_{n}.mat'), 'results')
        line(f'{s}_{n}', summ(R), summ(py[(s, n)]))
