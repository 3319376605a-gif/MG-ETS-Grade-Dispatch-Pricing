"""Python/SCIP port of read_config_xlsx.m + build_model.m + make_partition_data.m
+ scenario_capacity_reuse.m (see ../matlab). MIQP solved with SCIP, prices from the
fixed-integer QP solved with HiGHS. The MATLAB/Gurobi code is the reference implementation."""
import copy
import numpy as np
import pandas as pd
from pyscipopt import Model, quicksum


def read_config(xlsx):
    x = pd.read_excel(xlsx, sheet_name=None)
    d = {}
    meta = dict(zip(x['Meta'].Key, x['Meta'].Value))
    d['T'] = int(meta['T']); d['dt'] = float(meta['dt']); d['NB'] = int(meta['NB'])
    d['Nheat'] = int(meta['Nheat']); d['SlackBus'] = int(meta['SlackBus']); d['BigM'] = float(meta['BigM'])
    d['c_curt'] = float(meta.get('c_curt', 0.0))   # renewable curtailment cost, 元/MWh (optional Meta row)
    L = x['Elec_Lines']
    d['line_from'] = L.from_bus.values; d['line_to'] = L.to_bus.values
    d['line_x'] = L.x_pu.values; d['line_Pmax'] = L.Pmax_MW.values
    d['Pd'] = x['Elec_Load_Pd'].iloc[:, 1:].values.astype(float)
    up = x['upper_level_power_grid'].iloc[0]
    d['busUp'] = int(up.bus); d['Pbuy_max'] = up.Pbuy_max; d['Psell_max'] = up.Psell_max
    d['Pbuy_ramp_up'] = up.ramp_up; d['Pbuy_ramp_down'] = up.ramp_down
    d['price_buy'] = x['upper_level_price'].price_buy.values
    d['price_sell'] = x['upper_level_price'].price_sell.values
    tu = x['Gen_Turbine']
    d['J'] = len(tu); d['busTu'] = tu.bus.values; d['nTu'] = tu.heat_node.values
    for k, c in [('Ptu_min', 'Pmin_MW'), ('Ptu_max', 'Pmax_MW'), ('Ptu_ramp_up', 'ramp_up'),
                 ('Ptu_ramp_down', 'ramp_down'), ('Qtu_h_min', 'Qtu_h_min'), ('Qtu_h_max', 'Qtu_h_max'),
                 ('Qtu_c_min', 'Qtu_c_min'), ('Qtu_c_max', 'Qtu_c_max'), ('Qtu_r_min', 'Qtu_r_min'),
                 ('Qtu_r_max', 'Qtu_r_max'), ('k_cond', 'k_cond'), ('CHP_b', 'a_cost'), ('CHP_a', 'a2_cost'),
                 ('k_tu', 'k_heat_credit'), ('k_tu2', 'k_heat_credit2')]:
        d[k] = tu[c].values.astype(float)
    g = x['Gen_Other']
    d['G'] = len(g); d['busG'] = g.bus.values
    d['Pg_min'] = g.Pmin_MW.values; d['Pg_max'] = g.Pmax_MW.values
    d['Pg_ramp_up'] = g.ramp_up.values; d['Pg_ramp_down'] = g.ramp_down.values
    d['a_g'] = g.a_cost.values; d['a2_g'] = g.a2_cost.values
    gn = x['Gen_New']
    d['G_N'] = len(gn); d['busG_N'] = gn.bus.values; d['a_n'] = gn.a_cost.values
    d['Gen_New_P'] = x['Gen_New_P'].iloc[:, 1:].values.astype(float)
    st = x['Storage']
    d['I'] = len(st); d['busES'] = st.bus.values; d['nI'] = st.heat_node.values
    for k, c in [('E0', 'E0'), ('Emin', 'Emin'), ('Emax', 'Emax'), ('EL', 'EL'), ('EH', 'EH'),
                 ('eta_loss', 'eta_loss'), ('eta_ch', 'eta_ch'), ('eta_dis', 'eta_dis'), ('eta_eh', 'eta_eh'),
                 ('Pes_min', 'Pmin'), ('Pes_max', 'Pmax'), ('Qdis_min', 'Qdis_min'), ('Qdis_max', 'Qdis_max'),
                 ('Q_tu_max', 'Qtu_max'), ('Q_in_max', 'Qin_max'), ('Q_re_max', 'Qre_max'),
                 ('gamma_tu', 'gamma_tu'), ('gamma_in', 'gamma_in'), ('gamma_re', 'gamma_re')]:
        d[k] = st[c].values.astype(float)
    d['A_i2j'] = x['Conn_i2j'].iloc[:, 1:].values.astype(float)
    d['A_i2k'] = x['Conn_i2k'].iloc[:, 1:].values.astype(float)
    d['Qin_dem'] = x['Ind_Load_Demand'].iloc[:, 1:].values.astype(float)
    d['K'] = d['Qin_dem'].shape[0]
    bi = x['Boiler_Ind']
    d['S'] = len(bi); d['Qs_min'] = bi.Qmin.values; d['Qs_max'] = bi.Qmax.values
    d['gamma_GB_ind'] = bi.gamma_GB_ind.values; d['gamma_GB_ind_2'] = bi.gamma_GB_ind_2.values
    d['A_s2k'] = x['Conn_s2k'].iloc[:, 1:].values.astype(float)
    br = x['Boiler_Res']
    d['W'] = len(br); d['nW'] = br.heat_node.values
    d['Qw_min'] = br.Qmin.values; d['Qw_max'] = br.Qmax.values
    d['gamma_GB_res'] = br.gamma_GB_res.values; d['gamma_GB_res_2'] = br.gamma_GB_res_2.values
    d['nM'] = x['Res_Load'].heat_node.values
    d['Qre_dem_m'] = x['Res_Load_Demand'].iloc[:, 1:].values.astype(float)
    hn = x['Heat_Nodes']
    d['mcir'] = hn.mcir.values.astype(float); d['cw'] = hn.cw.values.astype(float)
    d['Tsup_min'] = hn.Tsup_min.values; d['Tsup_max'] = hn.Tsup_max.values
    d['Tret_min'] = hn.Tret_min.values; d['Tret_max'] = hn.Tret_max.values
    s, r = x['Heat_Edges_Sup'], x['Heat_Edges_Ret']
    d['sup_from'] = s.from_node.values; d['sup_to'] = s.to_node.values
    d['sup_m'] = s.m_flow.values.astype(float); d['sup_len'] = s.length.values.astype(float)
    d['ret_from'] = r.from_node.values; d['ret_to'] = r.to_node.values
    d['ret_m'] = r.m_flow.values.astype(float); d['ret_len'] = r.length.values.astype(float)
    tl = x['temperature_loss'].iloc[0]
    d['T_amb'] = float(tl.T_out_pipeline_equivalent); d['k_pipe'] = float(tl.Heat_transfer_rate)
    return d


def make_partition_data(data, gated=False):
    """make_partition_data.m. gated=True keeps each dedicated unit's own
    temperature threshold (same SOC-grade physics as the pool, scaled by 1/3)."""
    dp = copy.deepcopy(data)
    I = data['I']; c = 1.0 / 3
    rep = lambda v: np.repeat(np.asarray(v, float), 3)
    for k in ['busES', 'nI']:
        dp[k] = np.repeat(np.asarray(data[k]), 3)
    for k in ['E0', 'Emin', 'Emax', 'Pes_min', 'Pes_max', 'Qdis_min', 'Qdis_max']:
        dp[k] = rep(data[k]) * c
    for k in ['eta_loss', 'eta_ch', 'eta_dis', 'eta_eh', 'gamma_tu', 'gamma_in', 'gamma_re']:
        dp[k] = rep(data[k])
    dp['EL'] = dp['Emin'].copy(); dp['EH'] = dp['Emin'].copy()
    dp['Q_tu_max'] = np.zeros(3 * I); dp['Q_in_max'] = np.zeros(3 * I); dp['Q_re_max'] = np.zeros(3 * I)
    dp['A_i2j'] = np.zeros((3 * I, data['J'])); dp['A_i2k'] = np.zeros((3 * I, data['K']))
    # dedicated-unit discharge floor (gated variant): H unit needs E>=EH/3, M unit E>=EL/3
    dp['E_floor'] = dp['Emin'].copy()
    for i in range(I):
        iH, iM, iL = 3 * i, 3 * i + 1, 3 * i + 2
        cap = data['Qdis_max'][i] * c
        dp['Q_tu_max'][iH] = cap; dp['A_i2j'][iH] = data['A_i2j'][i]
        dp['Q_in_max'][iM] = cap; dp['A_i2k'][iM] = data['A_i2k'][i]
        dp['Q_re_max'][iL] = cap
        if gated:
            dp['E_floor'][iH] = data['EH'][i] * c
            dp['E_floor'][iM] = data['EL'][i] * c
    dp['I'] = 3 * I
    return dp


def scenario_capacity_reuse(d, windScale=1.2, resScale=2.0, indScale=0.3):
    """scenario_capacity_reuse.m (defaults set to the values reported in paper Sec. 4.4)."""
    d = copy.deepcopy(d)
    d['Gen_New_P'] = d['Gen_New_P'] * windScale
    d['Qre_dem_m'] = d['Qre_dem_m'] * resScale
    d['Qin_dem'] = d['Qin_dem'] * indScale
    qmin = 1.1 * np.sum(d['Qs_min'])
    col = d['Qin_dem'].sum(0)
    bad = col < qmin
    if bad.any():
        up = np.ones_like(col); up[bad] = qmin / np.maximum(col[bad], 1e-12)
        d['Qin_dem'] = d['Qin_dem'] * up
    return d


class _Scip:
    def __init__(self, gap, time_limit, verbose):
        self.m = Model(); self.m.setParam('limits/gap', gap); self.m.setParam('limits/time', time_limit)
        if not verbose: self.m.hideOutput()

    def var(self, name, lb=0.0, ub=None, vt='C'):
        return self.m.addVar(name, vtype=vt, lb=lb, ub=ub)

    def con(self, c):
        return self.m.addCons(c)

    def set_obj(self, lin, quad):
        # convex quadratic terms via per-term epigraph variables (SCIP needs a linear objective)
        zs = []
        for coef, v in quad:
            z = self.var(f'z{len(zs)}', 0)
            self.m.addCons(z >= coef * v * v)
            zs.append(z)
        self.m.setObjective(lin + quicksum(zs), 'minimize')

    def solve(self):
        self.m.optimize(); sol = self.m.getBestSol()
        self.val = lambda v: self.m.getSolVal(sol, v)
        return self.m.getStatus(), self.m.getObjVal(), self.m.getGap()


class _Highs:
    """Continuous convex QP (integers fixed) -> row duals = nodal prices."""
    def __init__(self, verbose=False):
        import highspy
        self.h = highspy.Highs(); self.inf = highspy.kHighsInf
        if not verbose: self.h.silent()

    def var(self, name, lb=0.0, ub=None, vt='C'):
        return self.h.addVariable(lb=-self.inf if lb is None else lb, ub=self.inf if ub is None else ub)

    def con(self, c):
        return self.h.addConstr(c)

    def set_obj(self, lin, quad):
        import highspy
        h = self.h
        h.setObjective(lin, sense=highspy.ObjSense.kMinimize)
        n = h.getNumCol(); diag = np.zeros(n)
        for coef, v in quad:
            diag[v.index] += 2.0 * coef            # HiGHS: min c'x + 0.5 x'Qx
        start, index, value = [], [], []
        for c in range(n):
            start.append(len(index))
            if diag[c] != 0:
                index.append(c); value.append(diag[c])
        h.passHessian(n, len(index), highspy.HessianFormat.kTriangular,
                      np.array(start, np.int32), np.array(index, np.int32), np.array(value))

    def solve(self):
        self.h.run(); sol = self.h.getSolution()
        self.val = lambda v: sol.col_value[v.index]
        self.dual = lambda c: sol.row_dual[c.index]
        st = self.h.modelStatusToString(self.h.getModelStatus())
        return st, self.h.getInfo().objective_function_value, 0.0


class _PyArr(np.ndarray):
    """Indexing returns Python scalars (highspy expressions reject numpy scalars)."""
    def __getitem__(self, k):
        v = super().__getitem__(k)
        return v.item() if isinstance(v, np.generic) else v


def _py(d):
    out = {}
    for k, v in d.items():
        if isinstance(v, np.ndarray) and v.dtype.kind in 'fiu':
            out[k] = v.astype(float).view(_PyArr)
        elif isinstance(v, np.generic):
            out[k] = v.item()
        else:
            out[k] = v
    return out


def solve(d, gap=1e-5, time_limit=1800, verbose=False, cyclic=False, y_fix=None):
    """cyclic=True: E_init is a decision variable and E(T)=E_init (repeatable typical day).
    y_fix=(yL, yM, yH): integers fixed, continuous QP solved with HiGHS and nodal prices returned."""
    if y_fix is not None:
        d = _py(d)
    # renewable curtailment cost c_cur*(P_avail - P) (元/MWh); 0 reproduces the original MATLAB model
    c_cur = float(d.get('c_curt', 0.0))
    T, I, J, K, S, W, G, GN, NB = (int(d[k]) for k in ['T', 'I', 'J', 'K', 'S', 'W', 'G', 'G_N', 'NB'])
    dt = d['dt']; M = d['BigM']
    be = _Highs(verbose) if y_fix is not None else _Scip(gap, time_limit, verbose)
    qs = (lambda it: sum(it, 0.0)) if y_fix is not None else quicksum
    V = be.var
    rI, rT = range(I), range(T)
    E = {(i, t): V(f'E{i}_{t}', None) for i in rI for t in rT}
    Qch = {(i, t): V(f'Qch{i}_{t}', None) for i in rI for t in rT}
    Qdis = {(i, t): V(f'Qdis{i}_{t}', None) for i in rI for t in rT}
    Pes = {(i, t): V(f'Pes{i}_{t}', None) for i in rI for t in rT}
    Qij = {(i, j, t): V(f'Qij{i}_{j}_{t}', 0, None if d['A_i2j'][i, j] else 0) for i in rI for j in range(J) for t in rT}
    Qik = {(i, k, t): V(f'Qik{i}_{k}_{t}', 0, None if d['A_i2k'][i, k] else 0) for i in rI for k in range(K) for t in rT}
    Qin = {(i, t): V(f'Qin{i}_{t}', 0) for i in rI for t in rT}
    if y_fix is None:
        yL, yM, yH = ({(i, t): V(f'y{z}{i}_{t}', vt='B') for i in rI for t in rT} for z in 'LMH')
    else:
        yL, yM, yH = ({(i, t): V(f'y{z}{i}_{t}', float(yv[i, t]), float(yv[i, t])) for i in rI for t in rT}
                      for z, yv in zip('LMH', y_fix))
    Ptu = {(j, t): V(f'Ptu{j}_{t}', d['Ptu_min'][j], d['Ptu_max'][j]) for j in range(J) for t in rT}
    Pg = {(g, t): V(f'Pg{g}_{t}', d['Pg_min'][g], d['Pg_max'][g]) for g in range(G) for t in rT}
    Pn = {(g, t): V(f'Pn{g}_{t}', 0, d['Gen_New_P'][g, t]) for g in range(GN) for t in rT}
    Pbuy = {t: V(f'Pbuy{t}', 0, d['Pbuy_max']) for t in rT}
    Psell = {t: V(f'Psell{t}', 0, d['Psell_max']) for t in rT}
    Qr = {(j, t): V(f'Qr{j}_{t}', d['Qtu_r_min'][j], d['Qtu_r_max'][j]) for j in range(J) for t in rT}
    Qc = {(j, t): V(f'Qc{j}_{t}', d['Qtu_c_min'][j], d['Qtu_c_max'][j]) for j in range(J) for t in rT}
    Qh = {(j, t): V(f'Qh{j}_{t}', d['Qtu_h_min'][j], d['Qtu_h_max'][j]) for j in range(J) for t in rT}
    Qs = {(s, t): V(f'Qs{s}_{t}', d['Qs_min'][s], d['Qs_max'][s]) for s in range(S) for t in rT}
    Qw = {(w, t): V(f'Qw{w}_{t}', d['Qw_min'][w], d['Qw_max'][w]) for w in range(W) for t in rT}
    Qsk = {(s, k, t): V(f'Qsk{s}_{k}_{t}', 0) for s in range(S) for k in range(K) for t in rT}
    NH = int(d['Nheat'])
    Tn = {(n, t): V(f'Ts{n}_{t}', d['Tsup_min'][n], d['Tsup_max'][n]) for n in range(NH) for t in rT}
    Rn = {(n, t): V(f'Tr{n}_{t}', d['Tret_min'][n], d['Tret_max'][n]) for n in range(NH) for t in rT}
    Es, Er = len(d['sup_from']), len(d['ret_from'])
    sf, st_, rf, rt = (np.asarray(d[k], dtype=int) - 1 for k in ['sup_from', 'sup_to', 'ret_from', 'ret_to'])
    Ssf = {(e, t): V(f'Ssf{e}_{t}', d['Tsup_min'][sf[e]], d['Tsup_max'][sf[e]]) for e in range(Es) for t in rT}
    Sst = {(e, t): V(f'Sst{e}_{t}', d['Tsup_min'][st_[e]], d['Tsup_max'][st_[e]]) for e in range(Es) for t in rT}
    Rrf = {(e, t): V(f'Rrf{e}_{t}', d['Tret_min'][rf[e]], d['Tret_max'][rf[e]]) for e in range(Er) for t in rT}
    Rrt = {(e, t): V(f'Rrt{e}_{t}', d['Tret_min'][rt[e]], d['Tret_max'][rt[e]]) for e in range(Er) for t in rT}
    th = {(u, t): V(f'th{u}_{t}', None) for u in range(NB) for t in rT}
    Pf = {(l, t): V(f'Pf{l}_{t}', -d['line_Pmax'][l], d['line_Pmax'][l]) for l in range(len(d['line_x'])) for t in rT}
    E_floor = d.get('E_floor', d['Emin'])
    A = be.con
    con_elec, con_tu, con_in, con_src, con_load = {}, {}, {}, {}, {}
    if cyclic:
        Ei = {i: V(f'Einit{i}', d['Emin'][i], d['Emax'][i]) for i in rI}
        for i in rI:
            A(E[i, T - 1] == Ei[i])
    else:
        Ei = {i: d['E0'][i] for i in rI}
    for i in rI:
        for t in rT:
            prev = d['eta_loss'][i] * (Ei[i] if t == 0 else E[i, t - 1])
            A(E[i, t] == prev + d['eta_ch'][i] * Qch[i, t] * dt - (1 / d['eta_dis'][i]) * Qdis[i, t] * dt)
            A(Qch[i, t] == d['eta_eh'][i] * Pes[i, t])
            A(Pes[i, t] >= d['Pes_min'][i]); A(Pes[i, t] <= d['Pes_max'][i])
            A(Qdis[i, t] >= d['Qdis_min'][i]); A(Qdis[i, t] <= d['Qdis_max'][i])
            A(E[i, t] >= d['Emin'][i]); A(E[i, t] <= d['Emax'][i])
            sj = qs(Qij[i, j, t] for j in range(J)); sk = qs(Qik[i, k, t] for k in range(K))
            A(Qdis[i, t] == sj + sk + Qin[i, t])
            A(yL[i, t] + yM[i, t] + yH[i, t] == 1)
            EL, EH = d['EL'][i], d['EH'][i]
            A(E[i, t] <= EL + M * (1 - yL[i, t])); A(E[i, t] >= d['Emin'][i] - M * (1 - yL[i, t]))
            A(E[i, t] >= EL - M * (1 - yM[i, t])); A(E[i, t] <= EH + M * (1 - yM[i, t]))
            A(E[i, t] >= EH - M * (1 - yH[i, t])); A(E[i, t] <= d['Emax'][i] + M * (1 - yH[i, t]))
            A(sj <= d['Q_tu_max'][i] * yH[i, t])
            A(sk <= d['Q_in_max'][i] * (yM[i, t] + yH[i, t]))
            A(Qin[i, t] <= d['Q_re_max'][i])
            if E_floor[i] > d['Emin'][i] + 1e-9:
                # gated dedicated unit: may discharge only while E stays above its grade threshold
                A(E[i, t] >= E_floor[i])
    for t in rT:
        for l in range(len(d['line_x'])):
            u, v = int(d['line_from'][l]) - 1, int(d['line_to'][l]) - 1
            A(Pf[l, t] == (th[u, t] - th[v, t]) / d['line_x'][l])
        A(th[int(d['SlackBus']) - 1, t] == 0)
        if t >= 1:
            A(Pbuy[t] - Pbuy[t - 1] <= d['Pbuy_ramp_up']); A(Pbuy[t] - Pbuy[t - 1] >= -d['Pbuy_ramp_down'])
            A(Psell[t] - Psell[t - 1] <= d['Pbuy_ramp_up']); A(Psell[t] - Psell[t - 1] >= -d['Pbuy_ramp_down'])
        for j in range(J):
            QinH = Qc[j, t] + Qr[j, t]
            A(Ptu[j, t] <= d['k_tu'][j] * QinH - d['k_cond'][j] * Qh[j, t])
            A(Qh[j, t] <= d['k_tu2'][j] * QinH)
            if t >= 1:
                A(Ptu[j, t] - Ptu[j, t - 1] <= d['Ptu_ramp_up'][j]); A(Ptu[j, t] - Ptu[j, t - 1] >= -d['Ptu_ramp_down'][j])
            con_tu[j, t] = A(Qr[j, t] - qs(Qij[i, j, t] for i in rI) == 0)
        for g in range(G):
            if t >= 1:
                A(Pg[g, t] - Pg[g, t - 1] <= d['Pg_ramp_up'][g]); A(Pg[g, t] - Pg[g, t - 1] >= -d['Pg_ramp_down'][g])
        for u in range(NB):
            bus = u + 1
            gen = qs(Ptu[j, t] for j in range(J) if d['busTu'][j] == bus) \
                + qs(Pg[g, t] for g in range(G) if d['busG'][g] == bus) \
                + qs(Pn[g, t] for g in range(GN) if d['busG_N'][g] == bus)
            if d['busUp'] == bus:
                gen = gen + Pbuy[t] - Psell[t]
            pes = qs(Pes[i, t] for i in rI if d['busES'][i] == bus)
            inj = qs(Pf[l, t] for l in range(len(d['line_x'])) if d['line_from'][l] == bus) \
                - qs(Pf[l, t] for l in range(len(d['line_x'])) if d['line_to'][l] == bus)
            con_elec[u, t] = A(gen - pes - inj == d['Pd'][u, t])
        for s in range(S):
            A(Qs[s, t] == qs(d['A_s2k'][s, k] * Qsk[s, k, t] for k in range(K)))
        for k in range(K):
            con_in[k, t] = A(qs(d['A_i2k'][i, k] * Qik[i, k, t] for i in rI)
                             + qs(d['A_s2k'][s, k] * Qsk[s, k, t] for s in range(S)) == d['Qin_dem'][k, t])
    MW2W = 1e6
    src = sorted(set(int(x) for x in np.r_[d['nI'], d['nW'], d['nTu']]))
    load = sorted(set(int(x) for x in np.asarray(d['nM'])))
    mid = [n for n in range(1, NH + 1) if n not in src and n not in load]
    for t in rT:
        for e in range(Es):
            A(Ssf[e, t] == Tn[sf[e], t])
        for e in range(Er):
            A(Rrf[e, t] == Rn[rf[e], t])
        for n in src:
            for e in np.where(rt == n - 1)[0]:
                A(Rrt[e, t] == Rn[n - 1, t])
        for n in load:
            for e in np.where(st_ == n - 1)[0]:
                A(Sst[e, t] == Tn[n - 1, t])
        for e in range(Es):
            a = float(np.exp(-d['k_pipe'] * d['sup_len'][e] / (MW2W * d['cw'][sf[e]] * d['sup_m'][e])))
            A(Sst[e, t] == d['T_amb'] + (Ssf[e, t] - d['T_amb']) * a)
        for e in range(Er):
            a = float(np.exp(-d['k_pipe'] * d['ret_len'][e] / (MW2W * d['cw'][rf[e]] * d['ret_m'][e])))
            A(Rrt[e, t] == d['T_amb'] + (Rrf[e, t] - d['T_amb']) * a)
        for n in src:
            q = qs(Qin[i, t] for i in rI if d['nI'][i] == n) + qs(Qw[w, t] for w in range(W) if d['nW'][w] == n) \
                + qs(Qh[j, t] for j in range(J) if d['nTu'][j] == n)
            con_src[n, t] = A(d['cw'][n - 1] * d['mcir'][n - 1] * (Tn[n - 1, t] - Rn[n - 1, t]) - q == 0)
        for n in load:
            ql = float(sum(d['Qre_dem_m'][mm, t] for mm in range(len(d['nM'])) if d['nM'][mm] == n))
            con_load[n, t] = A(d['cw'][n - 1] * d['mcir'][n - 1] * (Tn[n - 1, t] - Rn[n - 1, t]) == ql)
        for n in mid:
            inE = np.where(st_ == n - 1)[0]
            if len(inE):
                A(float(np.sum(d['sup_m'][inE])) * Tn[n - 1, t] - qs(d['sup_m'][e] * Sst[e, t] for e in inE) == 0)
            inR = np.where(rt == n - 1)[0]
            if len(inR):
                A(float(np.sum(d['ret_m'][inR])) * Rn[n - 1, t] - qs(d['ret_m'][e] * Rrt[e, t] for e in inR) == 0)
    lin = qs(d['price_buy'][t] * Pbuy[t] - d['price_sell'][t] * Psell[t] for t in rT) \
        + qs((d['a_n'][g] - c_cur) * Pn[g, t] for g in range(GN) for t in rT) \
        + qs(d['a_g'][g] * Pg[g, t] for g in range(G) for t in rT) \
        + qs(d['CHP_b'][j] * Qc[j, t] for j in range(J) for t in rT) \
        + qs(d['gamma_tu'][i] * Qij[i, j, t] for i in rI for j in range(J) for t in rT) \
        + qs(d['gamma_in'][i] * Qik[i, k, t] for i in rI for k in range(K) for t in rT) \
        + qs(d['gamma_re'][i] * Qin[i, t] for i in rI for t in rT) \
        + qs(d['gamma_GB_ind'][s] * Qs[s, t] for s in range(S) for t in rT) \
        + qs(d['gamma_GB_res'][w] * Qw[w, t] for w in range(W) for t in rT)
    quad = ([(d['a2_g'][g], Pg[g, t]) for g in range(G) for t in rT]
            + [(d['CHP_a'][j], Qc[j, t]) for j in range(J) for t in rT]
            + [(d['gamma_GB_ind_2'][s], Qs[s, t]) for s in range(S) for t in rT]
            + [(d['gamma_GB_res_2'][w], Qw[w, t]) for w in range(W) for t in rT])
    be.set_obj(lin, quad)
    status, obj, gap_ = be.solve()
    obj = obj + c_cur * float(np.sum(d['Gen_New_P']))   # constant part of c_cur*(avail - Pn)
    val = be.val
    arr2 = lambda D, a, b: np.array([[val(D[x, y]) for y in range(b)] for x in range(a)])
    r = dict(status=status, obj=obj, gap=gap_,
             E=arr2(E, I, T), Pes=arr2(Pes, I, T), Qdis=arr2(Qdis, I, T),
             Q_i2j=np.array([[[val(Qij[i, j, t]) for t in rT] for j in range(J)] for i in rI]),
             Q_i2k=np.array([[[val(Qik[i, k, t]) for t in rT] for k in range(K)] for i in rI]),
             Q_i2n=arr2(Qin, I, T), Pn=arr2(Pn, GN, T), Pg=arr2(Pg, G, T), Ptu=arr2(Ptu, J, T),
             Qtu_c=arr2(Qc, J, T), Qtu_h=arr2(Qh, J, T), Qtu_r=arr2(Qr, J, T),
             Qs=arr2(Qs, S, T), Qw=arr2(Qw, W, T),
             Q_s2k=np.array([[[val(Qsk[s, k, t]) for t in rT] for k in range(K)] for s in range(S)]),
             Pbuy=np.array([val(Pbuy[t]) for t in rT]), Psell=np.array([val(Psell[t]) for t in rT]),
             yL=arr2(yL, I, T).round(), yM=arr2(yM, I, T).round(), yH=arr2(yH, I, T).round())
    if y_fix is not None:
        du = be.dual
        r['pi_bus'] = np.array([[du(con_elec[u, t]) for t in rT] for u in range(NB)])
        r['pi_tu'] = np.array([[-du(con_tu[j, t]) for t in rT] for j in range(J)])
        r['pi_in'] = np.array([[du(con_in[k, t]) for t in rT] for k in range(K)])
        pn = np.full((NH, T), np.nan)
        for (n, t), c in con_src.items(): pn[n - 1, t] = -du(c)
        for (n, t), c in con_load.items(): pn[n - 1, t] = du(c)
        r['pi_node'] = pn
    return r


def solve_priced(d, cyclic=True, **kw):
    """solve_dispatch_milp.m: MIQP -> fix integers -> continuous QP -> duals as prices."""
    r = solve(d, cyclic=cyclic, **kw)
    rp = solve(d, cyclic=cyclic, y_fix=(r['yL'], r['yM'], r['yH']))
    for k in ['pi_bus', 'pi_tu', 'pi_in', 'pi_node']:
        r[k] = rp[k]
    r['obj_fixed'] = rp['obj']; r['status_fixed'] = rp['status']
    return r
