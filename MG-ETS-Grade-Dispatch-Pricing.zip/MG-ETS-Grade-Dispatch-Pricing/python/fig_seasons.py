"""Four-season and lifecycle figures (paper Sec. 4.5-4.6, Figs. 7-10; curtailment cost included).
Usage: python fig_seasons.py <case.xlsx> <outdir> runs_a.pkl runs_b.pkl"""
import sys, os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import lcc_season as lc, seasons as se, settle as st

plt.rcParams.update({'font.family': ['Liberation Serif', 'Noto Serif CJK SC'], 'font.size': 9,
                     'axes.unicode_minus': False, 'mathtext.fontset': 'stix', 'savefig.dpi': 300,
                     'xtick.direction': 'in', 'ytick.direction': 'in', 'axes.linewidth': 0.8,
                     'axes.grid': False, 'legend.frameon': False})
SEAS = lc.SEAS
CN = se.NAMES_CN
# palette of the paper's original figures (matlab/plot_section42_figures.m)
C = dict(charge=(0.929, 0.490, 0.192), P=(0.180, 0.545, 0.549), I=(0.557, 0.267, 0.537),
         B=(0.843, 0.522, 0.522), E=(0.122, 0.267, 0.537), band_high=(0.957, 0.898, 0.898),
         band_mid=(0.969, 0.949, 0.910), band_low=(0.910, 0.945, 0.969), steel=(0.329, 0.431, 0.639),
         green=(0.302, 0.686, 0.290), gold=(0.929, 0.686, 0.133), gray=(0.62, 0.62, 0.62),
         zero=(0.5, 0.5, 0.5), dark=(0.35, 0.35, 0.35))
CASES = [('NoETS', '无电蓄热', C['gray']), ('B', '仅建筑级供热', C['steel']), ('PIB', '三品级供热', C['P'])]
# grade configurations, labels as in the paper's Table 1
GRADES = [('PIB', '发电+工业+建筑'), ('PI', '发电+工业'), ('PB', '发电+建筑'), ('IB', '工业+建筑'),
          ('P', '仅发电'), ('I', '仅工业'), ('B', '仅建筑')]
LINE_C = [(0.180, 0.545, 0.549), (0.557, 0.267, 0.537), (0.843, 0.522, 0.522), (0.929, 0.490, 0.192),
          (0.122, 0.267, 0.537), (0.400, 0.706, 0.710), (0.55, 0.55, 0.55)]


def box(ax):
    for sp in ax.spines.values():
        sp.set_visible(True); sp.set_linewidth(0.8)
    ax.tick_params(direction='in', top=False, right=False)


def sub(k, txt):
    return f'({"abcd"[k]}) {txt}'


def dispatch(runs, out):
    fig, axs = plt.subplots(2, 2, figsize=(6.9, 4.7))
    for k, (ax, s) in enumerate(zip(axs.flat, SEAS)):
        r = runs[(s, 'PIB')]; t = np.arange(1, 25)
        P, I, B = r['Q_i2j'].sum((0, 1)), r['Q_i2k'].sum((0, 1)), r['Q_i2n'].sum(0)
        ch = 0.97 * r['Pes'].sum(0)
        ax.bar(t, ch, 0.8, color=C['charge'], alpha=0.9, label='充热', lw=0)
        ax.bar(t, -P, 0.8, color=C['P'], alpha=0.75, label='发电级放热', lw=0)
        ax.bar(t, -I, 0.8, bottom=-P, color=C['I'], alpha=0.75, label='工业级放热', lw=0)
        ax.bar(t, -B, 0.8, bottom=-P - I, color=C['B'], alpha=0.75, label='建筑级放热', lw=0)
        ax.axhline(0, color=C['zero'], lw=0.6); ax.set_ylim(-420, 420)
        e2p = lambda e: -420 + (e - 130) / 800 * 840          # energy axis -> power axis (same frame)
        for lo, hi, cc in [(600, 900, 'band_high'), (400, 600, 'band_mid'), (160, 400, 'band_low')]:
            ax.axhspan(e2p(lo), e2p(hi), color=C[cc], alpha=0.4, lw=0, zorder=0)
        ax2 = ax.twinx()
        ax2.plot(t, r['E'].sum(0), '-o', color=C['E'], lw=1.4, ms=3, mfc='w', mec=C['E'], label='储能量')
        ax2.set_ylim(130, 930); ax2.tick_params(direction='in')
        if k % 2 == 0: ax.set_ylabel('热功率/MW')
        else: ax2.set_ylabel('储能量/MWh')
        ax.set_xlabel('时刻\n' + sub(k, CN[s]))
        ax.set_xlim(0, 24.5); ax.set_xticks([0, 4, 8, 12, 16, 20, 24]); box(ax)
    h1, l1 = axs[0, 0].get_legend_handles_labels()
    h2, l2 = fig.axes[-4].get_legend_handles_labels()
    fig.legend(h1 + h2, l1 + l2, loc='upper center', ncol=5, bbox_to_anchor=(0.5, 1.0), handlelength=1.2)
    fig.tight_layout(rect=(0, 0, 1, 0.94)); fig.savefig(out); plt.close(fig)


def cost_curt(runs, datas, out):
    fig, axs = plt.subplots(1, 2, figsize=(6.9, 2.8))
    x = np.arange(4); w = 0.26
    for k, (n, lab, c) in enumerate(CASES):
        cost = [runs[(s, n)]['obj'] / 1e4 for s in SEAS]
        curt = [max(datas[(s, n)]['Gen_New_P'].sum() - runs[(s, n)]['Pn'].sum(), 0.0) for s in SEAS]
        axs[0].bar(x + (k - 1) * w, cost, w, color=c, label=lab, alpha=0.92, lw=0)
        axs[1].bar(x + (k - 1) * w, curt, w, color=c, label=lab, alpha=0.92, lw=0)
    axs[0].set_ylabel('日运行成本/万元'); axs[1].set_ylabel('弃风弃光电量/MWh')
    for k, (a, tl) in enumerate(zip(axs, ['日运行成本', '弃风弃光电量'])):
        a.set_xticks(x); a.set_xticklabels([CN[s] for s in SEAS]); a.set_xlabel(sub(k, tl)); box(a)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc='upper center', ncol=3, bbox_to_anchor=(0.5, 1.0))
    fig.tight_layout(rect=(0, 0, 1, 0.9)); fig.savefig(out); plt.close(fig)


def prices(runs, datas, out):
    fig, axs = plt.subplots(2, 2, figsize=(6.9, 4.5))
    t = np.arange(1, 25)
    for k, (ax, s) in enumerate(zip(axs.flat, SEAS)):
        r, d = runs[(s, 'PIB')], datas[(s, 'PIB')]
        ld = np.unique(np.asarray(d['nM'])) - 1
        kw = dict(lw=1.4, ms=3, mfc='w')
        ax.plot(t, r['pi_tu'].mean(0), '-o', color=C['P'], mec=C['P'], label='发电级热价', **kw)
        ax.plot(t, r['pi_in'].mean(0), '-s', color=C['I'], mec=C['I'], label='工业级热价', **kw)
        ax.plot(t, np.nanmean(r['pi_node'][ld], 0), '-^', color=C['B'], mec=C['B'], label='建筑级热价', **kw)
        ax.plot(t, r['pi_bus'].mean(0), '--', color=C['E'], lw=1.2, label='节点电价')
        ax.axhline(0, color=C['zero'], lw=0.6)
        ax.set_xlim(1, 24); ax.set_xticks([1, 4, 8, 12, 16, 20, 24]); box(ax)
        if k % 2 == 0: ax.set_ylabel('价格/(元/MWh)')
        ax.set_xlabel('时刻\n' + sub(k, CN[s]))
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc='upper center', ncol=4, bbox_to_anchor=(0.5, 1.0))
    fig.tight_layout(rect=(0, 0, 1, 0.94)); fig.savefig(out); plt.close(fig)


def revenue(runs, datas, out):
    keys = [('ETS', '电蓄热'), ('CHP', '热电联产'), ('RE', '新能源'), ('ConvGen', '常规机组'),
            ('BoInd', '工业锅炉'), ('BoRes', '居民锅炉'), ('IndPay', '工业用户\n用热支付'), ('ResPay', '居民用户\n用热支付')]
    acc = {s: st.settle(runs[(s, 'PIB')], datas[(s, 'PIB')]) for s in SEAS}
    fig, ax = plt.subplots(figsize=(6.9, 2.9))
    x = np.arange(len(keys)); w = 0.2
    cs = [C['green'], C['charge'], C['I'], C['E']]
    for k, s in enumerate(SEAS):
        ax.bar(x + (k - 1.5) * w, [acc[s][kk] / 1e4 for kk, _ in keys], w, color=cs[k], label=CN[s], alpha=0.92, lw=0)
    ax.axhline(0, color=C['zero'], lw=0.6); ax.axvline(5.5, color=C['dark'], ls=':', lw=0.8)
    ax.set_xticks(x); ax.set_xticklabels([v for _, v in keys]); box(ax)
    ax.set_ylabel('净收益或支付/万元')
    h, l = ax.get_legend_handles_labels()
    fig.legend(h, l, loc='upper center', ncol=4, bbox_to_anchor=(0.5, 1.0))
    fig.tight_layout(rect=(0, 0, 1, 0.9)); fig.savefig(out); plt.close(fig)


def lifecycle(df, out, r=0.064, life=25):
    """Lifecycle benefit vs. the no-ETS system: (a) cumulative discounted net cash flow, (b) present-value breakdown."""
    d = df.set_index('name')
    af = (1 - (1 + r) ** -life) / r
    b0 = d.loc['NoETS']
    fig, axs = plt.subplots(1, 2, figsize=(6.9, 3.1), gridspec_kw=dict(width_ratios=[1, 1.25]))
    yrs = np.arange(life + 1); disc = (1 + r) ** -yrs
    for (n, lab), c in zip(GRADES, LINE_C):
        cf = np.r_[-d.loc[n, 'capex'], np.full(life, d.loc[n, 'saving_y'])] * disc
        axs[0].plot(yrs, np.cumsum(cf) / 1e4, color=c, lw=2.0 if n == 'PIB' else 1.1, label=lab)
    axs[0].axhline(0, color=C['zero'], lw=0.6); axs[0].set_xlim(0, life)
    axs[0].set_ylabel('累计折现净现金流/亿元'); axs[0].set_xlabel('运行年份/a\n' + sub(0, '累计折现净现金流')); box(axs[0])
    axs[0].legend(fontsize=7, loc='upper left', handlelength=1.4)
    x = np.arange(len(GRADES)); kw = dict(width=0.62, lw=0, alpha=0.92)
    fuel = np.array([(b0['op'] - b0['curt_cost']) - (d.loc[n, 'op'] - d.loc[n, 'curt_cost']) for n, _ in GRADES]) * af / 1e4
    curt = np.array([b0['curt_cost'] - d.loc[n, 'curt_cost'] for n, _ in GRADES]) * af / 1e4
    hx = np.array([d.loc[n, 'capex_hx'] for n, _ in GRADES]) / 1e4
    oth = np.array([d.loc[n, 'capex'] - d.loc[n, 'capex_hx'] for n, _ in GRADES]) / 1e4
    om = np.array([d.loc[n, 'om'] for n, _ in GRADES]) * af / 1e4
    ax = axs[1]
    ax.bar(x, fuel, color=C['green'], label='燃料成本节约', **kw)
    ax.bar(x, curt, bottom=fuel, color=C['gold'], label='弃电成本节约', **kw)
    ax.bar(x, -oth, color=C['steel'], label='加热器与储热体投资', **kw)
    ax.bar(x, -hx, bottom=-oth, color=C['charge'], label='换热设备投资', **kw)
    ax.bar(x, -om, bottom=-oth - hx, color=C['gray'], label='固定运维', **kw)
    npv = fuel + curt - oth - hx - om
    ax.hlines(npv, x - 0.31, x + 0.31, color='k', lw=1.8, zorder=5)
    ax.plot([], [], '-', color='k', lw=1.8, label='净现值')
    ax.axhline(0, color=C['zero'], lw=0.6)
    ax.set_xticks(x); ax.set_xticklabels([l.replace('+', '+\n') for _, l in GRADES], fontsize=7)
    ax.set_ylabel('现值/亿元'); ax.set_xlabel(sub(1, '全寿命周期收益与成本现值')); box(ax)
    h, l = ax.get_legend_handles_labels(); h, l = h[1:] + h[:1], l[1:] + l[:1]
    ax.legend(h, l, fontsize=6.5, ncol=3, loc='upper center', bbox_to_anchor=(0.5, 1.22), handlelength=1.0, columnspacing=0.8)
    fig.tight_layout(); fig.savefig(out); plt.close(fig)
    return dict(af=af, fuel=dict(zip([n for n, _ in GRADES], fuel)), curt=dict(zip([n for n, _ in GRADES], curt)),
                npv=dict(zip([n for n, _ in GRADES], npv)))


if __name__ == '__main__':
    xlsx, outdir, paths = sys.argv[1], sys.argv[2], sys.argv[3:]
    os.makedirs(outdir, exist_ok=True)
    runs, datas = lc.load(paths, xlsx)
    names = [n for n in lc.GRADE_CASES if all((s, n) in runs for s in SEAS)]
    df, _ = lc.evaluate(runs, datas, names)
    lifecycle(df, os.path.join(outdir, 'fig_lcc.png'))
    dispatch(runs, os.path.join(outdir, 'fig_season_dispatch.png'))
    cost_curt(runs, datas, os.path.join(outdir, 'fig_season_cost.png'))
    prices(runs, datas, os.path.join(outdir, 'fig_season_price.png'))
    revenue(runs, datas, os.path.join(outdir, 'fig_season_revenue.png'))
    print('figures ->', outdir)
