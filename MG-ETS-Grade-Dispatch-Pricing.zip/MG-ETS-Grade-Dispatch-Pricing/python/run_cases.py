"""Configuration builders shared by the batch runs."""
import copy
import numpy as np
import ets_model as em

CASES = ['NoETS', 'PIB', 'IB', 'PB', 'PI', 'B', 'I', 'P', 'Part_ungated', 'Part_gated', 'Pool_cap100']


def grade_case(d, use):
    d = copy.deepcopy(d)
    if 'P' not in use: d['A_i2j'][:] = 0; d['Q_tu_max'][:] = 0
    if 'I' not in use: d['A_i2k'][:] = 0; d['Q_in_max'][:] = 0
    if 'B' not in use: d['Q_re_max'][:] = 0
    return d


def no_ets(d):
    d = copy.deepcopy(d)
    for k in ['Pes_max', 'Qdis_max', 'Emin', 'EL', 'EH', 'E0', 'Emax', 'Q_tu_max', 'Q_in_max', 'Q_re_max']:
        d[k] = np.zeros_like(d[k])
    return d


def pool_cap(d, cap):
    d = copy.deepcopy(d)
    d['Q_tu_max'][:] = cap; d['Q_in_max'][:] = cap; d['Q_re_max'][:] = cap
    return d


def build(d, name):
    if name == 'NoETS': return no_ets(d)
    if name == 'Part_ungated': return em.make_partition_data(d, gated=False)
    if name == 'Part_gated': return em.make_partition_data(d, gated=True)
    if name == 'Pool_cap100': return pool_cap(d, 100.0)
    return grade_case(d, name)
