"""Four-season lifecycle accounting incl. high-temperature heat-exchanger capex.

System view : EAC = sum_c capex_c*CRF(r,n_c) + OM_fix*capex + sum_s days_s*C_s
              (C_s: typical-day operating cost without the ETS degradation terms, see P['exclude_degr'])
              C_s includes the renewable curtailment cost; NPV/IRR vs. the no-ETS system (paper Sec. 4.6, Table 5).
"""
import sys, pickle, copy, json
import numpy as np, pandas as pd
import ets_model as em, seasons as se, run_cases as rc, settle as st

P = dict(
    r=0.064, life=25,                                   # real discount rate 6.4 %, analysis period 25 a (ref [18] Table 7)
    life_c=dict(store=25, heater=25, fan=25, hx=25),
    # Capex basis: Hamilton & Neises, J Energy Storage 2023 (paper ref [18], Table 7):
    #   heater 104 $/kW_t, storage 22 $/kWh_t, contingency 7 %, EPC & owner 13 %, 7.0467 元/$.
    #   Fans/ducts are part of the "配套结构" in that basis -> c_fan = 0.
    fx=7.0467, k_c=0.07, k_e=0.13,
    c_store=22.0 * 7.0467,                      # 元/kWh_th
    c_heater=104.0 * 7.0467,                    # 元/kW_th  (rated thermal power = Pe * eta_eh)
    c_fan=0.0,
    # Heat exchangers. Generation grade = steam generation system of the SAM molten-salt tower cost model
    # (Turchi & Heath, NREL/TP-5500-57625, 2013, Table 1; paper ref [37]): 350 $/kW_e x 0.412 gross cycle efficiency = 144.2 $/kW_t
    # (evaporator, superheater/reheater, preheater, pumps, piping, controls, foundations).
    # Industrial / building grade scaled by the exergy factor (paper Appendix B6, Table B7: 0.3706/0.5174, 0.1813/0.5174).
    c_hx=dict(P=144.2 * 7.0467, I=144.2 * 7.0467 * 0.3706 / 0.5174, B=144.2 * 7.0467 * 0.1813 / 0.5174),
    multi_loop=0.05,                            # extra on HX capex of a device with >=2 grade circuits
    om_fix=0.015,                               # fixed O&M, share of capex per year
    E=450.0, Pe=200.0, eta_eh=0.97, Qdis=300.0, n_dev=2,
    # The degradation terms gamma_x in the dispatch objective are the work-based depreciation of the same
    # capex (paper Appendix B6); they are excluded from lifecycle operating cost to avoid counting it twice.
    exclude_degr=True,
)
SEAS = list(se.SEASONS)
C_CURT = 373.1      # 元/MWh renewable curtailment cost, must match run_jobs.py
# no-ETS baseline + the 7 grade configurations reported in the paper (partition variants are not evaluated)
GRADE_CASES = ['NoETS', 'PIB', 'IB', 'PB', 'PI', 'B', 'I', 'P']
DAYS = {s: se.SEASONS[s][0] for s in SEAS}


def crf(r, n):
    return r * (1 + r) ** n / ((1 + r) ** n - 1)


def ceil10(x):
    return np.ceil(np.round(x, 6) / 10.0) * 10.0


def peaks(r):
    return np.c_[r['Q_i2j'].sum(1).max(1), r['Q_i2k'].sum(1).max(1), r['Q_i2n'].max(1)]


def hx_sizes(name, runs):
    """Installed HX capacity (MW_th) per grade [P, I, B] = per-device seasonal peak, rounded up to 10 MW."""
    if name == 'NoETS':
        return np.zeros(3), 0
    pk = np.max([peaks(runs[(s, name)]) for s in SEAS], axis=0)
    if name.startswith('Part'):                 # rows [H, M, L] per parent device
        n = pk.shape[0] // 3
        per = np.array([[pk[3 * k, 0], pk[3 * k + 1, 1], pk[3 * k + 2, 2]] for k in range(n)])
        return ceil10(per).sum(0), 0
    per = ceil10(pk)
    return per.sum(0), int(((per > 0).sum(1) >= 2).sum())


def capex(name, runs, p=P):
    """Capex by component (万元)."""
    if name == 'NoETS':
        return dict(store=0., heater=0., fan=0., hx=0., hxP=0., hxI=0., hxB=0., hxMW=[0, 0, 0])
    n = p['n_dev']
    hx, multi = hx_sizes(name, runs)
    hxP, hxI, hxB = (hx[g] * 1e3 * p['c_hx'][k] / 1e4 for g, k in enumerate('PIB'))
    loop = p['multi_loop'] * (hxP + hxI + hxB) * (multi / n)
    k = (1 + p['k_c']) * (1 + p['k_e'])        # contingency + EPC/owner, applied to every item
    return dict(store=k * n * p['E'] * 1e3 * p['c_store'] / 1e4,
                heater=k * n * p['Pe'] * p['eta_eh'] * 1e3 * p['c_heater'] / 1e4,
                fan=k * n * p['Qdis'] * 1e3 * p['c_fan'] / 1e4, hx=k * (hxP + hxI + hxB + loop),
                hxP=k * hxP, hxI=k * hxI, hxB=k * hxB, hxMW=hx.tolist())


def cashflows(c, annual_net, p=P):
    """Yearly cash flows (万元), year 0 = capex; components replaced at end of their life within the horizon."""
    cf = np.full(p['life'] + 1, annual_net, float)
    cf[0] = -sum(c[k] for k in ['store', 'heater', 'fan', 'hx'])
    for k in ['store', 'heater', 'fan', 'hx']:
        L = p['life_c'][k]
        for y in range(L, p['life'], L):
            cf[y] -= c[k]
    return cf


def npv(cf, r):
    return float(sum(v / (1 + r) ** y for y, v in enumerate(cf)))


def irr(cf):
    lo, hi = -0.99, 1.0
    if npv(cf, hi) > 0 or npv(cf, lo) < 0:
        return float('nan')
    for _ in range(200):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if npv(cf, mid) > 0 else (lo, mid)
    return mid


def payback(cf, r):
    acc = 0.0
    for y, v in enumerate(cf):
        prev = acc; acc += v / (1 + r) ** y
        if y > 0 and acc >= 0:
            return y - 1 + (-prev) / (acc - prev)
    return float('nan')


def evaluate(runs, datas, names, p=P):
    acc = {(s, n): st.settle(runs[(s, n)], datas[(s, n)]) for s in SEAS for n in names}
    degr = {(s, n): (acc[(s, n)]['ETS_degr'] if p['exclude_degr'] else 0.0) for s in SEAS for n in names}
    curt = {(s, n): datas[(s, n)]['Gen_New_P'].sum() - runs[(s, n)]['Pn'].sum() for s in SEAS for n in names}
    ccur = {k: float(datas[k].get('c_curt', 0.0)) * v for k, v in curt.items()}       # curtailment cost 元/day
    yr = lambda f, n: sum(DAYS[s] * f(s, n) for s in SEAS) / 1e4                       # 万元/a
    opf = lambda s, n: runs[(s, n)]['obj'] - degr[(s, n)]
    base_op, base_cc = yr(opf, 'NoETS'), yr(lambda s, n: ccur[(s, n)], 'NoETS')
    rows = []
    for n in names:
        c = capex(n, runs, p)
        tot = c['store'] + c['heater'] + c['fan'] + c['hx']
        L, r = p['life_c'], p['r']
        ann_cap = sum(c[k] * crf(r, L[k]) for k in ['store', 'heater', 'fan', 'hx'])
        om = p['om_fix'] * tot
        op, cc = yr(opf, n), yr(lambda s, n: ccur[(s, n)], n)
        row = dict(name=n, capex=tot, capex_hx=c['hx'], hx_share=c['hx'] / tot if tot else 0.,
                   hxP=c['hxP'], hxP_MW=c['hxMW'][0], hxI_MW=c['hxMW'][1], hxB_MW=c['hxMW'][2],
                   ann_cap=ann_cap, om=om, op=op, curt_cost=cc, EAC=ann_cap + om + op,
                   curt_GWh=yr(lambda s, n: curt[(s, n)], n) * 1e4 / 1e3, degr_y=yr(lambda s, n: degr[(s, n)], n))
        for s in SEAS:
            row[f'C_{s}'] = opf(s, n) / 1e4
        if n != 'NoETS':
            sav = base_op - op - om
            cf = cashflows(c, sav, p)
            # same, with the curtailment cost left out of the operating cost (robustness note)
            cf0 = cashflows(c, sav - (base_cc - cc), p)
            row.update(saving_y=sav, NPV=npv(cf, r), IRR=irr(cf), payback=payback(cf, r),
                       NPV_nocurt=npv(cf0, r), IRR_nocurt=irr(cf0), payback_nocurt=payback(cf0, r))
        rows.append(row)
    return pd.DataFrame(rows), acc


def load(paths, xlsx):
    runs = {}
    for f in paths:
        runs.update(pickle.load(open(f, 'rb')))
    base = em.read_config(xlsx)
    base['c_curt'] = C_CURT
    runs = {k: v for k, v in runs.items() if k[0] in SEAS}
    datas = {(s, n): rc.build(se.season_data(base, s), n) for (s, n) in runs}
    return runs, datas


if __name__ == '__main__':
    xlsx, paths = sys.argv[1], sys.argv[2:]
    runs, datas = load(paths, xlsx)
    names = [n for n in GRADE_CASES if all((s, n) in runs for s in SEAS)]
    df, _ = evaluate(runs, datas, names)
    pd.set_option('display.width', 250)
    print(df.round(3).to_string())
