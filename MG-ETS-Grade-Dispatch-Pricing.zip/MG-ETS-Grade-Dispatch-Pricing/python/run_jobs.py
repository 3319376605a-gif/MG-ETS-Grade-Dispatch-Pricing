"""Batch runs with the renewable curtailment cost (paper Sec. 4.4-4.5, Appendix B7). Resumable.
Usage: python run_jobs.py <case.xlsx> <out.pkl> <group> [<group> ...]
groups: paper  - paper base day (E0 fixed, as in the MATLAB code): 7 grade cases + pool/partition (standard, reuse)
        degr   - base day, three-grade case with the derived / low / high discharge cost coefficients (Appendix B7, Tables B8/B9)
        <season> - spring/summer/autumn/winter: periodic-SOC typical day, NoETS + 7 grade cases (Sec. 4.5-4.6)
"""
import sys, os, copy, pickle, time
import ets_model as em, seasons as se, run_cases as rc

C_CURT = 373.1      # 元/MWh, Jilin coal-fired benchmark price = mechanism price of existing renewables
GRADES = ['PIB', 'IB', 'PB', 'PI', 'B', 'I', 'P']
DEGR = {'derived': (27.45, 19.67, 9.62), 'low': (22.88, 16.39, 8.01), 'high': (34.32, 24.58, 12.02)}


def jobs(base, group):
    b = copy.deepcopy(base); b['c_curt'] = C_CURT
    if group == 'paper':
        for n in GRADES:
            yield ('paper', n), rc.grade_case(b, n), dict(cyclic=False, priced=True)
        ru = em.scenario_capacity_reuse(b)
        for sc, d in [('standard', b), ('reuse', ru)]:
            yield ('paper', 'pool_' + sc), d, dict(cyclic=False, priced=False)
            yield ('paper', 'part_' + sc), em.make_partition_data(d), dict(cyclic=False, priced=False)
    elif group == 'degr':
        for k, (gp, gi, gb) in DEGR.items():
            d = copy.deepcopy(b)
            d['gamma_tu'][:] = gp; d['gamma_in'][:] = gi; d['gamma_re'][:] = gb
            yield ('degr', k), d, dict(cyclic=False, priced=True)
    else:
        d = se.season_data(b, group)
        for n in ['NoETS'] + GRADES:
            yield (group, n), rc.build(d, n), dict(cyclic=True, priced=True)


if __name__ == '__main__':
    X, OUT, groups = sys.argv[1], sys.argv[2], sys.argv[3:]
    base = em.read_config(X)
    res = pickle.load(open(OUT, 'rb')) if os.path.exists(OUT) else {}
    for g in groups:
        for key, d, o in jobs(base, g):
            if key in res: continue
            t0 = time.time()
            r = (em.solve_priced if o['priced'] else em.solve)(d, cyclic=o['cyclic'], time_limit=1800)
            r['I'] = d['I']
            res[key] = r
            print(f"{key[0]:8s} {key[1]:14s} obj={r['obj']:11.1f} curt={d['Gen_New_P'].sum() - r['Pn'].sum():8.1f} "
                  f"{r['status']} {time.time() - t0:5.0f}s", flush=True)
            pickle.dump(res, open(OUT, 'wb'))
