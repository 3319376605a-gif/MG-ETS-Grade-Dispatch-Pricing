"""Paper Appendix B, Fig. B1: four-season typical-day load and available renewable output.
Winter = paper base day (Sec. 4.1); other seasons scaled by seasons.py. Usage: python fig_b1.py <case.xlsx> <out.png>"""
import sys

import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import ets_model as em, seasons as se

X, OUT = sys.argv[1], sys.argv[2]
base = em.read_config(X)
plt.rcParams.update({'font.family': ['Liberation Serif', 'Noto Serif CJK SC'], 'font.size': 7,
                     'axes.unicode_minus': False, 'axes.linewidth': 0.6,
                     'xtick.direction': 'in', 'ytick.direction': 'in',
                     'xtick.major.width': 0.6, 'ytick.major.width': 0.6})
# 季节色（validate_palette: 全部通过，相邻 CVD ΔE 7.6 → 另以标记形状作第二编码）
COL = {'spring': '#2E8B45', 'summer': '#F0913A', 'autumn': '#9B4F96', 'winter': '#3A78C2'}
MK = {'spring': 'o', 'summer': 's', 'autumn': '^', 'winter': 'D'}
SEAS = ['spring', 'summer', 'autumn', 'winter']
t = np.arange(1, 25)
D = {s: se.season_data(base, s) for s in SEAS}
panels = [('(a) 系统电负荷', lambda d: d['Pd'].sum(0)),
          ('(b) 风电可用出力', lambda d: d['Gen_New_P'][0]),
          ('(c) 光伏可用出力', lambda d: d['Gen_New_P'][1]),
          ('(d) 工业级热负荷', lambda d: d['Qin_dem'].sum(0)),
          ('(e) 建筑级热负荷', lambda d: d['Qre_dem_m'].sum(0))]
fig, axs = plt.subplots(3, 2, figsize=(3.3, 4.3))
axs = axs.ravel()
for ax, (title, f) in zip(axs, panels):
    if title.startswith('(d)'):
        ax.plot(t, f(D['winter']), '-', color='#555555', lw=1.0)
        ax.text(0.5, 0.12, '四季相同', transform=ax.transAxes, ha='center', fontsize=6.5, color='#333333')
    else:
        for s in SEAS:
            ax.plot(t, f(D[s]), '-', color=COL[s], lw=1.0, marker=MK[s], ms=2.2, markevery=3,
                    mfc='white', mew=0.6, label=se.NAMES_CN[s])
    if title.startswith('(a)'):
        ax.text(0.5, 0.12, '春季与秋季曲线重合', transform=ax.transAxes, ha='center', fontsize=6.5, color='#333333')
    ax.set_xlim(1, 24); ax.set_xticks([1, 6, 12, 18, 24])
    ax.set_ylim(bottom=0)
    ax.set_xlabel('时段/h', labelpad=1); ax.set_ylabel('功率/MW', labelpad=1)
    ax.set_title(title, fontsize=7, pad=2)
    ax.grid(True, color='#E3E3E3', lw=0.4); ax.set_axisbelow(True)
    ax.tick_params(length=2, pad=1.5)
axs[-1].axis('off')
h, l = axs[0].get_legend_handles_labels()
axs[-1].legend(h, l, loc='center', frameon=False, fontsize=7, handlelength=2.2, labelspacing=0.8)
fig.tight_layout(pad=0.3, h_pad=0.6, w_pad=0.6)
fig.savefig(OUT, dpi=600)
print('ok')
