"""Four-season typical days built from the paper's base case (taken as the winter heating-season day).
Scale factors follow northern-China seasonal patterns; replace with measured profiles if available."""
import copy
import numpy as np

SEASONS = {
    #          days  wind  pv    elec  res   ind
    'spring': (92, 1.15, 1.40, 0.90, 0.40, 1.00),
    'summer': (92, 0.75, 1.60, 1.10, 0.12, 1.00),
    'autumn': (91, 0.95, 1.20, 0.90, 0.30, 1.00),
    'winter': (90, 1.00, 1.00, 1.00, 1.00, 1.00),
}
NAMES_CN = {'spring': '春季', 'summer': '夏季', 'autumn': '秋季', 'winter': '冬季'}


def season_data(base, season):
    days, w, pv, el, res, ind = SEASONS[season]
    d = copy.deepcopy(base)
    d['Gen_New_P'] = d['Gen_New_P'] * np.array([[w], [pv]])
    d['Pd'] = d['Pd'] * el
    d['Qre_dem_m'] = d['Qre_dem_m'] * res
    d['Qin_dem'] = d['Qin_dem'] * ind
    if res < 1:
        # outside the heating season the residential boilers are not must-run
        d['Qw_min'] = np.zeros_like(d['Qw_min'])
    return d
