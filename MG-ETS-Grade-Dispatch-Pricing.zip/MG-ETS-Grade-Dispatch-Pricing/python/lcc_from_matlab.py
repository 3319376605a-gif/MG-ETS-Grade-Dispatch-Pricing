"""Re-run the lifecycle accounting on the MATLAB four-season results (paper Sec. 4.6).
Usage: python lcc_from_matlab.py <case.xlsx> <mat_results dir>"""
import sys, os
import numpy as np, scipy.io as sio
import lcc_season as lc, seasons as se, run_cases as rc, ets_model as em

X, MR = sys.argv[1], sys.argv[2]
F = ['E', 'Pes', 'Qdis', 'Q_i2j', 'Q_i2k', 'Q_i2n', 'Pn', 'Pg', 'Ptu', 'Qtu_c', 'Qtu_h', 'Qtu_r',
     'Qs', 'Qw', 'Q_s2k', 'Pbuy', 'Psell']


def conv(R, I, J, K, S):
    r = {k: np.atleast_1d(np.asarray(getattr(R, k), float)) for k in F}
    r['Q_i2j'] = r['Q_i2j'].reshape(I, J, -1); r['Q_i2k'] = r['Q_i2k'].reshape(I, K, -1)
    r['Q_s2k'] = r['Q_s2k'].reshape(S, K, -1)
    for k in ['E', 'Pes', 'Qdis', 'Q_i2n']:
        r[k] = r[k].reshape(I, -1)
    r['obj'] = float(R.Objective)
    r['pi_bus'] = np.asarray(R.ElecPrices.pi_bus, float)
    r['pi_tu'] = np.atleast_2d(R.HeatPrices.pi_tu).astype(float)
    r['pi_in'] = np.atleast_2d(R.HeatPrices.pi_in).astype(float)
    r['pi_node'] = np.asarray(R.HeatPrices.pi_node, float)
    return r


base = em.read_config(X); base['c_curt'] = lc.C_CURT
runs, datas = {}, {}
for s in lc.SEAS:
    for n in lc.GRADE_CASES:
        d = rc.build(se.season_data(base, s), n)
        R = sio.loadmat(os.path.join(MR, 'season', f'{s}_{n}.mat'), squeeze_me=True, struct_as_record=False)['results']
        runs[(s, n)] = conv(R, d['I'], d['J'], d['K'], d['S']); datas[(s, n)] = d
df, _ = lc.evaluate(runs, datas, lc.GRADE_CASES)
cols = ['name', 'capex', 'capex_hx', 'hx_share', 'hxP', 'EAC', 'op', 'curt_GWh', 'saving_y', 'NPV', 'IRR', 'payback',
        'NPV_nocurt', 'IRR_nocurt']
import pandas as pd
pd.set_option('display.width', 250)
print(df[cols].round(4).to_string())
