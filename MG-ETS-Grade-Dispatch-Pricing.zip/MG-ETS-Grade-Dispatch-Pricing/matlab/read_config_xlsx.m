function data = read_config_xlsx(xlsxPath)


meta = readtable(xlsxPath, 'Sheet', 'Meta', 'TextType', 'string');
getv = @(k) meta.Value(meta.Key==k);

data.T        = double(getv("T"));
data.dt       = double(getv("dt"));
data.NB       = double(getv("NB"));
data.Nheat    = double(getv("Nheat"));
data.SlackBus = double(getv("SlackBus"));
data.BigM     = double(getv("BigM"));
data.Solver   = char(getv("Solver"));
% 新能源单位弃电成本（元/MWh）；Meta 表无该行时取 0，即原模型
c = double(getv("c_curt"));
if isempty(c) || isnan(c), c = 0; end
data.c_curt   = c;

% ---------- 电网：线路 ----------
lines = readtable(xlsxPath, 'Sheet', 'Elec_Lines');
data.L = height(lines);
data.line_from = double(lines.from_bus);
data.line_to   = double(lines.to_bus);
data.line_x    = double(lines.x_pu);
data.line_Pmax = double(lines.Pmax_MW);

% ---------- 电网：负荷 Pd(bus,t) ----------
Pd_tbl = readtable(xlsxPath, 'Sheet', 'Elec_Load_Pd');
data.Pd = table2array(Pd_tbl(:,2:end));  % NB x T

%--------------- 上级电网---------------
upper = readtable(xlsxPath, 'Sheet', 'upper_level_power_grid');
data.busUp = double(upper.bus);
data.Pbuy_max = double(upper.Pbuy_max);
data.Psell_max = double(upper.Psell_max);
data.Pbuy_ramp_down = double(upper.ramp_down);
data.Pbuy_ramp_up = double(upper.ramp_up);
upper_price = readtable(xlsxPath, 'Sheet', 'upper_level_price');
data.price_buy    = double(upper_price.price_buy(:));
data.price_sell   = double(upper_price.price_sell(:));

% ---------- 汽轮机（可接受供热） ----------
tu = readtable(xlsxPath, 'Sheet', 'Gen_Turbine');
data.J = height(tu);
data.busTu    = double(tu.bus);
data.nTu = double(tu.heat_node); 
data.Ptu_min  = double(tu.Pmin_MW);
data.Ptu_max  = double(tu.Pmax_MW);
data.Ptu_ramp_up  = double(tu.ramp_up);
data.Ptu_ramp_down  = double(tu.ramp_down);

data.Qtu_h_min = double(tu.Qtu_h_min);
data.Qtu_h_max = double(tu.Qtu_h_max);

data.Qtu_c_min = double(tu.Qtu_c_min);
data.Qtu_c_max = double(tu.Qtu_c_max);

data.Qtu_r_min = double(tu.Qtu_r_min);
data.Qtu_r_max = double(tu.Qtu_r_max);

data.P_cond = double(tu.P_cond);
data.k_cond = double(tu.k_cond);
data.P_bp   = double(tu.P_bp);
data.k_bp   = double(tu.k_bp);

data.a_tu     = double(tu.a_cost);
data.a2_tu     = double(tu.a2_cost);
data.k_tu     = double(tu.k_heat_credit);
data.k_tu2     = double(tu.k_heat_credit2);

% ---------- 修正后的单变量燃料成本系数 ----------
% 燃料成本只对锅炉燃料汽 H^FH(=Qtu_c)计费： C^CHP = a_j*(H^FH)^2 + b_j*H^FH
%   b_j = a_cost  (一次系数), a_j = a2_cost (二次系数)
% 系数按"CHP单位电边际燃料成本"锚定: b = (目标单位电成本)*cv，使CHP发电成本
% 低于常规机组、体现联产经济优势（详见 Gen_Turbine 表 a_cost/a2_cost 列）。
% H^FH>=0 (Qtu_c_min>=0) 保证成本非负，彻底消除原 P^EQ 五参数写法的负成本问题。
data.CHP_b = data.a_tu;    % 一次系数 b_j  <- a_cost
data.CHP_a = data.a2_tu;   % 二次系数 a_j  <- a2_cost
% ---------- 传统发电机 ----------
g = readtable(xlsxPath, 'Sheet', 'Gen_Other');
data.G = height(g);
data.busG   = double(g.bus);
data.Pg_min = double(g.Pmin_MW);
data.Pg_max = double(g.Pmax_MW);
data.Pg_ramp_up  = double(g.ramp_up);
data.Pg_ramp_down  = double(g.ramp_down);
data.a_g    = double(g.a_cost);
data.a2_g    = double(g.a2_cost);

% ---------- 新能源 ----------
g_n = readtable(xlsxPath, 'Sheet', 'Gen_New');
data.G_N       = height(g_n);
data.busG_N    = double(g_n.bus);
data.a_n       = double(g_n.a_cost);
Gen_New = readtable(xlsxPath, 'Sheet', 'Gen_New_P');
data.Gen_New_P = table2array(Gen_New(:,2:end));

% ---------- 蓄热体 ----------
st = readtable(xlsxPath, 'Sheet', 'Storage');
data.I = height(st);
data.busES   = double(st.bus);
data.nI      = double(st.heat_node);

data.E0   = double(st.E0);
data.Emin = double(st.Emin);
data.Emax = double(st.Emax);
data.EL   = double(st.EL);
data.EH   = double(st.EH);

data.eta_loss  = double(st.eta_loss);
data.eta_ch  = double(st.eta_ch);
data.eta_dis = double(st.eta_dis);
data.eta_eh  = double(st.eta_eh);

data.Pes_min   = double(st.Pmin);
data.Pes_max   = double(st.Pmax);
data.Qdis_min  = double(st.Qdis_min);
data.Qdis_max  = double(st.Qdis_max);

data.Q_tu_max  = double(st.Qtu_max);
data.Q_in_max  = double(st.Qin_max);
data.Q_re_max  = double(st.Qre_max);

data.gamma_tu  = double(st.gamma_tu);
data.gamma_in  = double(st.gamma_in);
data.gamma_re  = double(st.gamma_re);

% ---------- 连接矩阵 ----------
A_i2j = readtable(xlsxPath, 'Sheet', 'Conn_i2j');
data.A_i2j = table2array(A_i2j(:,2:end));

A_i2k = readtable(xlsxPath, 'Sheet', 'Conn_i2k');
data.A_i2k = table2array(A_i2k(:,2:end));

% ---------- 工业负荷需求 ----------
indDem = readtable(xlsxPath, 'Sheet', 'Ind_Load_Demand');
data.K = height(indDem);
data.Qin_dem = table2array(indDem(:,2:end));

% ---------- 工业锅炉 ----------
boiInd = readtable(xlsxPath, 'Sheet', 'Boiler_Ind');
data.S = height(boiInd);
data.Qs_min = double(boiInd.Qmin);
data.Qs_max = double(boiInd.Qmax);
data.gamma_GB_ind = double(boiInd.gamma_GB_ind);
data.gamma_GB_ind_2 = double(boiInd.gamma_GB_ind_2);

A_s2k = readtable(xlsxPath, 'Sheet', 'Conn_s2k');
data.A_s2k = table2array(A_s2k(:,2:end));

% ---------- 居民锅炉（接入热网） ----------
boiRes = readtable(xlsxPath, 'Sheet', 'Boiler_Res');
data.W = height(boiRes);
data.nW = double(boiRes.heat_node);
data.Qw_min = double(boiRes.Qmin);
data.Qw_max = double(boiRes.Qmax);
data.gamma_GB_res = double(boiRes.gamma_GB_res);
data.gamma_GB_res_2 = double(boiRes.gamma_GB_res_2);

% ---------- 居民负荷（接入热网节点） ----------
resMap = readtable(xlsxPath, 'Sheet', 'Res_Load');
data.M = height(resMap);
data.nM = double(resMap.heat_node);

resDem = readtable(xlsxPath, 'Sheet', 'Res_Load_Demand');
data.Qre_dem_m = table2array(resDem(:,2:end));

% ---------- 热网节点参数 ----------
hn = readtable(xlsxPath, 'Sheet', 'Heat_Nodes');
data.mcir = double(hn.mcir);
data.cw   = double(hn.cw);
data.Tsup_min = double(hn.Tsup_min);
data.Tsup_max = double(hn.Tsup_max);
data.Tret_min = double(hn.Tret_min);
data.Tret_max = double(hn.Tret_max);

% ---------- 热网拓扑：供水/回水边 ----------
supE = readtable(xlsxPath, 'Sheet', 'Heat_Edges_Sup');
retE = readtable(xlsxPath, 'Sheet', 'Heat_Edges_Ret');

data.Es = height(supE);
data.Er = height(retE);

data.sup_from = double(supE.from_node);
data.sup_to   = double(supE.to_node);
data.sup_m    = double(supE.m_flow);
data.sup_len  = double(supE.length);

data.ret_from = double(retE.from_node);
data.ret_to   = double(retE.to_node);
data.ret_m    = double(retE.m_flow);
data.ret_len  = double(retE.length);

% ---------- 热网温度损耗 ----------
loss = readtable(xlsxPath, 'Sheet', 'temperature_loss');
data.T_out_pipeline_equivalent  = double(loss.T_out_pipeline_equivalent);
data.Heat_transfer_rate         = double(loss.Heat_transfer_rate);

end
