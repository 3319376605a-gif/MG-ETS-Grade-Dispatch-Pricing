%RUN_ALL  一键复现论文第4节及附录B、C的全部算例
%  4.4节  7 种可供热品级配置（表1、表2）；共享容量池 vs 专用分置（表3）
%  4.5节  四季典型日调度与定价（图7~图9）
%  4.6节  全寿命周期经济性（图10）
%  附录B  四季负荷与新能源出力曲线（图B1）；放热成本系数取值影响（表B8、表B9）
%  附录C  关键参数敏感性分析（表C1、表C2）
%  依赖：YALMIP + Gurobi。全部运行约 2~3 h，四季与敏感性部分可断点续跑。
%  4.2、4.3节基准日结果图另见 main.m、plot_section42_figures.m、plot_heat_prices_journal.m、plot_elec_prices_journal.m。
clear; clc;
X = 'case_14bus_6heat.xlsx';

% ---- 4.4节：表1、表2（7 种品级配置）与表3（共享池 vs 专用分置）----
run_grade_comparison(X);
run_pool_vs_partition(X, 'standard');
run_pool_vs_partition(X, 'reuse', struct('windScale',1.2,'resScale',2.0,'indScale',0.3));   % 论文4.4节场景二

% ---- 附录B7：放热成本系数取值影响 ----
run_degr_sensitivity(X);

% ---- 4.5、4.6节：四季典型日与全寿命周期 ----
run_four_seasons(X);
lcc_four_season(X);

% ---- 附录C：关键参数敏感性分析 ----
run_param_sensitivity(X);

% ---- 4.5、4.6节图与附录B 图B1 ----
plot_season_figures(X);
plot_fig_B1(X);
