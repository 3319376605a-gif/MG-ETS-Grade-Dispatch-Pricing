function results = solve_dispatch_milp(data)

% ---------- 构建 & 求解 MILP ----------
[model, handles] = build_model(data, []);  % [] 表示不固定 y
% 相对最优间隙 1e-4（Gurobi 默认值，显式写出以与论文附录B表B1一致）
ops = sdpsettings('solver', 'gurobi', 'verbose', 1, 'gurobi.MIPGap', 1e-4);
optimize(model.C, model.obj, ops);
results = collect_results(data, model, handles);
results.Objective = value(model.obj);

% ---------- S4: 固定整数变量 -> 连续子问题，取对偶作为热价 ----------
y_fix.yL = round(value(handles.yL));
y_fix.yM = round(value(handles.yM));
y_fix.yH = round(value(handles.yH));

[model2, handles2] = build_model(data, y_fix);

ops2 = sdpsettings('solver', 'gurobi', 'verbose', 0);
optimize(model2.C, model2.obj, ops2);

prices = struct();
prices.pi_tu = zeros(data.J, data.T);      
prices.pi_in = zeros(data.K, data.T);      

nSrc = length(handles2.src_nodes);
nLoad = length(handles2.load_nodes);

prices.pi_node = nan(data.Nheat, data.T);


for j = 1:data.J
    for t = 1:data.T
        prices.pi_tu(j,t) = value(dual(handles2.con_tu{j,t}));
    end
end
for k = 1:data.K
    for t = 1:data.T
        prices.pi_in(k,t) = value(dual(handles2.con_in{k,t}));
    end
end


N = data.Nheat;
T = data.T;

prices.pi_node_src  = nan(N,T);   % 仅热源节点价格（按节点号）
prices.pi_node_load = nan(N,T);   % 仅负荷节点价格（按节点号）
prices.pi_node      = nan(N,T);   % 节点热价汇总（只填源/荷节点）

% --- 源节点（按节点号写入 pi_node_src）---
for a = 1:length(handles2.src_nodes)
    n = handles2.src_nodes(a);
    for t = 1:T
        lam = value(dual(handles2.con_src{a,t}));
        % build_model 中源节点约束写成 Qsrc == cw*m*(Ts-Tr)，其对偶与边际热价反号，故取负号
        prices.pi_node_src(n,t) = -lam;
    end
end

% --- 荷节点（按节点号写入 pi_node_load）---
for b = 1:length(handles2.load_nodes)
    n = handles2.load_nodes(b);
    for t = 1:T
        lam = value(dual(handles2.con_load{b,t}));
        prices.pi_node_load(n,t) = lam;
    end
end

% --- 合并源/荷节点（中间节点无热价）---
prices.pi_node = prices.pi_node_src;

idx = isnan(prices.pi_node);
prices.pi_node(idx) = prices.pi_node_load(idx);

results.HeatPrices = prices;
% ---------- S4(补充): 固定整数变量后的连续子问题，取对偶作为“分时节点电价” ----------
prices_elec = struct();
prices_elec.pi_bus = nan(data.NB, data.T);   % NB x T

for t = 1:data.T
    for u = 1:data.NB
        lam = value(dual(handles2.con_elec{u,t}));
        % 符号约定：功率平衡写成 Pg - Pd - Pes == Pinj，负荷 Pd 增加 1 MW 的边际成本对应 -lam
        prices_elec.pi_bus(u,t) = -lam;

        % 若目标函数改为“成本 * 功率 * dt”，此处需除以 dt 才是 元/MWh
    end
end

results.ElecPrices = prices_elec;


end


