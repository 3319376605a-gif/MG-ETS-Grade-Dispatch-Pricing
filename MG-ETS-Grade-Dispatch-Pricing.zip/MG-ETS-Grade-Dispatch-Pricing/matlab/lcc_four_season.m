function [L, A] = lcc_four_season(xlsxPath)
%LCC_FOUR_SEASON  计及高温换热设备投资的全寿命周期经济性核算（论文4.6节）
%  需先运行 run_four_seasons。
%  等年值总成本  EAC = C_inv*CRF(r,Ny) + k_om*C_inv + sum_s N_s*C_s^op
%  C_s^op 为季节 s 典型日运行成本（含弃电成本），扣除电蓄热等效成本项（gamma_*×放热量）：
%  该项是设备投资按寿命期累计放热量的分摊值，投资已在期初计入，不重复计算。
%  NPV/IRR/动态回收期以无电蓄热系统为基准，年收益 = 年运行成本节约 - 固定运维。
%  输出 L：各配置核算结果表（万元）；A：四季结算明细。
if nargin < 1 || isempty(xlsxPath), xlsxPath = 'case_14bus_6heat.xlsx'; end
p = lcc_params();
S = season_table();
CASES = {'NoETS','PIB','IB','PB','PI','B','I','P'};
base = read_config_xlsx(xlsxPath);
c_curt = base.c_curt;

% ---- 读结果、结算 ----
A = struct();
for s = 1:numel(S)
    for c = 1:numel(CASES)
        X = load(fullfile('mat_results','season', sprintf('%s_%s.mat', S(s).name, CASES{c})));
        a = settle_results(X.results, X.d);
        a.obj  = X.results.Objective;
        a.curt = sum(X.d.Gen_New_P(:)) - sum(X.results.Pn(:));
        a.pk   = hx_peaks(X.results);                    % I x 3 各台各品级最大放热功率
        a.R = X.results; a.d = X.d;
        A.(S(s).name).(CASES{c}) = a;
    end
end
days = [S.days];
yr = @(f, n) sum(arrayfun(@(k) days(k) * f(A.(S(k).name).(n)), 1:numel(S))) / 1e4;   % 万元/a

opf = @(a) a.obj - a.ETS_degr;
base_op = yr(opf, 'NoETS');
base_cc = yr(@(a) c_curt*a.curt, 'NoETS');
crf = p.r*(1+p.r)^p.life / ((1+p.r)^p.life - 1);
kf  = (1 + p.k_c) * (1 + p.k_e);

nC = numel(CASES);
V = nan(nC, 18);
for c = 1:nC
    n = CASES{c};
    if strcmp(n, 'NoETS')
        cap = zeros(1,5); hxMW = [0 0 0];
    else
        pk = zeros(size(A.(S(1).name).(n).pk));
        for s = 1:numel(S), pk = max(pk, A.(S(s).name).(n).pk); end
        per = ceil(round(pk, 6) / 10) * 10;              % 按台、按品级向上取整至 10 MW
        hxMW = sum(per, 1);
        multi = sum(sum(per > 0, 2) >= 2);               % 具备两个及以上品级回路的台数
        hx = hxMW .* 1e3 .* [p.c_hx.P, p.c_hx.I, p.c_hx.B] / 1e4;
        loop = p.multi_loop * sum(hx) * multi / p.n_dev;
        store  = kf * p.n_dev * p.E * 1e3 * p.c_store / 1e4;
        heater = kf * p.n_dev * p.Pe * p.eta_eh * 1e3 * p.c_heater / 1e4;
        cap = [store, heater, kf*(sum(hx)+loop), kf*hx(1), kf*hx(2)];   % 储热体 加热器 换热设备 其中发电级 工业级
    end
    tot = sum(cap(1:3)); ann = tot * crf; om = p.om_fix * tot;
    op = yr(opf, n); cc = yr(@(a) c_curt*a.curt, n);
    curtGWh = yr(@(a) a.curt, n) * 1e4 / 1e3;
    row = [tot, cap(3), cap(3)/max(tot,eps), hxMW, ann, om, op, cc, ann+om+op, curtGWh, nan(1,6)];
    if ~strcmp(n, 'NoETS')
        sav = base_op - op - om;
        cf  = [-tot, repmat(sav, 1, p.life)];
        cf0 = [-tot, repmat(sav - (base_cc - cc), 1, p.life)];   % 不计弃电成本
        row(13:18) = [sav, npv(cf, p.r), irr(cf), payback(cf, p.r), npv(cf0, p.r), irr(cf0)];
    end
    V(c,:) = row;
end
L = array2table(V, 'RowNames', CASES, 'VariableNames', ...
    {'初始投资','换热设备投资','换热设备占比','发电级换热_MW','工业级换热_MW','建筑级换热_MW', ...
     '投资年值','固定运维','年运行成本','其中弃电成本','等年值总成本','年弃电量_GWh', ...
     '年净收益','NPV','IRR','动态回收期_a','NPV_不计弃电','IRR_不计弃电'});
disp(L);
writetable(L, 'results_summary.xlsx', 'Sheet', '4.6全寿命周期', 'WriteRowNames', true, 'WriteMode', 'overwritesheet');
save(fullfile('mat_results','lcc_four_season.mat'), 'L', 'p');
end

% ---------------------------------------------------------------
function pk = hx_peaks(R)
I = size(R.Q_i2n, 1); T = size(R.Q_i2n, 2);
pk = zeros(I, 3);
for i = 1:I
    pk(i,1) = max(sum(reshape(R.Q_i2j(i,:,:), [], T), 1));
    pk(i,2) = max(sum(reshape(R.Q_i2k(i,:,:), [], T), 1));
    pk(i,3) = max(R.Q_i2n(i,:));
end
pk = max(pk, 0);
end

function v = npv(cf, r)
v = sum(cf ./ (1 + r).^(0:numel(cf)-1));
end

function x = irr(cf)
lo = -0.99; hi = 1.0;
if npv(cf, hi) > 0 || npv(cf, lo) < 0, x = NaN; return; end
for k = 1:200
    x = (lo + hi)/2;
    if npv(cf, x) > 0, lo = x; else, hi = x; end
end
end

function y = payback(cf, r)
acc = 0; y = NaN;
for k = 1:numel(cf)
    prev = acc; acc = acc + cf(k) / (1 + r)^(k-1);
    if k > 1 && acc >= 0, y = (k-2) + (-prev)/(acc - prev); return; end
end
end
