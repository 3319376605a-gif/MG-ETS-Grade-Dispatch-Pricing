function d = build_case(d, name)
%BUILD_CASE  电蓄热配置：'NoETS'（无电蓄热）或可供热品级组合 'PIB','IB','PB','PI','B','I','P'
%  品级关断方式与 run_grade_comparison.m 相同（断开对应品级的连接/管道）。
if strcmp(name, 'NoETS')
    f = {'Pes_max','Qdis_max','Emin','EL','EH','E0','Emax','Q_tu_max','Q_in_max','Q_re_max'};
    for k = 1:numel(f), d.(f{k}) = zeros(size(d.(f{k}))); end
    return
end
if ~any(name == 'P'), d.A_i2j = zeros(size(d.A_i2j)); d.Q_tu_max = zeros(size(d.Q_tu_max)); end
if ~any(name == 'I'), d.A_i2k = zeros(size(d.A_i2k)); d.Q_in_max = zeros(size(d.Q_in_max)); end
if ~any(name == 'B'), d.Q_re_max = zeros(size(d.Q_re_max)); end
end
