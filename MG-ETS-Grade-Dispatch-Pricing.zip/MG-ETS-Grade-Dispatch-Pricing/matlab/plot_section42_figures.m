function plot_section42_figures()
%PLOT_SECTION42_FIGURES  论文4.2节系统调度结果图（拆分为独立小图）
%  需先运行 main.m 生成 mat_results/results.mat。
%
% 字体策略（正确方案）：
%   在同一字符串内用 \fontname{} 内联切换字体，例如：
%     '\fontname{宋体}时间/\fontname{Times New Roman}h'
%   这样中文用宋体、数字/字母用新罗马，彻底解决方框问题。
%   坐标轴刻度（纯数字）通过 set(ax,'FontName','Times New Roman') 设置。
%   图例文字（纯中文）通过 legend(...,'FontName','宋体') 设置。

%% ==================== 参数设置 ====================
resultsPath = fullfile('mat_results','results.mat');
xlsxPath    = 'case_14bus_6heat.xlsx';
outDir      = 'figs_section42_split';

if ~exist(outDir, 'dir'), mkdir(outDir); end

%% ==================== 加载数据 ====================
S    = load(resultsPath);
R    = S.results;
data = read_config_xlsx(xlsxPath);
T    = data.T;

%% ==================== 全局绘图设置 ====================
% 内联字体切换宏，方便复用
CN  = '\fontname{宋体}';
TNR = '\fontname{Times New Roman}';
FS  = '\fontsize{20}';   % 统一字号

% 常用混合标签（中文部分用宋体，字母/单位用新罗马）
LBL_POWER_MW  = [FS, CN, '功率/',    TNR, 'MW'];
LBL_HEAT_MW   = [FS, CN, '热功率/',  TNR, 'MW'];
LBL_ELEC_MW   = [FS, CN, '电功率/',  TNR, 'MW'];
LBL_ENERGY    = [FS, CN, '储能量/',  TNR, 'MWh'];
LBL_TIME_H    = [FS, CN, '时刻'];

fontSize_tick = 20;

% 颜色方案
colors = struct();
% 电蓄热
colors.charge        = [0.929, 0.490, 0.192];
colors.discharge_tu  = [0.180, 0.545, 0.549];
colors.discharge_ind = [0.557, 0.267, 0.537];
colors.discharge_res = [0.843, 0.522, 0.522];
colors.energy_line   = [0.122, 0.267, 0.537];
colors.band_high     = [0.957, 0.898, 0.898];
colors.band_mid      = [0.969, 0.949, 0.910];
colors.band_low      = [0.910, 0.945, 0.969];
% 热电联产机组（原始配色）
colors.Qtu_c         = [0.929, 0.490, 0.192];
colors.Qtu_r         = [0.180, 0.545, 0.549];
colors.Qtu_h         = [0.843, 0.522, 0.522];
% 工业热（原始配色）
colors.ind_boiler    = [0.929, 0.490, 0.192];
colors.ind_TS        = [0.180, 0.545, 0.549];
% 居民热（原始配色）
colors.res_boiler    = [0.929, 0.686, 0.133];
colors.res_TS        = [0.557, 0.267, 0.537];
colors.res_tu        = [0.180, 0.600, 0.502];
% 电侧（改为与热侧同色系）
colors.turbine       = [0.929, 0.490, 0.192];   % 橙（同燃料供热）
colors.other_gen     = [0.329, 0.431, 0.639];   % 钢蓝
colors.renewable     = [0.302, 0.686, 0.290];   % 翠绿
colors.grid_buy      = [0.929, 0.686, 0.133];   % 金
colors.es_charge     = [0.557, 0.267, 0.537];   % 紫
colors.load_line     = [0.122, 0.267, 0.537];
colors.gray_dark     = [0.35, 0.35, 0.35];
colors.gray_light    = [0.55, 0.55, 0.55];
colors.zero_line     = [0.50, 0.50, 0.50];

%% ==================== 图形尺寸 ====================
figW   = 24; figH = 10;
axPos  = [0.12, 0.24, 0.78, 0.52];
legPos = [0.08, 0.80, 0.84, 0.08];

lbl = struct('POWER_MW', LBL_POWER_MW, 'HEAT_MW', LBL_HEAT_MW, ...
             'ELEC_MW', LBL_ELEC_MW, 'ENERGY', LBL_ENERGY, 'TIME_H', LBL_TIME_H);

%% ==================== 绘图 ====================

% (a) 电侧
fig_a = create_figure(figW, figH);
axes('Position', axPos);
plot_electric_dispatch(gca, R, T, data, colors, lbl, fontSize_tick, legPos);
make_draggable_texts(fig_a);
save_figure(fig_a, outDir, 'Fig_a_Electric_Dispatch');

% (b) 电蓄热：两个电蓄热分开绘制
% data/results 中有几个电蓄热就自动画几个；本算例 Ni = 2，输出 b1 和 b2。
Ni_TS = size(R.E, 1);
for iTS = 1:Ni_TS
    fig_b = create_figure(figW, figH);
    axes('Position', axPos);
    plot_thermal_storage_one(gca, R, T, data, colors, lbl, fontSize_tick, legPos, iTS);
    make_draggable_texts(fig_b);
    save_figure(fig_b, outDir, sprintf('Fig_b%d_ThermalStorage_i%d', iTS, iTS));
end

% 如果还想保留两个电蓄热合并后的总图，取消下面5行注释即可：
% fig_b_sum = create_figure(figW, figH);
% axes('Position', axPos);
% plot_thermal_storage_sum(gca, R, T, data, colors, lbl, fontSize_tick, legPos);
% make_draggable_texts(fig_b_sum);
% save_figure(fig_b_sum, outDir, 'Fig_b_ThermalStorage_sum');

% (c) 热电联产
fig_c = create_figure(figW, figH);
axes('Position', axPos);
plot_turbine_sum(gca, R, T, colors, lbl, fontSize_tick, legPos);
make_draggable_texts(fig_c);
save_figure(fig_c, outDir, 'Fig_c_Turbine');

% (d) 工业热
fig_d = create_figure(figW, figH);
axes('Position', axPos);
plot_industrial_heat(gca, R, T, data, colors, lbl, fontSize_tick, legPos);
make_draggable_texts(fig_d);
save_figure(fig_d, outDir, 'Fig_d_IndustrialHeat');

% (e) 居民热
fig_e = create_figure(figW, figH);
axes('Position', axPos);
plot_residential_heat(gca, R, T, data, colors, lbl, fontSize_tick, legPos);
make_draggable_texts(fig_e);
save_figure(fig_e, outDir, 'Fig_e_ResidentialHeat');

fprintf('\n所有图已保存至: %s\n', outDir);
end

%% ================================================================
%  辅助函数
% ================================================================
function fig = create_figure(w, h)
    fig = figure('Units','centimeters','Position',[2 2 w h],'Color','w',...
                 'PaperPositionMode','auto','Resize','on');
end

function fix_legend(ax, entries, legPos, nCol)
    % 图例文字为纯中文，直接设宋体即可，无需内联切换
    lgd = legend(ax, entries, 'Orientation','horizontal', ...
        'NumColumns',nCol, 'FontName','宋体', 'FontSize',20, 'Box','off');
    lgd.ItemTokenSize = [14, 8];
    set(lgd, 'Units','normalized', 'Position', legPos);
end

function save_figure(fig, outDir, filename)
    exportgraphics(fig, fullfile(outDir,[filename '.png']), 'Resolution',600);
    exportgraphics(fig, fullfile(outDir,[filename '.pdf']), 'ContentType','vector');
    saveas(fig, fullfile(outDir,[filename '.fig']));
    fprintf('已保存: %s\n', filename);
end

%% ================================================================
%  文字拖动
% ================================================================
function make_draggable_texts(fig)
    allTexts = findall(fig, 'Type', 'text');
    for i = 1 : numel(allTexts)
        th = allTexts(i);
        if isempty(strtrim(get(th, 'String'))), continue; end
        set(th, 'ButtonDownFcn', @(src, ~) drag_start(src, fig));
    end
end

function drag_start(hText, fig)
    set(hText, 'Units', 'normalized');
    origPos    = get(hText, 'Position');
    mouseStart = get_mouse_normalized(fig);
    fig.UserData = struct('hText',hText,'origPos',origPos,'mouseStart',mouseStart);
    set(fig, 'WindowButtonMotionFcn', @(s,~) drag_move(s), ...
             'WindowButtonUpFcn',     @(s,~) drag_stop(s), ...
             'Pointer', 'fleur');
end

function drag_move(fig)
    ds = fig.UserData;
    if isempty(ds) || ~isfield(ds,'hText'), return; end
    d  = get_mouse_normalized(fig) - ds.mouseStart;
    np = ds.origPos; np(1) = np(1)+d(1); np(2) = np(2)+d(2);
    set(ds.hText, 'Units','normalized', 'Position', np);
end

function drag_stop(fig)
    fig.UserData = [];
    set(fig, 'WindowButtonMotionFcn','', 'WindowButtonUpFcn','', 'Pointer','arrow');
end

function pos = get_mouse_normalized(fig)
    fp = get(fig,'Position');
    cp = get(fig,'CurrentPoint');
    pos = [cp(1)/fp(3), cp(2)/fp(4)];
end

%% ================================================================
%  子函数：电侧
% ================================================================
function plot_electric_dispatch(ax, R, T, data, colors, lbl, fsTick, legPos)
    axes(ax); t = 1:T;
    Ptu_sum = sum(R.Ptu(:,1:T), 1);
    Pg_sum  = sum(R.Pg(:,1:T),  1);
    Pn_sum  = sum(R.Pn(:,1:T),  1);
    if isvector(R.Pbuy)
        Pbuy_arr = R.Pbuy(1:T);
    else
        Pbuy_arr = sum(R.Pbuy(:,1:T), 1);
    end
    Pbuy_arr   = Pbuy_arr(:)';
    Pes_charge = sum(max(R.Pes(:,1:T), 0), 1);
    Pd_total   = sum(data.Pd(:,1:T), 1);

    hold(ax,'on');
    Y = [Ptu_sum(:), Pg_sum(:), Pn_sum(:), Pbuy_arr(:)];
    bh = bar(ax,t,Y,0.8,'stacked','EdgeColor','none','FaceAlpha',0.92);
    bh(1).FaceColor = colors.turbine;
    bh(2).FaceColor = colors.other_gen;
    bh(3).FaceColor = colors.renewable;
    bh(4).FaceColor = colors.grid_buy;
    bar(ax,t,-Pes_charge,0.8,'FaceColor',colors.es_charge,'EdgeColor','none','FaceAlpha',0.75);
    yline(ax,0,'-','Color',colors.zero_line,'LineWidth',0.6,'HandleVisibility','off');
    plot(ax,t,Pd_total,'-o','Color',[0.15 0.15 0.15],'LineWidth',1.8,...
         'MarkerSize',4,'MarkerFaceColor','w','MarkerEdgeColor',[0.15 0.15 0.15]);

    % 标签用 \fontname{} 内联切换
    ylabel(ax, lbl.POWER_MW, 'Color','k');
    xlabel(ax, lbl.TIME_H);
    xlim(ax,[0,T+0.5]); xticks(ax,[0,4,8,12,16,20,24]); xticklabels(ax,{'0:00','4:00','8:00','12:00','16:00','20:00','24:00'});
    yticks(ax,[-500,-250,0,250,500]);

    % 坐标轴刻度（纯数字）→ Times New Roman
    set(ax,'FontName','Times New Roman','FontSize',fsTick, ...
        'TickDir','in','Box','on','LineWidth',0.8,'XColor','k','YColor','k');

    fix_legend(ax,{'热电联产机组','常规机组','可再生能源','外网购电','电蓄热充电','电力负荷'},legPos,2);
    hold(ax,'off');
end

%% ================================================================
%  子函数：电蓄热
% ================================================================
function plot_thermal_storage_sum(ax, R, T, data, colors, lbl, fsTick, legPos)
    axes(ax); t = 1:T;
    Ni = size(R.E,1);
    Emin_sum = sum(data.Emin(1:Ni));
    Emax_sum = sum(data.Emax(1:Ni));
    EL_sum   = sum(data.EL(1:Ni));
    EH_sum   = sum(data.EH(1:Ni));
    E_sum       = sum(R.E(:,1:T),   1);
    Qcharge_sum = sum(R.Qch(:,1:T), 1);
    if ndims(R.Q_i2j)==3
        QtoJ = squeeze(sum(sum(R.Q_i2j(:,:,1:T),1),2))';
    else
        QtoJ = sum(R.Q_i2j(:,1:T),1);
    end
    QtoJ = QtoJ(:)';
    if ndims(R.Q_i2k)==3
        QtoK = squeeze(sum(sum(R.Q_i2k(:,:,1:T),1),2))';
    else
        QtoK = sum(R.Q_i2k(:,1:T),1);
    end
    QtoK = QtoK(:)';
    QtoN = sum(R.Q_i2n(:,1:T),1); QtoN = QtoN(:)';

    yyaxis(ax,'left'); hold(ax,'on');
    bar(ax,t,Qcharge_sum,0.8,'FaceColor',colors.charge,'EdgeColor','none','FaceAlpha',0.9);
    Y_neg = [-QtoJ(:),-QtoK(:),-QtoN(:)];
    bh = bar(ax,t,Y_neg,0.8,'stacked','EdgeColor','none','FaceAlpha',0.75);
    bh(1).FaceColor=colors.discharge_tu;
    bh(2).FaceColor=colors.discharge_ind;
    bh(3).FaceColor=colors.discharge_res;
    yline(ax,0,'-','Color',colors.zero_line,'LineWidth',0.6,'HandleVisibility','off');
    ylabel(ax, lbl.HEAT_MW, 'Color','k');
    ap = [Qcharge_sum(:); sum(Y_neg,2)];
    ylim(ax,[min(min(ap)*1.1,-10), max(max(ap)*1.1,10)]);
    ax.YColor='k';

    yyaxis(ax,'right');
    xF = [0,T+0.5,T+0.5,0];
    fill(ax,xF,[EH_sum,EH_sum,Emax_sum,Emax_sum],colors.band_high,'EdgeColor','none','FaceAlpha',0.4,'HandleVisibility','off');
    fill(ax,xF,[EL_sum,EL_sum,EH_sum,EH_sum],    colors.band_mid, 'EdgeColor','none','FaceAlpha',0.4,'HandleVisibility','off');
    fill(ax,xF,[Emin_sum,Emin_sum,EL_sum,EL_sum], colors.band_low,'EdgeColor','none','FaceAlpha',0.4,'HandleVisibility','off');
    plot(ax,t,E_sum,'-o','Color',colors.energy_line,'LineWidth',1.8,...
         'MarkerSize',4,'MarkerFaceColor','w','MarkerEdgeColor',colors.energy_line);
    yline(ax,Emin_sum,'-.','Color',colors.gray_dark, 'LineWidth',0.5,'HandleVisibility','off');
    yline(ax,Emax_sum,'-.','Color',colors.gray_dark, 'LineWidth',0.5,'HandleVisibility','off');
    yline(ax,EL_sum,  ':','Color', colors.gray_light,'LineWidth',0.6,'HandleVisibility','off');
    yline(ax,EH_sum,  ':','Color', colors.gray_light,'LineWidth',0.6,'HandleVisibility','off');
    ylabel(ax, lbl.ENERGY, 'Color','k');
    ylim(ax,[Emin_sum-30, Emax_sum+30]); ax.YColor='k';

    xlim(ax,[0,T+0.5]); xticks(ax,[0,4,8,12,16,20,24]); xticklabels(ax,{'0:00','4:00','8:00','12:00','16:00','20:00','24:00'});
    set(ax,'FontName','Times New Roman','FontSize',fsTick, ...
        'TickDir','in','Box','on','LineWidth',0.8,'XColor','k');
    fix_legend(ax,{'充热','热电联产机组放热','工业放热','居民放热','储能量'},legPos,5);
    xlabel(ax, lbl.TIME_H);
    hold(ax,'off');
end


%% ================================================================
%  子函数：单个电蓄热
% ================================================================
function plot_thermal_storage_one(ax, R, T, data, colors, lbl, fsTick, legPos, iTS)
    axes(ax); t = 1:T;
    Ni = size(R.E,1);
    if iTS < 1 || iTS > Ni
        error('电蓄热编号 iTS=%d 超出范围，当前共有 %d 个电蓄热。', iTS, Ni);
    end

    % 单个电蓄热的能量上下限与实际储能量
    Emin = data.Emin(iTS);
    Emax = data.Emax(iTS);
    EL   = data.EL(iTS);
    EH   = data.EH(iTS);
    E_one       = R.E(iTS,1:T);
    Qcharge_one = R.Qch(iTS,1:T);

    % 单个电蓄热向各类热用户放热：
    % R.Q_i2j: 电蓄热 i -> 热电联产机组 j
    % R.Q_i2k: 电蓄热 i -> 工业热负荷/工业节点 k
    % R.Q_i2n: 电蓄热 i -> 居民热负荷/居民节点 n
    QtoJ = sum_from_storage_to_time(R.Q_i2j, iTS, T);
    QtoK = sum_from_storage_to_time(R.Q_i2k, iTS, T);
    QtoN = sum_from_storage_to_time(R.Q_i2n, iTS, T);

    yyaxis(ax,'left'); hold(ax,'on');
    bar(ax,t,Qcharge_one,0.8,'FaceColor',colors.charge,'EdgeColor','none','FaceAlpha',0.9);
    Y_neg = [-QtoJ(:), -QtoK(:), -QtoN(:)];
    bh = bar(ax,t,Y_neg,0.8,'stacked','EdgeColor','none','FaceAlpha',0.75);
    bh(1).FaceColor = colors.discharge_tu;
    bh(2).FaceColor = colors.discharge_ind;
    bh(3).FaceColor = colors.discharge_res;
    yline(ax,0,'-','Color',colors.zero_line,'LineWidth',0.6,'HandleVisibility','off');
    ylabel(ax, lbl.HEAT_MW, 'Color','k');
    ap = [Qcharge_one(:); sum(Y_neg,2)];
    ylim(ax,[min(min(ap)*1.1,-10), max(max(ap)*1.1,10)]);
    ax.YColor = 'k';

    yyaxis(ax,'right');
    xF = [0,T+0.5,T+0.5,0];
    fill(ax,xF,[EH,EH,Emax,Emax],colors.band_high,'EdgeColor','none','FaceAlpha',0.4,'HandleVisibility','off');
    fill(ax,xF,[EL,EL,EH,EH],    colors.band_mid, 'EdgeColor','none','FaceAlpha',0.4,'HandleVisibility','off');
    fill(ax,xF,[Emin,Emin,EL,EL], colors.band_low, 'EdgeColor','none','FaceAlpha',0.4,'HandleVisibility','off');
    plot(ax,t,E_one,'-o','Color',colors.energy_line,'LineWidth',1.8, ...
         'MarkerSize',4,'MarkerFaceColor','w','MarkerEdgeColor',colors.energy_line);
    yline(ax,Emin,'-.','Color',colors.gray_dark, 'LineWidth',0.5,'HandleVisibility','off');
    yline(ax,Emax,'-.','Color',colors.gray_dark, 'LineWidth',0.5,'HandleVisibility','off');
    yline(ax,EL,  ':','Color', colors.gray_light,'LineWidth',0.6,'HandleVisibility','off');
    yline(ax,EH,  ':','Color', colors.gray_light,'LineWidth',0.6,'HandleVisibility','off');
    ylabel(ax, lbl.ENERGY, 'Color','k');
    ylim(ax,[Emin-30, Emax+30]); ax.YColor = 'k';

    xlim(ax,[0,T+0.5]);
    xticks(ax,[0,4,8,12,16,20,24]);
    xticklabels(ax,{'0:00','4:00','8:00','12:00','16:00','20:00','24:00'});
    set(ax,'FontName','Times New Roman','FontSize',fsTick, ...
        'TickDir','in','Box','on','LineWidth',0.8,'XColor','k');
    fix_legend(ax,{'充热','热电联产机组放热','工业放热','居民放热','储能量'},legPos,5);
    xlabel(ax, lbl.TIME_H);
    hold(ax,'off');
end

function y = sum_from_storage_to_time(Q, iTS, T)
    % 将“第 iTS 个电蓄热”的放热量汇总成 1×T 时间序列。
    % 兼容二维矩阵 Q(i,t) 和三维矩阵 Q(i,destination,t)。
    if ndims(Q) == 3
        y = squeeze(sum(Q(iTS,:,1:T), 2));
    else
        y = Q(iTS,1:T);
    end
    y = y(:)';
end

%% ================================================================
%  子函数：热电联产机组
% ================================================================
function plot_turbine_sum(ax, R, T, colors, lbl, fsTick, legPos)
    axes(ax); t = 1:T;
    yQc = sum(R.Qtu_c(:,1:T), 1);
    yQr = sum(R.Qtu_r(:,1:T), 1);
    yQh = sum(R.Qtu_h(:,1:T), 1);

    hold(ax,'on');
    bh = bar(ax,t,[yQc(:),yQr(:)],0.8,'stacked','EdgeColor','none','FaceAlpha',0.9);
    bh(1).FaceColor=colors.Qtu_c; bh(2).FaceColor=colors.Qtu_r;
    bar(ax,t,-yQh,0.8,'FaceColor',colors.Qtu_h,'EdgeColor','none','FaceAlpha',0.75);
    yline(ax,0,'-','Color',colors.zero_line,'LineWidth',0.6,'HandleVisibility','off');
    ylabel(ax, lbl.HEAT_MW, 'Color','k');
    ylim(ax,[min(-max(yQh)*1.1,-10), max(max(yQc+yQr)*1.1,10)]);

    xlim(ax,[0,T+0.5]); xticks(ax,[0,4,8,12,16,20,24]); xticklabels(ax,{'0:00','4:00','8:00','12:00','16:00','20:00','24:00'});
    set(ax,'FontName','Times New Roman','FontSize',fsTick, ...
        'TickDir','in','Box','on','LineWidth',0.8,'XColor','k','YColor','k');
    fix_legend(ax,{'燃料供热','电蓄热供热','低品级热输出'},legPos,3);
    xlabel(ax, lbl.TIME_H);
    hold(ax,'off');
end

%% ================================================================
%  子函数：工业热
% ================================================================
function plot_industrial_heat(ax, R, T, data, colors, lbl, fsTick, legPos)
    axes(ax); t = 1:T;
    Q_boiler = sum(R.Qs(:,1:T),1);
    if ndims(R.Q_i2k)==3
        Q_TS = squeeze(sum(sum(R.Q_i2k(:,:,1:T),1),2))';
    else
        Q_TS = sum(R.Q_i2k(:,1:T),1);
    end
    Q_load = Q_boiler + Q_TS;

    hold(ax,'on');
    bh = bar(ax,t,[Q_boiler(:),Q_TS(:)],0.8,'stacked','EdgeColor','none','FaceAlpha',0.88);
    bh(1).FaceColor=colors.ind_boiler; bh(2).FaceColor=colors.ind_TS;
    plot(ax,t,Q_load,'-o','Color',colors.load_line,'LineWidth',1.8,...
         'MarkerSize',4,'MarkerFaceColor','w','MarkerEdgeColor',colors.load_line);
    ylabel(ax, lbl.HEAT_MW, 'Color','k');
    xlabel(ax, lbl.TIME_H);
    xlim(ax,[0,T+0.5]); xticks(ax,[0,4,8,12,16,20,24]); xticklabels(ax,{'0:00','4:00','8:00','12:00','16:00','20:00','24:00'});
    ylim(ax,[0,max(Q_load)*1.15]);
    set(ax,'FontName','Times New Roman','FontSize',fsTick, ...
        'TickDir','in','Box','on','LineWidth',0.8,'XColor','k','YColor','k');
    fix_legend(ax,{'工业锅炉','电蓄热','工业负荷'},legPos,3);
    hold(ax,'off');
end

%% ================================================================
%  子函数：居民热
% ================================================================
function plot_residential_heat(ax, R, T, data, colors, lbl, fsTick, legPos)
    axes(ax); t = 1:T;
    Q_boiler = sum(R.Qw(:,1:T),    1);
    Q_TS     = sum(R.Q_i2n(:,1:T), 1);
    Q_tu     = sum(R.Qtu_h(:,1:T), 1);
    Q_load   = Q_boiler + Q_TS + Q_tu;

    hold(ax,'on');
    bh = bar(ax,t,[Q_boiler(:),Q_TS(:),Q_tu(:)],0.8,'stacked','EdgeColor','none','FaceAlpha',0.88);
    bh(1).FaceColor=colors.res_boiler; bh(2).FaceColor=colors.res_TS; bh(3).FaceColor=colors.res_tu;
    plot(ax,t,Q_load,'-o','Color',colors.load_line,'LineWidth',1.8,...
         'MarkerSize',4,'MarkerFaceColor','w','MarkerEdgeColor',colors.load_line);
    ylabel(ax, lbl.HEAT_MW, 'Color','k');
    xlabel(ax, lbl.TIME_H);
    xlim(ax,[0,T+0.5]); xticks(ax,[0,4,8,12,16,20,24]); xticklabels(ax,{'0:00','4:00','8:00','12:00','16:00','20:00','24:00'});
    ylim(ax,[0,max(Q_load)*1.15]);
    set(ax,'FontName','Times New Roman','FontSize',fsTick, ...
        'TickDir','in','Box','on','LineWidth',0.8,'XColor','k','YColor','k');
    fix_legend(ax,{'居民锅炉','电蓄热','热电联产机组低品位热','居民负荷'},legPos,4);
    hold(ax,'off');
end