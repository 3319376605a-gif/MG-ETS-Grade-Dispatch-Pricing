function plot_season_figures(xlsxPath)
%PLOT_SEASON_FIGURES  论文4.5、4.6节图，配色、字体与 plot_section42_figures.m 一致
%  各品级配置全寿命周期经济性（论文图10）：(a)累计折现净现金流 (b)收益与成本现值
%  三品级配置四季典型日电蓄热调度结果（论文图7）
%  四季典型日运行成本与弃风弃光电量（论文图8）
%  三品级配置四季分品级热价与节点电价（论文图9）
%  三品级配置四季典型日各主体净收益与用户用热支付（补充图，论文未收录）
%  需先运行 run_four_seasons。输出至 figs/（png 600dpi + pdf + fig）。
if nargin < 1 || isempty(xlsxPath), xlsxPath = 'case_14bus_6heat.xlsx'; end
outDir = 'figs';
if ~exist(outDir, 'dir'), mkdir(outDir); end
[L, A] = lcc_four_season(xlsxPath);
S  = season_table();
st = fig_style();

plot_lcc(L, st, outDir, lcc_params());
plot_dispatch(A, S, st, outDir);
plot_cost_curt(A, S, st, outDir);
plot_prices(A, S, st, outDir);
plot_revenue(A, S, st, outDir);
fprintf('\n图已保存至: %s\n', outDir);
end

%% ================================================================
function plot_lcc(L, st, outDir, p)
% 以无电蓄热系统为基准。收益 = 燃料成本节约 + 弃电成本节约；成本 = 初始投资 + 固定运维。
% 年运行成本已扣除电蓄热等效成本项（见 lcc_four_season），设备费用只以投资与运维计入，不重复计算。
names = {'PIB','PI','PB','IB','P','I','B'};
labs  = {'发电+工业+建筑','发电+工业','发电+建筑','工业+建筑','仅发电','仅工业','仅建筑'};
r = p.r; N = p.life; af = (1 - (1+r)^-N) / r; yrs = 0:N;
b0 = L('NoETS', :);
n = numel(names);
[fuel, curt, hx, oth, om, npv] = deal(zeros(1, n));
fig = st.newfig(32, 13);
ax1 = axes(fig, 'Position', [0.07 0.24 0.38 0.62]); hold(ax1, 'on');
for k = 1:n
    a = L(names{k}, :);
    cf = [-a.("初始投资"), repmat(a.("年净收益"), 1, N)] ./ (1+r).^yrs;
    lw = 1.2 + 1.0*strcmp(names{k}, 'PIB');
    plot(ax1, yrs, cumsum(cf)/1e4, '-', 'Color', st.c.lines(k,:), 'LineWidth', lw);
    fuel(k) = ((b0.("年运行成本") - b0.("其中弃电成本")) - (a.("年运行成本") - a.("其中弃电成本"))) * af / 1e4;
    curt(k) = (b0.("其中弃电成本") - a.("其中弃电成本")) * af / 1e4;
    hx(k)   = a.("换热设备投资") / 1e4;
    oth(k)  = (a.("初始投资") - a.("换热设备投资")) / 1e4;
    om(k)   = a.("固定运维") * af / 1e4;
end
npv = fuel + curt - hx - oth - om;
yline(ax1, 0, '-', 'Color', st.c.zero_line, 'LineWidth', 0.6, 'HandleVisibility', 'off');
xlim(ax1, [0 N]); st.axfmt(ax1);
ylabel(ax1, st.mix('累计折现净现金流/亿元'));
xlabel(ax1, {st.mix('运行年份/a'), st.sub(1, '累计折现净现金流')});
lg = legend(ax1, st.cn(labs), 'Location', 'northwest', 'FontSize', 12, 'Box', 'off', 'Interpreter', 'tex');
lg.ItemTokenSize = [18, 8];

ax2 = axes(fig, 'Position', [0.56 0.24 0.42 0.56]); hold(ax2, 'on');
x = 1:n;
bp = bar(ax2, x, [fuel; curt]', 0.62, 'stacked', 'EdgeColor', 'none', 'FaceAlpha', 0.92);
bp(1).FaceColor = st.c.renewable; bp(2).FaceColor = st.c.curt;
bn = bar(ax2, x, -[oth; hx; om]', 0.62, 'stacked', 'EdgeColor', 'none', 'FaceAlpha', 0.92);
bn(1).FaceColor = st.c.other_gen; bn(2).FaceColor = st.c.charge; bn(3).FaceColor = st.c.gray_bar;
% 净现值：每根柱上一条横跨柱宽的黑色短线，不标数值
hw = 0.31;
plot(ax2, [x - hw; x + hw], [npv; npv], 'k-', 'LineWidth', 2.2, 'HandleVisibility', 'off');
plot(ax2, nan, nan, 'k-', 'LineWidth', 2.2);   % 图例占位
yline(ax2, 0, '-', 'Color', st.c.zero_line, 'LineWidth', 0.6, 'HandleVisibility', 'off');
xlim(ax2, [0.4 n+0.6]); st.axfmt(ax2);
set(ax2, 'XTick', x, 'XTickLabel', st.cn(strrep(labs, '+', '+ ')), 'FontSize', st.fsTick - 3);
xtickangle(ax2, 30);
ylabel(ax2, st.mix('现值/亿元'), 'FontSize', st.fsTick);
xlabel(ax2, st.sub(2, '全寿命周期收益与成本现值'), 'FontSize', st.fsTick);
st.legend(ax2, {'燃料成本节约','弃电成本节约','加热器与储热体投资','换热设备投资','固定运维','净现值'}, ...
          [0.56 0.84 0.42 0.12], 3);
st.save(fig, outDir, 'Fig1_LCC');
end

%% ================================================================
function plot_dispatch(A, S, st, outDir)
fig = st.newfig(30, 20);
pos = {[0.08 0.60 0.37 0.27], [0.58 0.60 0.37 0.27], [0.08 0.17 0.37 0.27], [0.58 0.17 0.37 0.27]};
for s = 1:4
    a = A.(S(s).name).PIB; R = a.R; d = a.d; T = d.T; t = 1:T;
    ax = axes(fig, 'Position', pos{s}); hold(ax, 'on');
    Qch = sum(R.Qch, 1);
    QP = reshape(sum(sum(R.Q_i2j, 1), 2), 1, T);
    QI = reshape(sum(sum(R.Q_i2k, 1), 2), 1, T);
    QB = sum(R.Q_i2n, 1);
    yyaxis(ax, 'left');
    bar(ax, t, Qch, 0.8, 'FaceColor', st.c.charge, 'EdgeColor', 'none', 'FaceAlpha', 0.9);
    bh = bar(ax, t, -[QP(:), QI(:), QB(:)], 0.8, 'stacked', 'EdgeColor', 'none', 'FaceAlpha', 0.75);
    bh(1).FaceColor = st.c.discharge_tu; bh(2).FaceColor = st.c.discharge_ind; bh(3).FaceColor = st.c.discharge_res;
    yline(ax, 0, '-', 'Color', st.c.zero_line, 'LineWidth', 0.6, 'HandleVisibility', 'off');
    ylim(ax, [-420 420]); ax.YColor = 'k';
    if mod(s,2) == 1, ylabel(ax, st.mix('热功率/MW')); end
    yyaxis(ax, 'right');
    Emin = sum(d.Emin); Emax = sum(d.Emax); EL = sum(d.EL); EH = sum(d.EH);
    xF = [0, T+0.5, T+0.5, 0];
    fill(ax, xF, [EH EH Emax Emax], st.c.band_high, 'EdgeColor', 'none', 'FaceAlpha', 0.4, 'HandleVisibility', 'off');
    fill(ax, xF, [EL EL EH EH],     st.c.band_mid,  'EdgeColor', 'none', 'FaceAlpha', 0.4, 'HandleVisibility', 'off');
    fill(ax, xF, [Emin Emin EL EL], st.c.band_low,  'EdgeColor', 'none', 'FaceAlpha', 0.4, 'HandleVisibility', 'off');
    plot(ax, t, sum(R.E, 1), '-o', 'Color', st.c.energy_line, 'LineWidth', 1.8, ...
         'MarkerSize', 4, 'MarkerFaceColor', 'w', 'MarkerEdgeColor', st.c.energy_line);
    ylim(ax, [Emin-30, Emax+30]); ax.YColor = 'k';
    if mod(s,2) == 0, ylabel(ax, st.mix('储能量/MWh')); end
    xlim(ax, [0, T+0.5]); st.axfmt(ax); set(ax, 'XTick', [0 4 8 12 16 20 24]);
    xlabel(ax, {st.mix('时刻'), st.sub(s, S(s).cn)});
    if s == 1
        st.legend(ax, {'充热','发电级放热','工业级放热','建筑级放热','储能量'}, [0.06 0.92 0.88 0.06], 5);
    end
end
st.save(fig, outDir, 'Fig2_SeasonDispatch');
end

%% ================================================================
function plot_cost_curt(A, S, st, outDir)
cases = {'NoETS','B','PIB'};
cols  = {st.c.gray_bar, st.c.other_gen, st.c.discharge_tu};
cost = zeros(4,3); curt = cost;
for s = 1:4
    for c = 1:3
        a = A.(S(s).name).(cases{c});
        cost(s,c) = a.obj / 1e4; curt(s,c) = max(a.curt, 0);
    end
end
fig = st.newfig(30, 11);
ttl = {'日运行成本', '弃风弃光电量'};
ylb = {st.mix('日运行成本/万元'), st.mix('弃风弃光电量/MWh')};
Ys = {cost, curt};
for k = 1:2
    ax = axes(fig, 'Position', [0.08 + 0.49*(k-1), 0.20, 0.40, 0.58]); hold(ax, 'on');
    bh = bar(ax, 1:4, Ys{k}, 0.8, 'EdgeColor', 'none', 'FaceAlpha', 0.92);
    for c = 1:3, bh(c).FaceColor = cols{c}; end
    xlim(ax, [0.5 4.5]); ylim(ax, [0, max(Ys{k}(:))*1.08]);
    st.axfmt(ax); set(ax, 'XTick', 1:4, 'XTickLabel', st.cn({S.cn}));
    ylabel(ax, ylb{k}); xlabel(ax, st.sub(k, ttl{k}));
end
st.legend(ax, {'无电蓄热','仅建筑级供热','三品级供热'}, [0.15 0.88 0.70 0.08], 3);
st.save(fig, outDir, 'Fig3_SeasonCost');
end

%% ================================================================
function plot_prices(A, S, st, outDir)
fig = st.newfig(30, 20);
pos = {[0.09 0.60 0.38 0.27], [0.59 0.60 0.38 0.27], [0.09 0.17 0.38 0.27], [0.59 0.17 0.38 0.27]};
for s = 1:4
    a = A.(S(s).name).PIB; R = a.R; d = a.d; t = 1:d.T;
    ax = axes(fig, 'Position', pos{s}); hold(ax, 'on');
    pnode = R.HeatPrices.pi_node(unique(d.nM), :);
    plot(ax, t, mean(R.HeatPrices.pi_tu, 1), '-o', 'Color', st.c.discharge_tu,  'LineWidth', 1.8, 'MarkerSize', 4, 'MarkerFaceColor', 'w');
    plot(ax, t, mean(R.HeatPrices.pi_in, 1), '-s', 'Color', st.c.discharge_ind, 'LineWidth', 1.8, 'MarkerSize', 4, 'MarkerFaceColor', 'w');
    plot(ax, t, mean(pnode, 1, 'omitnan'),   '-^', 'Color', st.c.discharge_res, 'LineWidth', 1.8, 'MarkerSize', 4, 'MarkerFaceColor', 'w');
    plot(ax, t, mean(R.ElecPrices.pi_bus, 1), '--', 'Color', st.c.energy_line,  'LineWidth', 1.5);
    yline(ax, 0, '-', 'Color', st.c.zero_line, 'LineWidth', 0.6, 'HandleVisibility', 'off');
    xlim(ax, [1 d.T]); st.axfmt(ax); set(ax, 'XTick', [1 4 8 12 16 20 24]);
    if mod(s,2) == 1, ylabel(ax, st.mix('价格/(元/MWh)')); end
    xlabel(ax, {st.mix('时刻'), st.sub(s, S(s).cn)});
    if s == 1
        st.legend(ax, {'发电级热价','工业级热价','建筑级热价','节点电价'}, [0.10 0.92 0.80 0.06], 4);
    end
end
st.save(fig, outDir, 'Fig4_SeasonPrice');
end

%% ================================================================
function plot_revenue(A, S, st, outDir)
keys = {'ETS','CHP','RE','ConvGen','BoInd','BoRes','IndPay','ResPay'};
labs = {'电蓄热','热电联产','新能源','常规机组','工业锅炉','居民锅炉','工业用户用热支付','居民用户用热支付'};
Y = zeros(8, 4);
for s = 1:4
    a = A.(S(s).name).PIB;
    for k = 1:8, Y(k,s) = a.(keys{k}) / 1e4; end
end
cols = {st.c.renewable, st.c.charge, st.c.discharge_ind, st.c.energy_line};
fig = st.newfig(30, 12); ax = axes(fig, 'Position', [0.08 0.22 0.90 0.60]); hold(ax, 'on');
bh = bar(ax, 1:8, Y, 0.8, 'EdgeColor', 'none', 'FaceAlpha', 0.92);
for s = 1:4, bh(s).FaceColor = cols{s}; end
yline(ax, 0, '-', 'Color', st.c.zero_line, 'LineWidth', 0.6, 'HandleVisibility', 'off');
xline(ax, 6.5, ':', 'Color', st.c.gray_dark, 'LineWidth', 0.8, 'HandleVisibility', 'off');
xlim(ax, [0.4 8.6]); st.axfmt(ax); set(ax, 'XTick', 1:8, 'XTickLabel', st.cn(labs));
ylabel(ax, st.mix('净收益或支付/万元'));
st.legend(ax, {S.cn}, [0.25 0.88 0.50 0.08], 4);
st.save(fig, outDir, 'Fig5_SeasonRevenue');
end
