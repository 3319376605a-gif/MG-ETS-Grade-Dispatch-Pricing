function plot_fig_B1(xlsxPath)
%PLOT_FIG_B1  论文附录B 图B1：四季典型日负荷与新能源可用出力曲线
%  (a)系统电负荷 (b)风电可用出力 (c)光伏可用出力 (d)工业级热负荷 (e)建筑级热负荷
%  冬季典型日即论文4.1节基准日，其余季节按 season_table 的系数构造。输出至 figs/。
%  季节配色已通过色觉障碍校验（相邻色 CVD ΔE≥7.6），并以标记形状作第二编码。
if nargin < 1 || isempty(xlsxPath), xlsxPath = 'case_14bus_6heat.xlsx'; end
outDir = 'figs';
if ~exist(outDir, 'dir'), mkdir(outDir); end
base = read_config_xlsx(xlsxPath);
S  = season_table();
st = fig_style();
col = [0.180 0.545 0.271;    % 春 #2E8B45
       0.941 0.569 0.227;    % 夏 #F0913A
       0.608 0.310 0.588;    % 秋 #9B4F96
       0.227 0.471 0.761];   % 冬 #3A78C2
mk = {'o', 's', '^', 'd'};
t = 1:base.T;
F = {'系统电负荷',     @(d) sum(d.Pd, 1);
     '风电可用出力',   @(d) d.Gen_New_P(1,:);
     '光伏可用出力',   @(d) d.Gen_New_P(2,:);
     '工业级热负荷',   @(d) sum(d.Qin_dem, 1);
     '建筑级热负荷',   @(d) sum(d.Qre_dem_m, 1)};
fig = st.newfig(17, 22);
h = gobjects(1, numel(S));
for p = 1:size(F, 1)
    ax = subplot(3, 2, p); hold(ax, 'on');
    if p == 4       % 工业级热负荷四季相同
        plot(ax, t, F{p,2}(base), '-', 'Color', st.c.gray_dark, 'LineWidth', 1.4);
        text(ax, 0.5, 0.12, st.mix('四季相同'), 'Units', 'normalized', 'HorizontalAlignment', 'center', ...
             'FontSize', st.fsTick - 2, 'Interpreter', 'tex');
    else
        for s = 1:numel(S)
            d = season_data(base, S(s).name);
            h(s) = plot(ax, t, F{p,2}(d), '-', 'Color', col(s,:), 'LineWidth', 1.4, 'Marker', mk{s}, ...
                        'MarkerIndices', 1:3:base.T, 'MarkerSize', 5, 'MarkerFaceColor', 'w');
        end
        if p == 1   % 春、秋季电负荷系数相同
            text(ax, 0.5, 0.12, st.mix('春季与秋季曲线重合'), 'Units', 'normalized', ...
                 'HorizontalAlignment', 'center', 'FontSize', st.fsTick - 2, 'Interpreter', 'tex');
        end
    end
    xlim(ax, [1 base.T]); xticks(ax, [1 6 12 18 24]); ylim(ax, [0 inf]);
    grid(ax, 'on'); ax.GridColor = [0.85 0.85 0.85];
    st.axfmt(ax);
    xlabel(ax, st.mix('时段/h')); ylabel(ax, st.mix('功率/MW'));
    title(ax, st.sub(p, F{p,1}), 'FontWeight', 'normal', 'Interpreter', 'tex');
end
ax6 = subplot(3, 2, 6); axis(ax6, 'off');
lg = legend(ax6, h, st.cn({S.cn}), 'Location', 'west', 'Box', 'off', 'FontSize', st.fsTick, ...
            'Interpreter', 'tex');
lg.Position(1:2) = [0.62 0.12];
st.save(fig, outDir, 'figB1_season_profiles');
end
