# MATLAB 程序

依赖：MATLAB（建议 R2020a 及以上）、[YALMIP](https://yalmip.github.io/)、Gurobi（MIQP，相对最优间隙 `MIPGap = 1e-4`，与论文附录B表B1一致）。

所有脚本在本目录下运行，结果写入 `mat_results/`、`figs/` 及若干 `.xlsx` 汇总表。

## 基准日（论文4.1~4.3节）
```matlab
main                        % 调度 + 定价，保存 mat_results/results.mat
plot_section42_figures      % 4.2节调度结果图 -> figs_section42_split/
plot_heat_prices_journal    % 4.3节分品级热价图 -> figs/
plot_elec_prices_journal    % 4.3节节点电价图 -> figs/
accounts = settlement_accounts();   % 各主体结算
```

## 一键运行（论文4.4~4.6节、附录B、C）
```matlab
run_all
```
全部约 2~3 h。四季与敏感性部分结果逐个存到 `mat_results/season/`、`mat_results/sens/`，中断后重跑会跳过已完成的工况。

| 步骤 | 函数 | 对应论文内容 | 输出 |
|---|---|---|---|
| 1 | `run_grade_comparison` | 4.4节 表1、表2（7 种可供热品级配置） | `grade_comparison_summary.xlsx`、`paper_tables.xlsx` |
| 2 | `run_pool_vs_partition`（standard / reuse） | 4.4节 表3（共享容量池 vs 专用分置） | `pool_vs_partition_*.xlsx` |
| 3 | `run_degr_sensitivity` | 附录B7 表B8、表B9（放热成本系数取值影响） | `results_summary.xlsx` |
| 4 | `run_four_seasons` | 4.5节 四季典型日调度与定价 | `mat_results/season/*.mat` |
| 5 | `lcc_four_season` | 4.6节 全寿命周期经济性 | `results_summary.xlsx` |
| 6 | `run_param_sensitivity` | 附录C 表C1、表C2 | `mat_results/sens/*.mat`、`results_summary.xlsx` |
| 7 | `plot_season_figures` | 4.5、4.6节 图7~图10 | `figs/`（png 600dpi + pdf + fig） |
| 8 | `plot_fig_B1` | 附录B 图B1（四季负荷与新能源出力曲线） | `figs/figB1_season_profiles.*` |

## 文件说明
| 文件 | 作用 |
|---|---|
| `case_14bus_6heat.xlsx` | 算例数据（电网、热网、机组、电蓄热、负荷与新能源曲线；Meta 表含 `T`、`dt`、`BigM`、`c_curt` 等） |
| `read_config_xlsx.m` | 读取算例数据；Meta 表缺少 `c_curt` 时取 0 |
| `build_model.m` | 建立电热协同调度 MIQP（分段供热 Big-M 约束、热网温度约束、直流潮流）；`data.cyclic = true` 时采用周期性储能（日末储能量 = 日初储能量） |
| `solve_dispatch_milp.m` | 求解 MIQP → 固定整数变量 → 求连续子问题，取对偶作为分品级热价与节点电价 |
| `collect_results.m` | 提取变量取值 |
| `settlement_accounts.m` / `settle_results.m` | 按边际价格结算各主体收益（前者读 .mat 文件，后者直接接收结构体） |
| `make_partition_data.m` | 把每台电蓄热拆成 3 台单品级专用装置（专用分置对照） |
| `scenario_capacity_reuse.m` | 4.4节场景二：新能源大发、建筑级需求高、发电/工业级需求低 |
| `build_case.m` | 无电蓄热 / 7 种可供热品级配置 |
| `season_table.m` / `season_data.m` | 四季典型日构造系数（论文表4）及数据构造；有实测分季曲线时只需改 `season_table.m` |
| `price_means.m` | 热价、电价日均值，口径同论文表2 |
| `lcc_params.m` | 全寿命周期核算参数（论文表5） |
| `fig_style.m` | 4.5、4.6节及附录图的统一样式 |
