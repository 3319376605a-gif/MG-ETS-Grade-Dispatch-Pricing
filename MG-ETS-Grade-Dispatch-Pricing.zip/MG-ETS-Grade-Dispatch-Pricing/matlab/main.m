clear;clc;
outDir = 'mat_results';                 % 所有 .mat 结果统一存放的新文件夹
if ~exist(outDir, 'dir'), mkdir(outDir); end
data = read_config_xlsx("case_14bus_6heat.xlsx");
results = solve_dispatch_milp(data);
save(fullfile(outDir, 'results.mat'), 'results');
fprintf('>> 已保存结果: %s\n', fullfile(outDir, 'results.mat'));
