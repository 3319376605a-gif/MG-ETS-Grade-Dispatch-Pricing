function dp = make_partition_data(data)
%MAKE_PARTITION_DATA  把每个新型电蓄热裂成 3 个独立的单品级蓄热体（"机械分区"基准）
%
%  每个父器件 i  ->  3 个子器件，顺序 [ H(发电级)  M(工业级)  L(建筑级) ]
%    - 容量类参数(E0/Emin/Emax/EL/EH/Pmax/Qdis) 各取父器件的 1/3，总量严格守恒
%    - 效率(eta_*) 与单位运维成本(gamma_*) 与父器件完全相同（隔离结构效应，不掺成本/效率差）
%    - 每个子器件只开一个品级口，其余两个品级口=0 -> 彼此锁死、不可跨品级调用
%    - 分段门控退化(令 EL=EH=Emin)：任意有能量状态都能放本品级热，
%      即"充电就能放热"，没有原新型ETS的分段大M能量级联约束
%
%  其余字段(电网/热网/负荷/机组) 原样保留。build_model / solve_dispatch_milp 一行不改。
%
%  用法:  dPart = make_partition_data(data);   results = solve_dispatch_milp(dPart);

dp  = data;
I   = data.I;
c13 = 1/3;

% 每个父器件的标量参数复制 3 份（列主序展开成 [1H;1M;1L;2H;2M;2L;...]）
rep = @(v) reshape(repmat(v(:).', 3, 1), [], 1);

% ---- 同父继承：电母线 / 热网接入节点（3 个子器件与父器件同位置）----
dp.busES = rep(data.busES);
dp.nI    = rep(data.nI);

% ---- 容量类：1/3 缩放（总量守恒）----
dp.E0       = rep(data.E0)       * c13;
dp.Emin     = rep(data.Emin)     * c13;
dp.Emax     = rep(data.Emax)     * c13;
dp.Pes_min  = rep(data.Pes_min)  * c13;
dp.Pes_max  = rep(data.Pes_max)  * c13;
dp.Qdis_min = rep(data.Qdis_min) * c13;
dp.Qdis_max = rep(data.Qdis_max) * c13;

% ---- 效率 / 单位运维成本：原样继承（与父器件逐一相等）----
dp.eta_loss = rep(data.eta_loss);
dp.eta_ch   = rep(data.eta_ch);
dp.eta_dis  = rep(data.eta_dis);
dp.eta_eh   = rep(data.eta_eh);
dp.gamma_tu = rep(data.gamma_tu);
dp.gamma_in = rep(data.gamma_in);
dp.gamma_re = rep(data.gamma_re);

% ---- 分段门控退化：EL=EH=Emin  ->  yH 在 E>Emin 时恒可行 -> 充电即可放本品级热 ----
dp.EL = dp.Emin;
dp.EH = dp.Emin;

% ---- 品级口：每个子器件只开一个，容量=子器件 Qdis_max(=父/3) ----
dp.Q_tu_max = zeros(3*I, 1);
dp.Q_in_max = zeros(3*I, 1);
dp.Q_re_max = zeros(3*I, 1);

% ---- 连接矩阵按行展开（行=蓄热体）----
dp.A_i2j = zeros(3*I, data.J);
dp.A_i2k = zeros(3*I, data.K);

for i = 1:I
    iH = 3*(i-1)+1;   iM = 3*(i-1)+2;   iL = 3*(i-1)+3;
    cap = data.Qdis_max(i) * c13;        % 子器件单品级口容量(=父/3)

    % H 子器件：仅发电级口
    dp.Q_tu_max(iH) = cap;
    dp.A_i2j(iH, :) = data.A_i2j(i, :);

    % M 子器件：仅工业级口
    dp.Q_in_max(iM) = cap;
    dp.A_i2k(iM, :) = data.A_i2k(i, :);

    % L 子器件：仅建筑级口（建筑级无连接矩阵，靠 Q_re_max 控制）
    dp.Q_re_max(iL) = cap;
end

dp.I = 3 * I;
end
