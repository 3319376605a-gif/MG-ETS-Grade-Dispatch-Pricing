function summary = run_pool_vs_partition(xlsxPath, mode, opt)
%RUN_POOL_VS_PARTITION  共享容量池(新型ETS) vs 机械分区(三独立单品级蓄热) 对比算例
%
%  对照设计：
%     · 共享池(新型ETS)：一台，分段大M门控，容量为可跨品级调用的共享池；
%     · 机械分区       ：拆成三台独立电蓄热，每台只供一个品级，且"老式"——无分段大M，
%                        充热即可放热(EL=EH=Emin 退化)。
%
%  mode（场景）:
%     'standard' (默认) 标准场景：与七情形/4.2节同一套负荷与风光，不做任何改造。
%                       需求均衡平稳时分区(专用化)更优（论文表3）。
%     'reuse'           容量复用场景：新能源大发 + 建筑负荷高 + 发电/工业级需求低谷，
%                       形成品级错配，此时共享池(容量复用)占优（论文表3）。
%
%  opt   仅 'reuse' 模式生效，传给 scenario_capacity_reuse
%        (windScale/resScale/indScale，默认 1.5/2.0/0.4)
%
%  共享池端口=300(模板内)；分区子器件端口由 make_partition_data 取 Qdis_max/3(=100)。
%  不改 build_model / solve_dispatch_milp。
%
%  用法:
%     run_pool_vs_partition();                 % 标准场景（分区占优）
%     run_pool_vs_partition('', 'reuse');      % 容量复用场景（共享池占优）
%     run_pool_vs_partition('', 'reuse', struct('windScale',1.8,'resScale',2.5,'indScale',0.3));

if nargin<1 || isempty(xlsxPath), xlsxPath = 'case_14bus_6heat.xlsx'; end
if nargin<2 || isempty(mode),     mode = 'standard'; end
if nargin<3, opt = struct; end

outDir = 'mat_results';                   % 所有 .mat 结果统一存放的新文件夹
if ~exist(outDir, 'dir'), mkdir(outDir); end

raw = read_config_xlsx(xlsxPath);
switch lower(mode)
    case 'standard'
        % 不改任何负荷/风光
    case 'reuse'
        raw = scenario_capacity_reuse(raw, opt);
    otherwise
        error('未知 mode：%s（应为 standard 或 reuse）', mode);
end
avail_re = sum(raw.Gen_New_P(:));

dPool = raw;                          % 共享池(新型ETS)
dPart = make_partition_data(raw);     % 机械分区(三独立单品级老式蓄热)

fprintf('\n########## [%s] 求解：共享池(新型ETS) ##########\n', mode);
rPool = solve_dispatch_milp(dPool);
fprintf('\n########## [%s] 求解：机械分区(三独立蓄热) ##########\n', mode);
rPart = solve_dispatch_milp(dPart);

mPool = local_metrics(rPool, dPool, avail_re);
mPart = local_metrics(rPart, dPart, avail_re);

summary = table( ...
    ["共享池(新型ETS)"; "机械分区(三独立蓄热)"], ...
    [mPool.Cost;         mPart.Cost], ...
    [mPool.Curtail;      mPart.Curtail], ...
    [mPool.AccRate;      mPart.AccRate], ...
    [mPool.QbuildPeak;   mPart.QbuildPeak], ...
    [mPool.QbuildEnergy; mPart.QbuildEnergy], ...
    [mPool.ChargeEnergy; mPart.ChargeEnergy], ...
    'VariableNames', {'Config','TotalCost','Curtail_MWh','AccRate_pct', ...
        'Build_from_ETS_peak_MW','Build_from_ETS_MWh','ETS_charge_MWh'});

disp(' '); fprintf('=== 场景: %s ===\n', mode); disp(summary);

dC    = mPart.Cost    - mPool.Cost;
dCurt = mPart.Curtail - mPool.Curtail;
who   = '';
if dC > 0, who = '（共享池更优）'; elseif dC < 0, who = '（分区更优）'; end
fprintf('\n============== [%s] 共享池 相对 机械分区 %s ==============\n', mode, who);
fprintf(' 总运行成本 : %12.1f  vs %12.1f   (差 %+.1f, %+.2f%%)\n', ...
        mPool.Cost, mPart.Cost, dC, 100*dC/mPart.Cost);
fprintf(' 弃风弃光   : %12.1f  vs %12.1f   MWh (差 %+.1f)\n', ...
        mPool.Curtail, mPart.Curtail, dCurt);
fprintf(' 消纳率     : %11.2f%%  vs %11.2f%%   (差 %+.2f pt)\n', ...
        mPool.AccRate, mPart.AccRate, mPool.AccRate-mPart.AccRate);
fprintf(' 储能->建筑级供热峰值 : %8.1f  vs %8.1f   MW\n', ...
        mPool.QbuildPeak, mPart.QbuildPeak);
fprintf(' 储能->建筑级供热电量 : %8.1f  vs %8.1f   MWh\n', ...
        mPool.QbuildEnergy, mPart.QbuildEnergy);
fprintf('==========================================================\n');

local_plot(rPool, rPart, dPool, dPart, mode);

try
    writetable(summary, sprintf('pool_vs_partition_%s.xlsx', mode), 'WriteMode','overwritesheet');
catch
    writetable(summary, sprintf('pool_vs_partition_%s.xlsx', mode));
end
save(fullfile(outDir, sprintf('results_pool_%s.mat', mode)), 'rPool');
save(fullfile(outDir, sprintf('results_partition_%s.mat', mode)), 'rPart');
fprintf('\n>> 已写出 pool_vs_partition_%s.xlsx 及 %s\n', mode, ...
        fullfile(outDir, sprintf('results_{pool,partition}_%s.mat', mode)));
end


%% ===================== 局部：指标提取 =====================
function m = local_metrics(r, d, avail_re)
m.Cost    = r.Objective;
disp_re   = sum(r.Pn(:));
m.Curtail = avail_re - disp_re;
m.AccRate = 100 * disp_re / avail_re;
Qbuild_t  = sum(r.Q_i2n, 1);
m.QbuildPeak   = max(Qbuild_t);
m.QbuildEnergy = sum(Qbuild_t) * d.dt;
m.ChargeEnergy = sum(r.Pes(:)) * d.dt;
end


%% ===================== 局部：对比图 =====================
function local_plot(rPool, rPart, dPool, dPart, mode)
T  = dPool.T;  tt = 1:T;
QbPool = sum(rPool.Q_i2n, 1);  QbPart = sum(rPart.Q_i2n, 1);
PcPool = sum(rPool.Pes, 1);    PcPart = sum(rPart.Pes, 1);
cP = [0.20 0.55 0.30];  cM = [0.80 0.30 0.22];

figure('Name',['Pool vs Partition - ' mode],'Color','w','Position',[100 100 1180 760]);

subplot(2,2,1); hold on; box on; grid on;
plot(tt, QbPool, '-o', 'Color',cP, 'LineWidth',1.8, 'MarkerSize',4);
plot(tt, QbPart, '-s', 'Color',cM, 'LineWidth',1.8, 'MarkerSize',4);
xlabel('时段 / h'); ylabel('储能向建筑级供热 / MW');
title('(a) 储能下沉供建筑级热'); legend({'共享池(新型ETS)','机械分区'}, 'Location','best');
set(gca,'FontSize',11); xlim([1 T]);

subplot(2,2,2); hold on; box on; grid on;
plot(tt, PcPool, '-o', 'Color',cP, 'LineWidth',1.8, 'MarkerSize',4);
plot(tt, PcPart, '-s', 'Color',cM, 'LineWidth',1.8, 'MarkerSize',4);
xlabel('时段 / h'); ylabel('储能总充电功率 / MW');
title('(b) 储能吸收风电(充电)能力发挥'); legend({'共享池','机械分区'}, 'Location','best');
set(gca,'FontSize',11); xlim([1 T]);

subplot(2,2,3);
b1 = bar(categorical({'共享池','机械分区'}), [rPool.Objective; rPart.Objective], 0.5);
b1.FaceColor='flat'; b1.CData=[cP;cM]; grid on; box on;
ylabel('系统总运行成本'); title('(c) 总运行成本'); set(gca,'FontSize',11);

subplot(2,2,4);
availP = sum(dPool.Gen_New_P(:));  availM = sum(dPart.Gen_New_P(:));
curtP  = availP - sum(rPool.Pn(:)); curtM = availM - sum(rPart.Pn(:));
b2 = bar(categorical({'共享池','机械分区'}), [curtP; curtM], 0.5);
b2.FaceColor='flat'; b2.CData=[cP;cM]; grid on; box on;
ylabel('弃风弃光 / MWh'); title('(d) 弃风弃光'); set(gca,'FontSize',11);

sgtitle(sprintf('共享容量池 vs 机械分区  —  场景: %s', mode), 'FontSize',13);
end
