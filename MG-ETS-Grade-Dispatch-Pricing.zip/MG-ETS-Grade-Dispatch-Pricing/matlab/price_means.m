function p = price_means(R)
%PRICE_MEANS  各品级热价与节点电价日均值（元/MWh），口径同 run_grade_comparison.m（论文表2）
HP = R.HeatPrices;
p.Gen  = mean(HP.pi_tu(:));
p.Ind  = mean(HP.pi_in(:));
x = HP.pi_node(~isnan(HP.pi_node));
p.Bld  = mean(x);
p.Elec = mean(R.ElecPrices.pi_bus(:));
end
