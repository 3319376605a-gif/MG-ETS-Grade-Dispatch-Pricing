function results = collect_results(data, model, handles)
results = struct();

results.E      = value(handles.E);
results.Qch    = value(handles.Qch);
results.Qdis   = value(handles.Qdis);
results.Pes    = value(handles.Pes);

results.Q_i2j  = value(handles.Q_i2j);
results.Q_i2k  = value(handles.Q_i2k);
results.Q_i2n  = value(handles.Q_i2n);
results.Q_s2k  = value(handles.Q_s2k);

results.Ptu    = value(handles.Ptu);
results.Pg     = value(handles.Pg);
results.Pn     = value(handles.Pn);
results.Pbuy     = value(handles.Pbuy);
results.Psell    = value(handles.Psell);
results.Qtu_r    = value(handles.Qtu_r);
results.Qtu_c    = value(handles.Qtu_c);
results.Qtu_h    = value(handles.Qtu_h);

results.Qs     = value(handles.Qs);
results.Qw     = value(handles.Qw);
results.theta  = value(handles.theta);
results.Pflow  = value(handles.Pflow);

results.Ts_node = value(handles.Ts_node);
results.Tr_node = value(handles.Tr_node);
results.Ts_sup_from = value(handles.Ts_sup_from);
results.Ts_sup_to = value(handles.Ts_sup_to);
results.Tr_ret_from = value(handles.Tr_ret_from);
results.Tr_ret_to = value(handles.Tr_ret_to);
     

results.yL     = round(value(handles.yL));
results.yM     = round(value(handles.yM));
results.yH     = round(value(handles.yH));


end
