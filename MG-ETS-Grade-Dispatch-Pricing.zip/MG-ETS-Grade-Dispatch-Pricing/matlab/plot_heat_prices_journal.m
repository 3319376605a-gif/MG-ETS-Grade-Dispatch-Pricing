function plot_heat_prices_journal(resultsPath, xlsxPath, outDir, plotType)
%PLOT_HEAT_PRICES_JOURNAL  科研论文级热价绘图
%
% 现在支持：
%   - plotType = 'lines'   只画曲线图
%   - plotType = 'heatmap' 只画热力图
%   - plotType = 'both'    同时画两张图（默认）
%
% 输入参数：
%   resultsPath - results.mat 路径（默认当前目录）
%   xlsxPath    - 配置 xlsx 路径
%   outDir      - 输出目录（默认 'figs'）
%   plotType    - 'lines' / 'heatmap' / 'both'（默认 'both'）
%
% 输出（默认 outDir='figs'）：
%   曲线图：
%     FigH1_TurbineHeatPrice_Lines.(png/pdf)
%     FigH2_IndustrialHeatPrice_Lines.(png/pdf)
%     FigH3_NodeHeatPrice_Lines.(png/pdf)
%   热力图：
%     FigH1_TurbineHeatPrice_Heatmap.(png/pdf)
%     FigH2_IndustrialHeatPrice_Heatmap.(png/pdf)
%     FigH3_NodeHeatPrice_Heatmap.(png/pdf)

%% ==================== 参数初始化 ====================
if nargin < 1 || isempty(resultsPath), resultsPath = fullfile('mat_results','results.mat'); end
if nargin < 2 || isempty(xlsxPath),    xlsxPath    = 'case_14bus_6heat.xlsx'; end
if nargin < 3 || isempty(outDir),      outDir      = 'figs'; end
if nargin < 4 || isempty(plotType),    plotType    = 'both'; end

%% ==================== 加载数据 ====================
S = load(resultsPath);
assert(isfield(S,'results'), 'results.mat 中未找到变量 results');
R = S.results;

data = read_config_xlsx(xlsxPath);
T = data.T;
t = 1:T;

% 取 HeatPrices
assert(isfield(R,'HeatPrices'), ...
    'results 中未找到 HeatPrices。请确认是用 solve_dispatch_milp.m 求解并保存了 results.HeatPrices');

HP = R.HeatPrices;

pi_tu   = getfield_ifexist(HP, 'pi_tu', []);
pi_in   = getfield_ifexist(HP, 'pi_in', []);
pi_node = getfield_ifexist(HP, 'pi_node', []);

%% ==================== 输出目录 ====================
if ~exist(outDir,'dir'), mkdir(outDir); end

%% ==================== 科研绘图全局设置 ====================
set(groot, 'defaultFigureColor', 'w');
set(groot, 'defaultAxesBox', 'on');
set(groot, 'defaultAxesTickDir', 'out');

%% ==================== 配色方案（Nature/Cell风格） ====================
% 多条曲线颜色
lineColors = [
    0.122, 0.267, 0.537;   % 深蓝
    0.929, 0.490, 0.192;   % 橙色
    0.180, 0.545, 0.549;   % 青色
    0.557, 0.267, 0.537;   % 紫色
    0.843, 0.522, 0.522;   % 玫瑰
    0.400, 0.706, 0.710;   % 浅青
    0.737, 0.478, 0.690;   % 浅紫
    0.200, 0.400, 0.600;   % 蓝灰
    0.850, 0.370, 0.370;   % 红
    0.350, 0.550, 0.350;   % 绿
    0.550, 0.550, 0.350;   % 橄榄
    0.750, 0.550, 0.350;   % 棕
    0.450, 0.350, 0.550;   % 靛
    0.350, 0.450, 0.550;   % 石板蓝
];

% 均价线颜色
meanColor = [0.35, 0.35, 0.35];

%% ==================== 字体配置（放大） ====================
fontConfig = struct();
fontConfig.family     = '宋体';
fontConfig.sizeAxis   = 18;
fontConfig.sizeTitle  = 18;
fontConfig.sizeLegend = 14;
fontConfig.sizeTick   = 16;

%% ==================== 根据类型绘图 ====================
plotType = lower(string(plotType));

switch plotType
    case "lines"
        plot_all_lines(pi_tu, pi_in, pi_node, data, t, T, lineColors, meanColor, fontConfig, outDir);
    case "heatmap"
        plot_all_heatmaps(pi_tu, pi_in, pi_node, data, T, fontConfig, outDir);
    case "both"
        plot_all_lines(pi_tu, pi_in, pi_node, data, t, T, lineColors, meanColor, fontConfig, outDir);
        plot_all_heatmaps(pi_tu, pi_in, pi_node, data, T, fontConfig, outDir);
    otherwise
        error("plotType 只能是 'lines' / 'heatmap' / 'both'。当前为: %s", plotType);
end

fprintf('\n完成！所有热价图形已保存至: %s\n', outDir);

end

%% ==================== 绘制所有曲线图 ====================
function plot_all_lines(pi_tu, pi_in, pi_node, data, t, T, lineColors, meanColor, fontConfig, outDir)

% Fig1: 汽轮机热价 - 不画均价
if ~isempty(pi_tu)
    plot_lines_single_no_mean(pi_tu, t, T, lineColors, fontConfig, ...
        '汽轮机边际热价（曲线）', '热电联产机组', ...
        fullfile(outDir, 'FigH1_TurbineHeatPrice_Lines'));
end

% Fig2: 工业热价 - 不画均价
if ~isempty(pi_in)
    plot_lines_single_no_mean(pi_in, t, T, lineColors, fontConfig, ...
        '工业负荷边际热价（曲线）', '工业负荷', ...
        fullfile(outDir, 'FigH2_IndustrialHeatPrice_Lines'));
end

% Fig3: 热网节点热价（关键节点）- 保留均价
if ~isempty(pi_node)
    keyNodes = get_key_nodes(data, size(pi_node, 1));
    if ~isempty(keyNodes)
        pi_key = pi_node(keyNodes, :);
        plot_lines_node(pi_key, keyNodes, t, T, lineColors, meanColor, fontConfig, ...
            '热网关键节点热价（曲线）', ...
            fullfile(outDir, 'FigH3_NodeHeatPrice_Lines'));
    end
end

end

%% ==================== 绘制所有热力图 ====================
function plot_all_heatmaps(pi_tu, pi_in, pi_node, data, T, fontConfig, outDir)

% ---- 计算三组数据的全局颜色范围 ----
allVals = [];
if ~isempty(pi_tu),   allVals = [allVals; pi_tu(:)];   end
if ~isempty(pi_in),   allVals = [allVals; pi_in(:)];   end
if ~isempty(pi_node)
    keyNodes_tmp = get_key_nodes(data, size(pi_node, 1));
    if ~isempty(keyNodes_tmp)
        allVals = [allVals; reshape(pi_node(keyNodes_tmp,:),[],1)];
    end
end
globalCLim = [min(allVals), max(allVals)];

% Fig1: 汽轮机热价
if ~isempty(pi_tu)
    N_tu = size(pi_tu, 1);
    yLabels_tu = arrayfun(@num2str, 1:N_tu, 'UniformOutput', false);
    plot_heatmap_single(pi_tu, T, fontConfig, ...
        '汽轮机边际热价（热力图）', '\fontname{宋体}热电联产机组', yLabels_tu, ...
        fullfile(outDir, 'FigH1_TurbineHeatPrice_Heatmap'), globalCLim);
end

% Fig2: 工业热价
if ~isempty(pi_in)
    N_in = size(pi_in, 1);
    yLabels_in = arrayfun(@num2str, 1:N_in, 'UniformOutput', false);
    plot_heatmap_single(pi_in, T, fontConfig, ...
        '工业负荷边际热价（热力图）', '\fontname{宋体}工业负荷', yLabels_in, ...
        fullfile(outDir, 'FigH2_IndustrialHeatPrice_Heatmap'), globalCLim);
end

% Fig3: 热网节点热价
if ~isempty(pi_node)
    keyNodes = get_key_nodes(data, size(pi_node, 1));
    if ~isempty(keyNodes)
        pi_key = pi_node(keyNodes, :);
        plot_heatmap_node(pi_key, keyNodes, T, fontConfig, ...
            '热网关键节点热价（热力图）', ...
            fullfile(outDir, 'FigH3_NodeHeatPrice_Heatmap'), globalCLim);
    end
end

end

%% ==================== 曲线图函数（不画均价） ====================
function plot_lines_single_no_mean(priceData, t, T, lineColors, fontConfig, titleStr, labelPrefix, baseName)

[N, ~] = size(priceData);

fig = figure('Units', 'pixels', ...
             'Position', [100, 100, 700, 500], ...
             'Color', 'w', ...
             'Renderer', 'painters');

ax = axes(fig, 'Units', 'normalized', ...
               'Position', [0.12, 0.15, 0.68, 0.75]);
hold(ax, 'on');

% 绘制各条曲线
h = gobjects(N, 1);
labels = cell(N, 1);

for i = 1:N
    colorIdx = mod(i-1, size(lineColors, 1)) + 1;
    h(i) = plot(ax, t, rowvec(priceData(i,:), T), '-o', ...
                'Color', lineColors(colorIdx,:), ...
                'LineWidth', 1.8, ...
                'MarkerSize', 4, ...
                'MarkerFaceColor', 'w', ...
                'MarkerEdgeColor', lineColors(colorIdx,:));
    labels{i} = sprintf('\\fontname{宋体}%s \\fontname{Times New Roman}%d', labelPrefix, i);
end

% 坐标轴设置
ax.XLim = [0, T+0.5];
yMax = max(priceData(:), [], 'omitnan');
if isnan(yMax) || yMax <= 0, yMax = 1; end
ax.YLim = [0, yMax * 1.08];

xlabel(ax, '\fontname{宋体}时刻', 'FontSize', fontConfig.sizeAxis);
ylabel(ax, '\fontname{宋体}热价/(\fontname{Times New Roman}¥/MWh)', ...
       'FontSize', fontConfig.sizeAxis);

% 刻度（数字用 Times New Roman）
ax.XTick = [0, 4, 8, 12, 16, 20, 24];
ax.XTickLabel = {'0:00','4:00','8:00','12:00','16:00','20:00','24:00'};
ax.FontName = 'Times New Roman';
ax.FontSize = fontConfig.sizeTick;
ax.TickDir = 'in';
ax.Box = 'on';
ax.LineWidth = 0.8;

% 图例
lg = legend(ax, h, labels, ...
            'Location', 'eastoutside', ...
            'FontSize', fontConfig.sizeLegend, ...
            'FontName', '宋体');
lg.Box = 'off';

hold(ax, 'off');

% 导出
exportgraphics(fig, [baseName, '.png'], 'Resolution', 600);
exportgraphics(fig, [baseName, '.pdf'], 'ContentType', 'vector');
fprintf('已保存: %s.png / .pdf\n', baseName);

end

%% ==================== 曲线图函数（节点专用，保留均价） ====================
function plot_lines_node(priceData, nodeIdx, t, T, lineColors, meanColor, fontConfig, titleStr, baseName)

N = size(priceData, 1);

fig = figure('Units', 'pixels', ...
             'Position', [100, 100, 700, 500], ...
             'Color', 'w', ...
             'Renderer', 'painters');

ax = axes(fig, 'Units', 'normalized', ...
               'Position', [0.12, 0.15, 0.68, 0.75]);
hold(ax, 'on');

% 绘制各条曲线
h = gobjects(N, 1);
labels = cell(N, 1);

for i = 1:N
    colorIdx = mod(i-1, size(lineColors, 1)) + 1;
    h(i) = plot(ax, t, rowvec(priceData(i,:), T), '-o', ...
                'Color', lineColors(colorIdx,:), ...
                'LineWidth', 1.8, ...
                'MarkerSize', 4, ...
                'MarkerFaceColor', 'w', ...
                'MarkerEdgeColor', lineColors(colorIdx,:));
    labels{i} = sprintf('\\fontname{宋体}节点 \\fontname{Times New Roman}%d', nodeIdx(i));
end

% 绘制均价（虚线）
mean_price = mean(priceData, 1, 'omitnan');
h_mean = plot(ax, t, mean_price, '--', ...
              'Color', meanColor, ...
              'LineWidth', 2.2);

% 坐标轴设置
ax.XLim = [0, T+0.5];
yMax = max(priceData(:), [], 'omitnan');
if isnan(yMax) || yMax <= 0, yMax = 1; end
ax.YLim = [0, yMax * 1.08];

xlabel(ax, '\fontname{宋体}时刻', 'FontSize', fontConfig.sizeAxis);
ylabel(ax, '\fontname{宋体}热价/(\fontname{Times New Roman}¥/MWh)', ...
       'FontSize', fontConfig.sizeAxis);

% 刻度（数字用 Times New Roman）
ax.XTick = [0, 4, 8, 12, 16, 20, 24];
ax.XTickLabel = {'0:00','4:00','8:00','12:00','16:00','20:00','24:00'};
ax.FontName = 'Times New Roman';
ax.FontSize = fontConfig.sizeTick;
ax.TickDir = 'in';
ax.Box = 'on';
ax.LineWidth = 0.8;

% 图例
lg = legend(ax, [h; h_mean], [labels; {'\fontname{宋体}均价'}], ...
            'Location', 'eastoutside', ...
            'FontSize', fontConfig.sizeLegend, ...
            'FontName', '宋体');
lg.Box = 'off';

hold(ax, 'off');

% 导出
exportgraphics(fig, [baseName, '.png'], 'Resolution', 600);
exportgraphics(fig, [baseName, '.pdf'], 'ContentType', 'vector');
fprintf('已保存: %s.png / .pdf\n', baseName);

end

%% ==================== 热力图函数（通用） ====================
function plot_heatmap_single(priceData, T, fontConfig, titleStr, yLabelStr, yTickLabels, baseName, globalCLim)

[N, ~] = size(priceData);

fig = figure('Units', 'pixels', ...
             'Position', [100, 100, 700, 500], ...
             'Color', 'w', ...
             'Renderer', 'painters');

ax = axes(fig, 'Units', 'normalized', ...
               'Position', [0.12, 0.15, 0.68, 0.75]);

% 绘制热力图
imagesc(ax, 1:T, 1:N, priceData);
ax.YDir = 'reverse';

% 全局统一颜色范围
caxis(ax, globalCLim);

% 连续渐变 colormap：蓝→青→淡黄→橙→深红
colors_cmap = [
    0.910, 0.945, 0.969;
    0.180, 0.545, 0.549;
    0.969, 0.949, 0.910;
    0.929, 0.490, 0.192;
    0.843, 0.302, 0.302;
];
cmap = interp1(linspace(0,1,size(colors_cmap,1)), colors_cmap, linspace(0,1,256));
colormap(ax, cmap);

% Colorbar
cb = colorbar(ax, 'Position', [0.82, 0.15, 0.03, 0.75]);
cb.Label.String = '\fontname{宋体}热价/(\fontname{Times New Roman}¥/MWh)';
cb.Label.FontSize = fontConfig.sizeAxis;
cb.FontSize = fontConfig.sizeTick;
cb.FontName = 'Times New Roman';

% 坐标轴设置
xlabel(ax, '\fontname{宋体}时刻', 'FontSize', fontConfig.sizeAxis);
ylabel(ax, yLabelStr, 'FontSize', fontConfig.sizeAxis);

% 刻度（数字用 Times New Roman）
ax.XTick = [0, 4, 8, 12, 16, 20, 24];
ax.XTickLabel = {'0:00','4:00','8:00','12:00','16:00','20:00','24:00'};
ax.XLim = [0.5, T + 0.5];
ax.YTick = 1:N;
ax.YTickLabel = yTickLabels;
ax.FontName = 'Times New Roman';
ax.FontSize = fontConfig.sizeTick;
ax.TickDir = 'in';
ax.Box = 'on';
ax.LineWidth = 0.8;

% 导出
exportgraphics(fig, [baseName, '.png'], 'Resolution', 600);
exportgraphics(fig, [baseName, '.pdf'], 'ContentType', 'vector');
fprintf('已保存: %s.png / .pdf\n', baseName);

end

%% ==================== 热力图函数（节点专用） ====================
function plot_heatmap_node(priceData, nodeIdx, T, fontConfig, titleStr, baseName, globalCLim)

N = size(priceData, 1);

fig = figure('Units', 'pixels', ...
             'Position', [100, 100, 700, 500], ...
             'Color', 'w', ...
             'Renderer', 'painters');

ax = axes(fig, 'Units', 'normalized', ...
               'Position', [0.12, 0.15, 0.68, 0.75]);

% 绘制热力图
imagesc(ax, 1:T, 1:N, priceData);
ax.YDir = 'reverse';

% 全局统一颜色范围
caxis(ax, globalCLim);

% 连续渐变 colormap
colors_cmap = [
    0.910, 0.945, 0.969;
    0.180, 0.545, 0.549;
    0.969, 0.949, 0.910;
    0.929, 0.490, 0.192;
    0.843, 0.302, 0.302;
];
cmap = interp1(linspace(0,1,size(colors_cmap,1)), colors_cmap, linspace(0,1,256));
colormap(ax, cmap);

% Colorbar
cb = colorbar(ax, 'Position', [0.82, 0.15, 0.03, 0.75]);
cb.Label.String = '\fontname{宋体}热价/(\fontname{Times New Roman}¥/MWh)';
cb.Label.FontSize = fontConfig.sizeAxis;
cb.FontSize = fontConfig.sizeTick;
cb.FontName = 'Times New Roman';

% 坐标轴设置
xlabel(ax, '\fontname{宋体}时刻', 'FontSize', fontConfig.sizeAxis);
ylabel(ax, '\fontname{宋体}节点', 'FontSize', fontConfig.sizeAxis);

% 刻度
ax.XTick = [0, 4, 8, 12, 16, 20, 24];
ax.XTickLabel = {'0:00','4:00','8:00','12:00','16:00','20:00','24:00'};
ax.XLim = [0.5, T + 0.5];
ax.YTick = 1:N;
ax.YTickLabel = arrayfun(@num2str, nodeIdx, 'UniformOutput', false);
ax.FontName = 'Times New Roman';
ax.FontSize = fontConfig.sizeTick;
ax.TickDir = 'in';
ax.Box = 'on';
ax.LineWidth = 0.8;

% 导出
exportgraphics(fig, [baseName, '.png'], 'Resolution', 600);
exportgraphics(fig, [baseName, '.pdf'], 'ContentType', 'vector');
fprintf('已保存: %s.png / .pdf\n', baseName);

end

%% ==================== 辅助函数 ====================
function keyNodes = get_key_nodes(data, maxNode)
% 获取关键节点集合
keyNodes = [];
if isfield(data,'nTu'), keyNodes = [keyNodes; data.nTu(:)]; end
if isfield(data,'nW'),  keyNodes = [keyNodes; data.nW(:)];  end
if isfield(data,'nM'),  keyNodes = [keyNodes; data.nM(:)];  end
keyNodes = unique(keyNodes(~isnan(keyNodes) & keyNodes >= 1));
keyNodes = keyNodes(keyNodes <= maxNode);

if isempty(keyNodes)
    warning('未识别到关键节点（nTu/nW/nM 为空），跳过节点热价图');
end
end

function v = getfield_ifexist(S, field, defaultVal)
if isstruct(S) && isfield(S, field)
    v = S.(field);
else
    v = defaultVal;
end
end

function x = rowvec(x, T)
x = double(x);
x = x(:)';
if nargin >= 2 && numel(x) ~= T
    x = reshape(x, 1, []);
    if numel(x) > T, x = x(1:T); end
    if numel(x) < T, x = [x, zeros(1, T-numel(x))]; end
end
end