function a = settle_results(R, data)
%SETTLE_RESULTS  按边际电价/热价结算各主体日收益（元），口径同 settlement_accounts.m
%  直接接收 results 结构体与 data，便于四季批量结算。
%  a.ETS_degr 为电蓄热等效成本项（gamma_*×放热量），全寿命周期核算时从运行成本中扣除。
T  = data.T; dt = data.dt;
pb  = R.ElecPrices.pi_bus;
ptu = R.HeatPrices.pi_tu;
pin = R.HeatPrices.pi_in;   pin(isnan(pin)) = 0;
pn  = R.HeatPrices.pi_node; pn(isnan(pn))  = 0;

a.Grid = (data.price_buy(:)'*R.Pbuy(:) - data.price_sell(:)'*R.Psell(:)) * dt;

a.ConvGen = 0;
for g = 1:data.G
    P = R.Pg(g,:);
    a.ConvGen = a.ConvGen + (sum(pb(data.busG(g),:).*P) - sum(data.a_g(g)*P + data.a2_g(g)*P.^2)) * dt;
end
a.RE = 0;
for g = 1:data.G_N
    P = R.Pn(g,:);
    a.RE = a.RE + (sum(pb(data.busG_N(g),:).*P) - data.a_n(g)*sum(P)) * dt;
end
a.CHP = 0;
for j = 1:data.J
    Qc = R.Qtu_c(j,:);
    a.CHP = a.CHP + (sum(pb(data.busTu(j),:).*R.Ptu(j,:)) + sum(pn(data.nTu(j),:).*R.Qtu_h(j,:)) ...
          - sum(data.CHP_a(j)*Qc.^2 + data.CHP_b(j)*Qc) - sum(ptu(j,:).*R.Qtu_r(j,:))) * dt;
end
ets = 0; rev_all = 0; pay_all = 0;
for i = 1:data.I
    Qij = reshape(R.Q_i2j(i,:,:), data.J, T);
    Qik = reshape(R.Q_i2k(i,:,:), data.K, T);
    pay = sum(pb(data.busES(i),:).*R.Pes(i,:));
    rev = sum(sum(ptu.*Qij)) + sum(sum(pin.*Qik)) + sum(pn(data.nI(i),:).*R.Q_i2n(i,:));
    om  = data.gamma_tu(i)*sum(Qij(:)) + data.gamma_in(i)*sum(Qik(:)) + data.gamma_re(i)*sum(R.Q_i2n(i,:));
    ets = ets + rev - pay - om; rev_all = rev_all + rev; pay_all = pay_all + pay;
end
a.ETS = ets*dt; a.ETS_heat_rev = rev_all*dt; a.ETS_elec_pay = pay_all*dt;
a.ETS_degr = (rev_all - pay_all - ets)*dt;
a.BoInd = 0;
for s = 1:data.S
    Qs = R.Qs(s,:);
    Qsk = reshape(R.Q_s2k(s,:,:), data.K, T);
    a.BoInd = a.BoInd + (sum(sum(pin.*Qsk)) - sum(data.gamma_GB_ind(s)*Qs + data.gamma_GB_ind_2(s)*Qs.^2)) * dt;
end
a.BoRes = 0;
for w = 1:data.W
    Qw = R.Qw(w,:);
    a.BoRes = a.BoRes + (sum(pn(data.nW(w),:).*Qw) - sum(data.gamma_GB_res(w)*Qw + data.gamma_GB_res_2(w)*Qw.^2)) * dt;
end
a.IndPay = sum(sum(pin.*data.Qin_dem)) * dt;
a.ResPay = 0;
for m = 1:numel(data.nM)
    a.ResPay = a.ResPay + sum(pn(data.nM(m),:).*data.Qre_dem_m(m,:)) * dt;
end
end
