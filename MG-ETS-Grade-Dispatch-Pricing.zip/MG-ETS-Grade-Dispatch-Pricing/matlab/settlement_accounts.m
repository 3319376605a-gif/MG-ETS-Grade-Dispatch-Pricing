function accounts = settlement_accounts(resultsPath, xlsxPath, outXlsx)
%SETTLEMENT_ACCOUNTS  结算程序：计算各主体收益/成本/净收益
%
% 用到的数据：
%   - results.mat: results.*  (包含 HeatPrices, ElecPrices)
%   - case_14bus_6heat.xlsx: read_config_xlsx 读取映射与成本参数
%
% 输出：
%   - accounts: struct，含各主体明细与汇总
%   - 可选写出 outXlsx（结算表）
%
% 运行示例：
%   accounts = settlement_accounts('results.mat','case_14bus_6heat.xlsx','settlement.xlsx');

if nargin < 1 || isempty(resultsPath), resultsPath = fullfile('mat_results','results.mat'); end
if nargin < 2 || isempty(xlsxPath),   xlsxPath   = 'case_14bus_6heat.xlsx'; end
if nargin < 3, outXlsx = ''; end

S = load(resultsPath);
assert(isfield(S,'results'), 'results.mat 中未找到 results 结构体');
R = S.results;

data = read_config_xlsx(xlsxPath);

T  = data.T;
dt = 1;
if isfield(data,'dt') && ~isempty(data.dt), dt = data.dt; end

% 价格
pi_bus  = R.ElecPrices.pi_bus;          % NB x T
pi_tu   = R.HeatPrices.pi_tu;           % J x T
pi_in   = R.HeatPrices.pi_in;           % K x T
pi_node = R.HeatPrices.pi_node;         % Nheat x T（只有源/荷节点有值）

% ========== 工具函数 ==========
safe_get = @(st, fn) (isfield(st,fn) * st.(fn)); %#ok<NASGU>  % 不直接用
nan2zero = @(x) (replace_nan_with_zero(x));

% ========== 0) 上级电网（Pbuy / Psell 用外部电价结算） ==========
grid.pay_to_grid = sum(data.price_buy(:)'.*R.Pbuy(:)') * dt;      % 系统->上级电网支付
grid.recv_from_grid = sum(data.price_sell(:)'.*R.Psell(:)') * dt; % 上级电网->系统支付
grid.net_revenue = grid.pay_to_grid - grid.recv_from_grid;        % 上级电网净收入（正=赚）

% ========== 1) 常规发电机（Gen_Other） ==========
G = data.G;
gen_other = table((1:G)', data.busG(:), 'VariableNames', {'id','bus'});
gen_other.elec_revenue = zeros(G,1);
gen_other.gen_cost     = zeros(G,1);
for g = 1:G
    u = data.busG(g);
    Pg = R.Pg(g,:); % 1 x T
    gen_other.elec_revenue(g) = sum(pi_bus(u,:).*Pg) * dt;
    gen_other.gen_cost(g)     = sum(data.a_g(g).*Pg + data.a2_g(g).*(Pg.^2)) * dt;
end
gen_other.net_profit = gen_other.elec_revenue - gen_other.gen_cost;

% ========== 2) 新能源（Gen_New） ==========
GN = data.G_N;
gen_new = table((1:GN)', data.busG_N(:), 'VariableNames', {'id','bus'});
gen_new.elec_revenue = zeros(GN,1);
gen_new.gen_cost     = zeros(GN,1);
for n = 1:GN
    u = data.busG_N(n);
    Pn = R.Pn(n,:);
    gen_new.elec_revenue(n) = sum(pi_bus(u,:).*Pn) * dt;
    gen_new.gen_cost(n)     = sum(data.a_n(n).*Pn) * dt;
end
gen_new.net_profit = gen_new.elec_revenue - gen_new.gen_cost;

% ========== 3) 汽轮机（CHP） ==========
J = data.J;
tu = table((1:J)', data.busTu(:), data.nTu(:), 'VariableNames', {'id','bus','heat_node'});
tu.elec_revenue = zeros(J,1);
tu.heat_revenue = zeros(J,1);  % 向热网注入余热 Qtu_h 的收入（按节点热价）
tu.fuel_cost    = zeros(J,1);  % 5参数联合成本 C(P^EQ, H^EXT)
tu.pay_heat_in  = zeros(J,1);  % 为收到的高品位热 Qtu_r 支付（按 pi_tu）
for j = 1:J
    ub = data.busTu(j);
    hn = data.nTu(j);

    Ptu   = R.Ptu(j,:);
    Qtu_h = R.Qtu_h(j,:);
    Qtu_c = R.Qtu_c(j,:);
    Qtu_r = R.Qtu_r(j,:);

    tu.elec_revenue(j) = sum(pi_bus(ub,:).*Ptu) * dt;

    % pi_node(hn,:) 可能有 NaN（若 hn 不是源/荷节点），做保护
    pn = pi_node(hn,:);
    pn = nan2zero(pn);
    tu.heat_revenue(j) = sum(pn.*Qtu_h) * dt;

    % 修正后燃料成本：只对锅炉燃料汽 H^FH = Qtu_c 计费
    % C^CHP = a_j*(H^FH)^2 + b_j*H^FH（与 build_model.m 目标函数保持一致）
    tu.fuel_cost(j) = sum(data.CHP_a(j).*Qtu_c.^2 + data.CHP_b(j).*Qtu_c) * dt;
    tu.pay_heat_in(j) = sum(pi_tu(j,:).*Qtu_r) * dt;
end
tu.net_profit = tu.elec_revenue + tu.heat_revenue - tu.fuel_cost - tu.pay_heat_in;

% ========== 4) 蓄热体（电蓄热/储热） ==========
I = data.I;
st = table((1:I)', data.busES(:), data.nI(:), 'VariableNames', {'id','bus','heat_node'});
st.elec_payment = zeros(I,1);   % 用电侧 LMP 结算：正数=付钱（因为 Pes 通常为负荷）
st.heat_revenue = zeros(I,1);   % 卖热收入：卖给汽轮机/工业/居民
st.op_cost      = zeros(I,1);   % 目标函数中的 gamma_* 放热成本
for i = 1:I
    ub = data.busES(i);
    hn = data.nI(i);

    Pes = R.Pes(i,:);        % 电侧功率（负荷为正）
    st.elec_payment(i) = sum(pi_bus(ub,:).*Pes) * dt;

    % 1) 卖给汽轮机：sum_j pi_tu(j,t) * Q_i2j(i,j,t)
    Q_i2j_i = squeeze(R.Q_i2j(i,:,:)); % J x T
    rev_tu  = sum(sum(pi_tu .* Q_i2j_i)) * dt;

    % 2) 卖给工业：sum_k pi_in(k,t) * Q_i2k(i,k,t)
    Q_i2k_i = squeeze(R.Q_i2k(i,:,:)); % K x T
    rev_in  = sum(sum(pi_in .* Q_i2k_i)) * dt;

    % 3) 卖给居民（注入热网节点 hn）：pi_node(hn,t)*Q_i2n(i,t)
    pn = nan2zero(pi_node(hn,:));
    rev_re = sum(pn .* R.Q_i2n(i,:)) * dt;

    st.heat_revenue(i) = rev_tu + rev_in + rev_re;

    % 放热成本（与目标函数一致）
    st.op_cost(i) = ( ...
        sum(data.gamma_tu(i).*sum(Q_i2j_i,1)) + ...
        sum(data.gamma_in(i).*sum(Q_i2k_i,1)) + ...
        sum(data.gamma_re(i).*R.Q_i2n(i,:)) ...
        ) * dt;
end
st.net_profit = st.heat_revenue - st.elec_payment - st.op_cost;

% ========== 5) 工业蒸汽锅炉（Boiler_Ind） ==========
% 需要 results.Q_s2k 才能按 pi_in(k,t) 精确结算
Sbo = data.S;
bo_ind = table((1:Sbo)', 'VariableNames', {'id'});
bo_ind.heat_revenue = zeros(Sbo,1);
bo_ind.fuel_cost    = zeros(Sbo,1);

has_Qs2k = isfield(R,'Q_s2k') && ~isempty(R.Q_s2k);
if has_Qs2k
    % Q_s2k: S x K x T
    for s = 1:Sbo
        Qs = R.Qs(s,:);
        bo_ind.fuel_cost(s) = sum(data.gamma_GB_ind(s).*Qs + data.gamma_GB_ind_2(s).*Qs.^2) * dt;

        Q_s2k_s = squeeze(R.Q_s2k(s,:,:));  % K x T
        bo_ind.heat_revenue(s) = sum(sum(pi_in .* Q_s2k_s)) * dt;
    end
else
    % 退化结算：只算成本，不算收入（否则会误）
    for s = 1:Sbo
        Qs = R.Qs(s,:);
        bo_ind.fuel_cost(s) = sum(data.gamma_GB_ind(s).*Qs + data.gamma_GB_ind_2(s).*Qs.^2) * dt;
        bo_ind.heat_revenue(s) = NaN;
    end
end
bo_ind.net_profit = bo_ind.heat_revenue - bo_ind.fuel_cost;

% ========== 6) 居民水锅炉（Boiler_Res，接热网） ==========
W = data.W;
bo_res = table((1:W)', data.nW(:), 'VariableNames', {'id','heat_node'});
bo_res.heat_revenue = zeros(W,1);
bo_res.fuel_cost    = zeros(W,1);
for w = 1:W
    hn = data.nW(w);
    pn = nan2zero(pi_node(hn,:));
    Qw = R.Qw(w,:);
    bo_res.heat_revenue(w) = sum(pn .* Qw) * dt;
    bo_res.fuel_cost(w)    = sum(data.gamma_GB_res(w).*Qw + data.gamma_GB_res_2(w).*Qw.^2) * dt;
end
bo_res.net_profit = bo_res.heat_revenue - bo_res.fuel_cost;

% ========== 7) 工业用户（负荷侧支付） ==========
K = data.K;
ind_load = table((1:K)', 'VariableNames', {'id'});
ind_load.heat_payment = zeros(K,1);
for k = 1:K
    ind_load.heat_payment(k) = sum(pi_in(k,:).*data.Qin_dem(k,:)) * dt;
end

% ========== 8) 居民用户（热网负荷侧支付） ==========
% Res_Load 映射：data.M 个居民负荷接入节点 data.nM(mm)
M = data.M;
res_load = table((1:M)', data.nM(:), 'VariableNames', {'id','heat_node'});
res_load.heat_payment = zeros(M,1);
for m = 1:M
    hn = data.nM(m);
    pn = nan2zero(pi_node(hn,:));
    dem = data.Qre_dem_m(m,:); % 1 x T
    res_load.heat_payment(m) = sum(pn .* dem) * dt;
end

% ========== 汇总 ==========
accounts = struct();
accounts.meta.resultsPath = resultsPath;
accounts.meta.xlsxPath    = xlsxPath;
accounts.meta.dt          = dt;

accounts.grid      = grid;
accounts.gen_other = gen_other;
accounts.gen_new   = gen_new;
accounts.turbine   = tu;
accounts.storage   = st;
accounts.bo_ind    = bo_ind;
accounts.bo_res    = bo_res;
accounts.ind_load  = ind_load;
accounts.res_load  = res_load;

% 全系统现金流核对（不保证严格为0：热网价格只定义在源/荷节点，且管网存在损耗）
accounts.check.total_gen_profit = nansum(gen_other.net_profit)+nansum(gen_new.net_profit)+nansum(tu.net_profit)+nansum(st.net_profit)+nansum(bo_ind.net_profit)+nansum(bo_res.net_profit);
accounts.check.total_load_payment = sum(ind_load.heat_payment) + sum(res_load.heat_payment);

% 写出 Excel（可选）
if ~isempty(outXlsx)
    try
        writetable(struct2table_scalar(grid), outXlsx, 'Sheet', 'Grid', 'WriteMode','overwritesheet');
    catch
        % older MATLAB: ignore WriteMode
        writetable(struct2table_scalar(grid), outXlsx, 'Sheet', 'Grid');
    end
    writetable(gen_other, outXlsx, 'Sheet', 'Gen_Other');
    writetable(gen_new,   outXlsx, 'Sheet', 'Gen_New');
    writetable(tu,        outXlsx, 'Sheet', 'Turbine_CHP');
    writetable(st,        outXlsx, 'Sheet', 'Storage');
    writetable(bo_ind,    outXlsx, 'Sheet', 'Boiler_Ind');
    writetable(bo_res,    outXlsx, 'Sheet', 'Boiler_Res');
    writetable(ind_load,  outXlsx, 'Sheet', 'Ind_Load');
    writetable(res_load,  outXlsx, 'Sheet', 'Res_Load');

    chk = struct2table_scalar(accounts.check);
    writetable(chk, outXlsx, 'Sheet', 'Check');
end

% 命令行打印一个简表
fprintf('\n===== Settlement Summary (dt=%.4g) =====\n', dt);
fprintf('Grid net revenue      : %.6g\n', grid.net_revenue);
fprintf('Gen_Other total profit: %.6g\n', sum(gen_other.net_profit));
fprintf('Gen_New   total profit: %.6g\n', sum(gen_new.net_profit));
fprintf('Turbine   total profit: %.6g\n', sum(tu.net_profit));
fprintf('Storage   total profit: %.6g\n', sum(st.net_profit));
fprintf('Bo_Ind    total profit: %.6g\n', nansum(bo_ind.net_profit));
fprintf('Bo_Res    total profit: %.6g\n', sum(bo_res.net_profit));
fprintf('Loads heat payment    : %.6g (Ind + Res)\n', accounts.check.total_load_payment);
fprintf('=======================================\n\n');

end

% ---------- helpers ----------
function x = replace_nan_with_zero(x)
x(isnan(x)) = 0;
end

function T = struct2table_scalar(s)
fn = fieldnames(s);
vals = cell(numel(fn),1);
for i = 1:numel(fn)
    vals{i} = s.(fn{i});
end
T = cell2table(vals','VariableNames',fn');
end