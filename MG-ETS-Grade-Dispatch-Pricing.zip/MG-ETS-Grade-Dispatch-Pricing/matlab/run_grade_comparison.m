function summary = run_grade_comparison(xlsxPath)
%RUN_GRADE_COMPARISON  电蓄热"可供品级"消融实验（7 种情形）
%
%  对 {发电级 P, 工业级 I, 建筑级 B} 的全部非空子集（共 7 种）各跑一遍完整
%  调度+定价+结算流程（论文4.4节表1、表2）。
%
%  品级"关断"全部在 data 层完成，不改 build_model / solve_dispatch_milp /
%  settlement_accounts：
%     关 P  ->  data.A_i2j   = 0   (断开 蓄热体->汽轮机， con_tu 强制 Qtu_r=0)
%     关 I  ->  data.A_i2k   = 0   (断开 蓄热体->工业负荷)
%     关 B  ->  data.Q_re_max= 0   (0<=Q_i2n<=0 -> 强制 Q_i2n=0)
%  能量级联门控 yL/yM/yH 一律保留：此处关断的是"连接/管道"，不是器件能力。
%
%  说明：这 7 种是 {P,I,B} 子集格上的偏序，不是全序。
%  对任意 S ⊆ S' 有 C(S) >= C(S')（可行域嵌套 -> 成本弱增，结构性必然）；
%  但 {P,B} 与 {I,B} 互不包含，成本无法先验排序，只能实算。主要对比链为
%  {B} ⊂ {I,B} ⊂ {P,I,B}（全功能 vs 传统单建筑级），其余 4 种作连接受限
%  反事实，用来佐证"低品级负荷给储能提供了全天候放热口"这一机理。
%
%  用法:
%     summary = run_grade_comparison();                         % 默认 NEW 模板
%     summary = run_grade_comparison('your_template.xlsx');
%
%  输出:
%     summary                       : 7 行汇总表（成本/弃风/消纳率/九类主体收益/成本分解）
%     grade_comparison_summary.xlsx : 同上，写盘
%     results_case_<TAG>.mat        : 各情形完整结果
%     三张图: 成本&弃风 / 各主体收益 / Hasse(成本)

if nargin < 1 || isempty(xlsxPath)
    xlsxPath = 'case_14bus_6heat.xlsx';
end

outDir   = 'mat_results';                 % 所有 .mat 结果统一存放的新文件夹
if ~exist(outDir, 'dir'), mkdir(outDir); end

data     = read_config_xlsx(xlsxPath);
avail_re = sum(data.Gen_New_P(:));        % 全天可用风光 (MWh)，与情形无关

% ---- 7 种情形（按品级数降序：3 / 2 / 1） ----
% 列: tag, useP, useI, useB
defs = { ...
    'PIB', 1, 1, 1; ...   % 全分品级（现模型）
    'IB' , 0, 1, 1; ...   % 工业+建筑
    'PB' , 1, 0, 1; ...   % 发电+建筑（跳级，连接受限反事实）
    'PI' , 1, 1, 0; ...   % 发电+工业（无建筑放热口，反事实）
    'B'  , 0, 0, 1; ...   % 仅建筑（传统电蓄热基准 = 不分品级）
    'I'  , 0, 1, 0; ...   % 仅工业（反事实）
    'P'  , 1, 0, 0  };    % 仅发电（反事实，预计退化）
nC = size(defs, 1);

% ---- 预分配 ----
[Cost, Curtail, AccRate] = deal(nan(nC,1));
[GridNet, GenOther, GenNew, Turbine, Storage, BoInd, BoRes, IndPay, ResPay] = deal(nan(nC,1));
[CHPfuel, ConvGen, BoilCost, ETSom, GridBuy] = deal(nan(nC,1));
% 分品级热价（发电级/工业级/建筑级）与节点电价的均值/方差
[HeatPGen_mean, HeatPGen_std, HeatPInd_mean, HeatPInd_std, ...
 HeatPBld_mean, HeatPBld_std, ElecP_mean, ElecP_std] = deal(nan(nC,1));
tags = strings(nC,1);
sz   = zeros(nC,1);

for c = 1:nC
    tag  = defs{c,1};  useP = defs{c,2};  useI = defs{c,3};  useB = defs{c,4};
    tags(c) = string(tag);
    sz(c)   = useP + useI + useB;

    d = data;
    if ~useP, d.A_i2j    = zeros(size(d.A_i2j));    end
    if ~useI, d.A_i2k    = zeros(size(d.A_i2k));    end
    if ~useB, d.Q_re_max = zeros(size(d.Q_re_max)); end

    fprintf('\n############ CASE %d/%d : {%s}  (P=%d I=%d B=%d) ############\n', ...
            c, nC, tag, useP, useI, useB);

    results = solve_dispatch_milp(d);

    if isempty(results.Objective) || any(isnan(results.Objective(:)))
        warning('Case {%s} 无可行解/对偶异常，跳过该行。', tag);
        continue;
    end

    matname = fullfile(outDir, sprintf('results_case_%s.mat', tag));
    save(matname, 'results');

    acc = settlement_accounts(matname, xlsxPath, '');   % 复用现有结算，不改

    % ---------- 系统级指标 ----------
    Cost(c)    = results.Objective;                 % 总运行成本（MILP 目标值）
    disp_re    = sum(results.Pn(:));                % 实际消纳风光 (MWh)
    Curtail(c) = avail_re - disp_re;                % 弃风弃光 (MWh)
    AccRate(c) = 100 * disp_re / avail_re;          % 消纳率 (%)

    % ---------- 各主体收益（来自结算） ----------
    GridNet(c)  = acc.grid.net_revenue;
    GenOther(c) = sum(acc.gen_other.net_profit);
    GenNew(c)   = sum(acc.gen_new.net_profit);
    Turbine(c)  = sum(acc.turbine.net_profit);
    Storage(c)  = sum(acc.storage.net_profit);
    BoInd(c)    = sum(acc.bo_ind.net_profit, 'omitnan');
    BoRes(c)    = sum(acc.bo_res.net_profit);
    IndPay(c)   = sum(acc.ind_load.heat_payment);   % 工业用户支付（成本，越低越好）
    ResPay(c)   = sum(acc.res_load.heat_payment);   % 居民用户支付（成本，越低越好）

    % ---------- 成本分解（解释节省来源） ----------
    CHPfuel(c)  = sum(acc.turbine.fuel_cost);
    ConvGen(c)  = sum(acc.gen_other.gen_cost);
    BoilCost(c) = sum(acc.bo_ind.fuel_cost) + sum(acc.bo_res.fuel_cost);
    ETSom(c)    = sum(acc.storage.op_cost);
    GridBuy(c)  = acc.grid.pay_to_grid;

    % ---------- 分品级热价 & 节点电价：均值/方差 ----------
    % 关断某品级只是禁止电蓄热向其供热，该品级仍有 CHP/锅炉等热源，
    % 对偶仍为真实边际价，故各情形一律照常统计。
    HP = results.HeatPrices;
    [HeatPGen_mean(c), HeatPGen_std(c)] = price_mean_std(HP.pi_tu);
    [HeatPInd_mean(c), HeatPInd_std(c)] = price_mean_std(HP.pi_in);
    [HeatPBld_mean(c), HeatPBld_std(c)] = price_mean_std(HP.pi_node);
    [ElecP_mean(c),    ElecP_std(c)]    = price_mean_std(results.ElecPrices.pi_bus);
end

ConsumerPay = IndPay + ResPay;

summary = table( tags, sz, Cost, Curtail, AccRate, ...
    Storage, Turbine, GenNew, GenOther, BoInd, BoRes, IndPay, ResPay, ConsumerPay, GridNet, ...
    CHPfuel, ConvGen, BoilCost, ETSom, GridBuy, ...
    HeatPGen_mean, HeatPGen_std, HeatPInd_mean, HeatPInd_std, ...
    HeatPBld_mean, HeatPBld_std, ElecP_mean, ElecP_std, ...
    'VariableNames', { 'Case','GradeCount','TotalCost','Curtail_MWh','AccRate_pct', ...
        'Storage_profit','CHP_profit','RE_profit','ConvGen_profit','BoInd_profit','BoRes_profit', ...
        'IndLoad_pay','ResLoad_pay','Consumer_pay_total','Grid_net', ...
        'CHP_fuel_cost','ConvGen_cost','Boiler_cost','ETS_OM','Grid_buy_cost', ...
        'HeatPrice_Gen_mean','HeatPrice_Gen_std','HeatPrice_Ind_mean','HeatPrice_Ind_std', ...
        'HeatPrice_Bld_mean','HeatPrice_Bld_std','ElecPrice_mean','ElecPrice_std' } );

% ===================== 头条：全功能 vs 传统单品级 =====================
iFull = find(tags=="PIB", 1);
iTrad = find(tags=="B",   1);
fprintf('\n========== 头条对比：{P,I,B} 全分品级  vs  {B} 传统单品级 ==========\n');
if ~isempty(iFull) && ~isempty(iTrad) && ~isnan(Cost(iFull)) && ~isnan(Cost(iTrad))
    dCost = Cost(iTrad) - Cost(iFull);
    fprintf(' 总运行成本 : %12.1f  ->  %12.1f   (降低 %.1f, %.2f%%)\n', ...
        Cost(iTrad), Cost(iFull), dCost, 100*dCost/Cost(iTrad));
    fprintf(' 弃风弃光   : %12.1f  ->  %12.1f   MWh (减少 %.1f)\n', ...
        Curtail(iTrad), Curtail(iFull), Curtail(iTrad)-Curtail(iFull));
    fprintf(' 消纳率     : %11.2f%%  ->  %11.2f%%   (提升 %.2f 个百分点)\n', ...
        AccRate(iTrad), AccRate(iFull), AccRate(iFull)-AccRate(iTrad));
    fprintf(' 用户总支付 : %12.1f  ->  %12.1f   (下降 %.1f)\n', ...
        ConsumerPay(iTrad), ConsumerPay(iFull), ConsumerPay(iTrad)-ConsumerPay(iFull));
    fprintf(' 电蓄热收益 : %12.1f  ->  %12.1f   (变化 %.1f)\n', ...
        Storage(iTrad), Storage(iFull), Storage(iFull)-Storage(iTrad));
    fprintf(' 传统热源   : 工业锅炉 %.1f->%.1f, 居民锅炉 %.1f->%.1f, CHP燃料 %.1f->%.1f\n', ...
        BoInd(iTrad),BoInd(iFull), BoRes(iTrad),BoRes(iFull), CHPfuel(iTrad),CHPfuel(iFull));
end
fprintf('   （注：传统热源被挤出边际、收益下降，是分品级的市场化激励信号，非异常）\n');

disp(' '); disp(summary);

% ---- 写盘 ----
try
    writetable(summary, 'grade_comparison_summary.xlsx', 'WriteMode', 'overwritesheet');
catch
    writetable(summary, 'grade_comparison_summary.xlsx');
end
fprintf('\n>> 已写出 grade_comparison_summary.xlsx\n');

% ---- 画图 ----
plot_cost_curtail(summary);
plot_stakeholders(summary);
plot_hasse(summary);

% ---- 论文用中文表（直接贴 Word）----
export_paper_tables(summary);

end


%% ================= 局部函数：成本 & 弃风 =================
function plot_cost_curtail(S)
X = categorical(S.Case);
X = reordercats(X, cellstr(S.Case));

figure('Name','Cost & Curtailment','Color','w','Position',[100 100 980 380]);

subplot(1,2,1);
b1 = bar(X, S.TotalCost, 0.6); grid on; box on;
highlight_full_trad(b1, S);
ylabel('系统总运行成本'); title('(a) 总运行成本'); set(gca,'FontSize',11);

subplot(1,2,2);
b2 = bar(X, S.Curtail_MWh, 0.6); grid on; box on;
highlight_full_trad(b2, S);
ylabel('弃风弃光量 / MWh'); title('(b) 弃风弃光'); set(gca,'FontSize',11);
end

function highlight_full_trad(b, S)
% 全功能(PIB)上色为绿、传统(B)为红，其余灰
n = height(S);
b.FaceColor = 'flat';
b.CData = repmat([0.60 0.60 0.62], n, 1);          % 默认灰：反事实
for i = 1:n
    switch char(S.Case(i))
        case 'PIB', b.CData(i,:) = [0.20 0.60 0.25];   % 绿：最优
        case 'B'  , b.CData(i,:) = [0.80 0.25 0.20];   % 红：传统基准
    end
end
end


%% ================= 局部函数：各利益主体 =================
function plot_stakeholders(S)
X = categorical(S.Case);
X = reordercats(X, cellstr(S.Case));

figure('Name','Stakeholder accounts','Color','w','Position',[120 120 1040 760]);

% (a) 供给侧收益
subplot(2,1,1);
Ysup = [S.Storage_profit, S.CHP_profit, S.RE_profit, S.ConvGen_profit, S.BoInd_profit, S.BoRes_profit];
bar(X, Ysup); grid on; box on;
ylabel('净收益'); title('(a) 供给侧主体净收益');
legend({'电蓄热','热电联产','新能源','常规机组','工业锅炉','居民锅炉'}, ...
       'Location','bestoutside'); set(gca,'FontSize',11);

% (b) 用热侧支付（越低越好）
subplot(2,1,2);
Ypay = [S.IndLoad_pay, S.ResLoad_pay, S.Consumer_pay_total];
bar(X, Ypay); grid on; box on;
ylabel('用热支付（成本）'); title('(b) 用热侧支付（越低对用户越有利）');
legend({'工业用户','居民用户','用户合计'}, 'Location','bestoutside');
set(gca,'FontSize',11);
end


%% ================= 局部函数：Hasse 图（成本） =================
function plot_hasse(S)
% {P,I,B} 子集格的固定坐标
coord = containers.Map();
coord('PIB') = [2 3];
coord('IB')  = [1 2]; coord('PB') = [2 2]; coord('PI') = [3 2];
coord('B')   = [1 1]; coord('I')  = [2 1]; coord('P')  = [3 1];

% 覆盖关系（|S'|=|S|+1 且 S ⊂ S'）
edges = { 'PIB','IB'; 'PIB','PB'; 'PIB','PI'; ...
          'IB','B';  'IB','I'; ...
          'PB','B';  'PB','P'; ...
          'PI','I';  'PI','P' };

% 成本查表
costMap = containers.Map();
for i = 1:height(S)
    costMap(char(S.Case(i))) = S.TotalCost(i);
end
cvals = S.TotalCost(~isnan(S.TotalCost));
cmin = min(cvals); cmax = max(cvals);

figure('Name','Hasse (TotalCost)','Color','w','Position',[150 150 620 560]); hold on;

% 边
for e = 1:size(edges,1)
    a = coord(edges{e,1}); b = coord(edges{e,2});
    plot([a(1) b(1)], [a(2) b(2)], '-', 'Color',[0.6 0.6 0.6], 'LineWidth',1.2);
end

% 节点
ks = keys(coord);
for i = 1:numel(ks)
    t = ks{i}; p = coord(t);
    if isKey(costMap, t) && ~isnan(costMap(t))
        cst = costMap(t);
        frac = 0.5; if cmax>cmin, frac = (cst-cmin)/(cmax-cmin); end
        col = [0.20+0.65*frac, 0.65-0.45*frac, 0.25];   % 低成本=绿，高成本=红
        lbl = { sprintf('\\{%s\\}', t); sprintf('%.0f', cst) };
    else
        col = [0.7 0.7 0.7]; lbl = { sprintf('\\{%s\\}', t); 'NaN' };
    end
    plot(p(1), p(2), 'o', 'MarkerSize',46, 'MarkerFaceColor',col, ...
         'MarkerEdgeColor','k', 'LineWidth',1.2);
    text(p(1), p(2), lbl, 'HorizontalAlignment','center', ...
         'VerticalAlignment','middle', 'FontSize',9, 'FontWeight','bold', 'Color','w');
end

text(2,3.45,'3 个品级','HorizontalAlignment','center','FontSize',10);
text(2,2.45,'2 个品级','HorizontalAlignment','center','FontSize',10);
text(2,0.55,'1 个品级','HorizontalAlignment','center','FontSize',10);

axis([0.3 3.7 0.3 3.7]); axis off;
title('可供品级子集格 — 节点标注总运行成本（绿=低/优, 红=高）');
hold off;
end


%% ================= 局部函数：价格均值/标准差（忽略 NaN） =================
function [m, s] = price_mean_std(X)
% 价格矩阵展平、剔除 NaN（如节点热价中非源/荷节点）后求均值与标准差。
% std 默认 N-1 归一化（样本标准差）；如需总体标准差改 std(x) -> std(x,1)。
x = X(:);
x = x(~isnan(x));
if isempty(x)
    m = NaN; s = NaN;
else
    m = mean(x);
    s = std(x);
end
end


%% ================= 局部函数：论文用中文表（贴 Word） =================
function export_paper_tables(S)
% 生成三张排版好的中文表，写入 paper_tables.xlsx，可直接复制进 Word。
% 表1 系统级：成本(万元)、相对本文增幅、弃风、消纳率
% 表2 供给侧主体净收益：电蓄热/热电联产/新能源/常规机组/工业锅炉/居民锅炉(均万元，正=盈利)
% 表3 分品级价格水平与波动：发电级/工业级/建筑级热价、节点电价(均值±标准差, 元/MWh)

% 情形 -> 中文标签（按品级数降序固定行序）
keysC = {'PIB','IB','PB','PI','B','I','P'};
lblsC = {'发电+工业+建筑（本文）','工业+建筑','发电+建筑','发电+工业', ...
         '仅建筑（传统）','仅工业','仅发电'};
labelMap = containers.Map(keysC, lblsC);

n = height(S);
iFull = find(S.Case=="PIB",1);
costFull = S.TotalCost(iFull);

w = @(x) round(x/1e4, 2);   % 元 -> 万元，保留两位

% ---------- 表1 系统级 ----------
hdr1 = {'品级配置','品级数','总运行成本/万元','相对本文增幅/%','弃风弃光/MWh','新能源消纳率/%'};
C1 = cell(n+1, numel(hdr1)); C1(1,:) = hdr1;
for i = 1:n
    cs = char(S.Case(i));
    C1{i+1,1} = labelMap(cs);
    C1{i+1,2} = S.GradeCount(i);
    C1{i+1,3} = w(S.TotalCost(i));
    C1{i+1,4} = round(100*(S.TotalCost(i)-costFull)/costFull, 2);
    C1{i+1,5} = round(S.Curtail_MWh(i), 1);
    C1{i+1,6} = round(S.AccRate_pct(i), 2);
end

% ---------- 表2 供给侧主体净收益（万元，正=盈利） ----------
hdr2 = {'品级配置','电蓄热/万元','热电联产/万元','新能源/万元','常规机组/万元','工业锅炉/万元','居民锅炉/万元'};
C2 = cell(n+1, numel(hdr2)); C2(1,:) = hdr2;
for i = 1:n
    cs = char(S.Case(i));
    C2{i+1,1} = labelMap(cs);
    C2{i+1,2} = w(S.Storage_profit(i));
    C2{i+1,3} = w(S.CHP_profit(i));
    C2{i+1,4} = w(S.RE_profit(i));
    C2{i+1,5} = w(S.ConvGen_profit(i));
    C2{i+1,6} = w(S.BoInd_profit(i));
    C2{i+1,7} = w(S.BoRes_profit(i));
end

% ---------- 表3 分品级价格水平与波动（均值/标准差分列, 元/MWh） ----------
hdr3 = {'品级配置', ...
        '发电级热价均值/(元/MWh)','发电级热价标准差/(元/MWh)', ...
        '工业级热价均值/(元/MWh)','工业级热价标准差/(元/MWh)', ...
        '建筑级热价均值/(元/MWh)','建筑级热价标准差/(元/MWh)', ...
        '节点电价均值/(元/MWh)','节点电价标准差/(元/MWh)'};
w2 = @(x) round(x, 2);   % 保留两位，元/MWh
C3 = cell(n+1, numel(hdr3)); C3(1,:) = hdr3;
for i = 1:n
    cs = char(S.Case(i));
    C3{i+1,1} = labelMap(cs);
    C3{i+1,2} = w2(S.HeatPrice_Gen_mean(i));
    C3{i+1,3} = w2(S.HeatPrice_Gen_std(i));
    C3{i+1,4} = w2(S.HeatPrice_Ind_mean(i));
    C3{i+1,5} = w2(S.HeatPrice_Ind_std(i));
    C3{i+1,6} = w2(S.HeatPrice_Bld_mean(i));
    C3{i+1,7} = w2(S.HeatPrice_Bld_std(i));
    C3{i+1,8} = w2(S.ElecPrice_mean(i));
    C3{i+1,9} = w2(S.ElecPrice_std(i));
end

out = 'paper_tables.xlsx';
if exist(out,'file'), delete(out); end
try
    writecell(C1, out, 'Sheet','表1_系统级');
    writecell(C2, out, 'Sheet','表2_供给侧收益');
    writecell(C3, out, 'Sheet','表3_分品级价格');
catch   % 老版本无 writecell，退回 cell2table+writetable
    writetable(cell2table(C1(2:end,:),'VariableNames',matlab.lang.makeValidName(hdr1)), out, 'Sheet','表1_系统级');
    writetable(cell2table(C2(2:end,:),'VariableNames',matlab.lang.makeValidName(hdr2)), out, 'Sheet','表2_供给侧收益');
    writetable(cell2table(C3(2:end,:),'VariableNames',matlab.lang.makeValidName(hdr3)), out, 'Sheet','表3_分品级价格');
end
fprintf('\n>> 论文用表已写出 %s（表1_系统级 / 表2_供给侧收益 / 表3_分品级价格）\n', out);

% ---------- 控制台预览表1 ----------
fprintf('\n=== 论文表1（系统级）===\n');
fprintf('%-26s %-6s %-14s %-14s %-12s %-12s\n', hdr1{:});
for i = 1:n
    fprintf('%-26s %-6d %-14.2f %-14.2f %-12.1f %-12.2f\n', ...
        C1{i+1,1}, C1{i+1,2}, C1{i+1,3}, C1{i+1,4}, C1{i+1,5}, C1{i+1,6});
end

% ---------- 控制台预览表2 ----------
fprintf('\n=== 论文表2（供给侧主体净收益, 万元）===\n');
fprintf('%-22s %-9s %-9s %-9s %-9s %-9s %-9s\n', ...
    '品级配置','电蓄热','热电联产','新能源','常规机组','工业锅炉','居民锅炉');
for i = 1:n
    fprintf('%-22s %-9.2f %-9.2f %-9.2f %-9.2f %-9.2f %-9.2f\n', ...
        C2{i+1,1}, C2{i+1,2}, C2{i+1,3}, C2{i+1,4}, C2{i+1,5}, C2{i+1,6}, C2{i+1,7});
end

% ---------- 控制台预览表3 ----------
fprintf('\n=== 论文表3（分品级价格 均值/标准差, 元/MWh）===\n');
fprintf('%-22s %-9s %-9s %-9s %-9s %-9s %-9s %-9s %-9s\n', ...
    '品级配置','发电均','发电标','工业均','工业标','建筑均','建筑标','电价均','电价标');
for i = 1:n
    fprintf('%-22s %-9.2f %-9.2f %-9.2f %-9.2f %-9.2f %-9.2f %-9.2f %-9.2f\n', ...
        C3{i+1,1}, C3{i+1,2}, C3{i+1,3}, C3{i+1,4}, C3{i+1,5}, ...
        C3{i+1,6}, C3{i+1,7}, C3{i+1,8}, C3{i+1,9});
end
end
