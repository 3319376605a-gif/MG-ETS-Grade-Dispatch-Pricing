function run_four_seasons(xlsxPath)
%RUN_FOUR_SEASONS  四季典型日 × 8 种配置的调度与定价（论文4.5节）
%  配置：无电蓄热 + 7 种可供热品级组合；目标函数计入弃电成本（模板 Meta 表 c_curt）。
%  典型日采用周期性储能（日末储能量=日初储能量，日初储能量为决策变量），便于按天数折算全年。
%  结果逐个保存为 mat_results/season/<季节>_<配置>.mat，已存在的工况自动跳过（可断点续跑）。
if nargin < 1 || isempty(xlsxPath), xlsxPath = 'case_14bus_6heat.xlsx'; end
outDir = fullfile('mat_results', 'season');
if ~exist(outDir, 'dir'), mkdir(outDir); end

base  = read_config_xlsx(xlsxPath);
S     = season_table();
CASES = {'NoETS','PIB','IB','PB','PI','B','I','P'};

for s = 1:numel(S)
    for c = 1:numel(CASES)
        f = fullfile(outDir, sprintf('%s_%s.mat', S(s).name, CASES{c}));
        if exist(f, 'file'), continue; end
        d = build_case(season_data(base, S(s).name), CASES{c});
        d.cyclic = true;
        t0 = tic;
        results = solve_dispatch_milp(d);
        curt = sum(d.Gen_New_P(:)) - sum(results.Pn(:));
        fprintf('[%s %-5s] 目标值 = %.1f 元，弃电 = %.1f MWh，用时 %.0f s\n', ...
                S(s).cn, CASES{c}, results.Objective, curt, toc(t0));
        save(f, 'results', 'd');
    end
end
end
