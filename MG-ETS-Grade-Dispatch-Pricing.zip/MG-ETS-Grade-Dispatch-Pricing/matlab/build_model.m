%% ========================================================================
function [model, handles] = build_model(data, y_fix)
% y_fix: [] 或 struct(yL,yM,yH) 固定值
% 输出：
%  model.C, model.obj
%  handles: 关键变量与对偶约束句柄

T  = data.T;
NB = data.NB;

% ------------------ 变量 ------------------
E    = sdpvar(data.I, T, 'full');
Qch  = sdpvar(data.I, T, 'full');
Qdis = sdpvar(data.I, T, 'full');
Pes  = sdpvar(data.I, T, 'full');

Q_i2j = sdpvar(data.I, data.J, T, 'full');
Q_i2k = sdpvar(data.I, data.K, T, 'full');
Q_i2n = sdpvar(data.I, T, 'full');

if isempty(y_fix)
    yL = binvar(data.I, T, 'full');
    yM = binvar(data.I, T, 'full');
    yH = binvar(data.I, T, 'full');
else
    yL = sdpvar(data.I, T, 'full');
    yM = sdpvar(data.I, T, 'full');
    yH = sdpvar(data.I, T, 'full');
end

Ptu = sdpvar(data.J, T, 'full');
Pg  = sdpvar(data.G, T, 'full');
Pn  = sdpvar(data.G_N, T, 'full');

Pbuy = sdpvar(1, T, 'full');   % 从上级电网购电（MW）
Psell = sdpvar(1, T, 'full');  % 向上级电网上网（MW）

Qtu_r = sdpvar(data.J, T, 'full');
Qtu_c = sdpvar(data.J, T, 'full');
Qtu_h = sdpvar(data.J, T, 'full');
Qtu_dump = sdpvar(data.J, T, 'full'); %弃热

Qs = sdpvar(data.S, T, 'full');
Qw = sdpvar(data.W, T, 'full');

Q_s2k = sdpvar(data.S, data.K, data.T, 'full');

% 节点温度（混合后节点出流温度）
Ts_node = sdpvar(data.Nheat, T, 'full');
Tr_node = sdpvar(data.Nheat, T, 'full');

% 供水/回水每条管道两端温度
Ts_sup_from = sdpvar(data.Es, T, 'full');
Ts_sup_to   = sdpvar(data.Es, T, 'full');
Tr_ret_from = sdpvar(data.Er, T, 'full');
Tr_ret_to   = sdpvar(data.Er, T, 'full');

theta = sdpvar(NB, T, 'full');
Pflow = sdpvar(data.L, T, 'full');

% ------------------ 约束 ------------------
C = [];

if ~isempty(y_fix)
    C = [C, yL == y_fix.yL, yM == y_fix.yM, yH == y_fix.yH];
end

Mbig = data.BigM;

% ---- S2: 蓄热体能量/功率 ----
% 周期性储能（论文4.5节四季典型日）：日初储能量为决策变量且日末=日初；
% data.cyclic 缺省或为 false 时与原模型一致（日初储能固定为 E0）
if isfield(data,'cyclic') && data.cyclic
    Einit = sdpvar(data.I, 1, 'full');
    C = [C, data.Emin(:) <= Einit <= data.Emax(:), E(:,T) == Einit];
else
    Einit = data.E0(:);
end
for i = 1:data.I
    for t = 1:T
        if t == 1
            C = [C, E(i,t) == data.eta_loss(i)*Einit(i) + data.eta_ch(i)*Qch(i,t)*data.dt ...
                           - (1/data.eta_dis(i))*Qdis(i,t)*data.dt];
        else
            C = [C, E(i,t) == data.eta_loss(i)*E(i,t-1) + data.eta_ch(i)*Qch(i,t)*data.dt ...
                           - (1/data.eta_dis(i))*Qdis(i,t)*data.dt];
        end

        C = [C, Qch(i,t) == data.eta_eh(i) * Pes(i,t)];
        C = [C, data.Pes_min(i) <= Pes(i,t) <= data.Pes_max(i)];
        C = [C, data.Qdis_min(i) <= Qdis(i,t) <= data.Qdis_max(i)];
        C = [C, data.Emin(i) <= E(i,t) <= data.Emax(i)];
    end
end

% 放热分解 + 连接关系
for i = 1:data.I
    for t = 1:T
        for j = 1:data.J
            if data.A_i2j(i,j) == 0
                C = [C, Q_i2j(i,j,t) == 0];
            else
                C = [C, Q_i2j(i,j,t) >= 0];
            end
        end
        for k = 1:data.K
            if data.A_i2k(i,k) == 0
                C = [C, Q_i2k(i,k,t) == 0];
            else
                C = [C, Q_i2k(i,k,t) >= 0];
            end
        end
        C = [C, Q_i2n(i,t) >= 0];

        C = [C, Qdis(i,t) == sum(Q_i2j(i,:,t), 2) + sum(Q_i2k(i,:,t), 2) + Q_i2n(i,t)];
    end
end

% ---- S2: 分段能量区间 + 供热路径 ----
for i = 1:data.I
    for t = 1:T
        C = [C, yL(i,t) + yM(i,t) + yH(i,t) == 1];

        EL = data.EL(i);
        EH = data.EH(i);

        C = [C, E(i,t) <= EL + Mbig*(1 - yL(i,t))];
        C = [C, E(i,t) >= data.Emin(i) - Mbig*(1 - yL(i,t))];

        C = [C, E(i,t) >= EL - Mbig*(1 - yM(i,t))];
        C = [C, E(i,t) <= EH + Mbig*(1 - yM(i,t))];

        C = [C, E(i,t) >= EH - Mbig*(1 - yH(i,t))];
        C = [C, E(i,t) <= data.Emax(i) + Mbig*(1 - yH(i,t))];

        C = [C, sum(Q_i2j(i,:,t),2) <= data.Q_tu_max(i) * yH(i,t)];
        C = [C, sum(Q_i2k(i,:,t),2) <= data.Q_in_max(i) * (yM(i,t) + yH(i,t))];
        C = [C, Q_i2n(i,t) <= data.Q_re_max(i)];
    end
end

% ---- S3: DC 潮流 ----
con_elec = cell(NB, T);   % 节点电力平衡（用于取对偶：节点电价）
for t = 1:T
    for l = 1:data.L
        u = data.line_from(l);
        v = data.line_to(l);
        x = data.line_x(l);
        C = [C, Pflow(l,t) == (theta(u,t) - theta(v,t)) / x];
        C = [C, -data.line_Pmax(l) <= Pflow(l,t) <= data.line_Pmax(l)];
    end

    C = [C, theta(data.SlackBus,t) == 0];
    %上级电网
        C = [C, 0 <= Pbuy(1,t) <= data.Pbuy_max];
        C = [C, 0 <= Psell(1,t) <= data.Psell_max];
        if t >= 2
            C = [C, -data.Pbuy_ramp_down <= (Pbuy(1,t)-Pbuy(1,t-1)) <= data.Pbuy_ramp_up];
            C = [C, -data.Pbuy_ramp_down <= (Psell(1,t)-Psell(1,t-1)) <= data.Pbuy_ramp_up];
        end
    %汽轮机
    for j = 1:data.J
             C = [C, data.Ptu_min(j)   <= Ptu(j,t)    <= data.Ptu_max(j)];
             C = [C, data.Qtu_h_min(j) <= Qtu_h(j,t)  <= data.Qtu_h_max(j)];
             C = [C, data.Qtu_c_min(j) <= Qtu_c(j,t)  <= data.Qtu_c_max(j)];
             C = [C, data.Qtu_r_min(j) <= Qtu_r(j,t)  <= data.Qtu_r_max(j)];
             C = [C, Qtu_dump(j,t) >= 0]; 
             QinH = Qtu_c(j,t) + Qtu_r(j,t);
             C = [C, Ptu(j,t) <= data.k_tu(j)*QinH- data.k_cond(j) * Qtu_h(j,t)];
             C = [C, Qtu_h(j,t) <= data.k_tu2(j)*QinH];
    if t >= 2
        C = [C, -data.Ptu_ramp_down(j) <= (Ptu(j,t)-Ptu(j,t-1)) <= data.Ptu_ramp_up(j)];
    end

    end
    %传统发电机
    for g = 1:data.G
        C = [C, data.Pg_min(g) <= Pg(g,t) <= data.Pg_max(g)];
        if t >= 2
            C = [C, -data.Pg_ramp_down(g) <= (Pg(g,t)-Pg(g,t-1)) <= data.Pg_ramp_up(g)];
        end
    end
    %新能源
    for gn = 1:data.G_N
        C = [C, 0 <= Pn(gn,t) <= data.Gen_New_P(gn,t)];
    end

    for u = 1:NB
        idxTu = find(data.busTu == u);
        idxG  = find(data.busG  == u);
        idxGN  = find(data.busG_N  == u);
        idxUp  = find(data.busUp  == u);

        Pg_u  = sum(Ptu(idxTu,t)) + sum(Pg(idxG,t)) + sum(Pn(idxGN,t))+ sum(Pbuy(idxUp,t)) - sum(Psell(idxUp,t));

        Pd_u = data.Pd(u,t);

        idxES = find(data.busES == u);
        Pes_u = sum(Pes(idxES,t));

        outL = find(data.line_from == u);
        inL  = find(data.line_to   == u);
        Pinj = sum(Pflow(outL,t)) - sum(Pflow(inL,t));

        con_elec{u,t} = ( Pg_u - Pd_u - Pes_u == Pinj );
        C = [C, con_elec{u,t}];

    end
end

% ---- S3: 热平衡 ----

%S3(1)产热主体约束

%工业蒸汽锅炉
for s = 1:data.S
    for t = 1:T
        C = [C, data.Qs_min(s) <= Qs(s,t) <= data.Qs_max(s)];
    end
end
%居民水锅炉
for w = 1:data.W
    for t = 1:T
        C = [C, data.Qw_min(w) <= Qw(w,t) <= data.Qw_max(w)];
    end
end
%汽轮机
con_tu = cell(data.J, T);
for j = 1:data.J
    for t = 1:T
        con_tu{j,t} = ( Qtu_r(j,t) == sum(Q_i2j(:,j,t),1)' );
        C = [C, con_tu{j,t}];
    end
end

%S3(2)热平衡约束

%给汽轮机的在DC潮流里面

% 工业负荷
con_in = cell(data.K, data.T);   
for t = 1:data.T
    for s = 1:data.S
        alloc_sum = 0;
        for k = 1:data.K
            alloc_sum = alloc_sum + data.A_s2k(s,k) * Q_s2k(s,k,t);
        end
        C= [C, Qs(s,t) == alloc_sum];
    end
    for k = 1:data.K
        Q_es = 0;
        for i = 1:data.I
            Q_es = Q_es + data.A_i2k(i,k) * Q_i2k(i,k,t);  
        end
        Q_bo_k = 0;
        for s = 1:data.S
            Q_bo_k = Q_bo_k + data.A_s2k(s,k) * Q_s2k(s,k,t);
        end
        con_in{k,t} = ( data.Qin_dem(k,t) == Q_es + Q_bo_k );
        C = [C, con_in{k,t}];
    end
end
C = [C, Q_s2k >= 0];

% ---- 居民热负荷总供需平衡（有热网） ----
MW2W = 1e6;
% ---- 供水/回水：管道起点温度=节点温度 ----
for t = 1:T
    for e = 1:data.Es
        u = data.sup_from(e);
        C = [C, Ts_sup_from(e,t) == Ts_node(u,t)];
    end
    for e = 1:data.Er
        u = data.ret_from(e);
        C = [C, Tr_ret_from(e,t) == Tr_node(u,t)];
    end
end
% ---- 热源 / 负荷节点识别 ----
src_nodes  = unique([data.nI(:); data.nW(:); data.nTu(:)]);  % 热源节点（蓄热体居民侧 + 居民锅炉）
load_nodes = unique(data.nM(:));                % 负荷节点（居民负荷）

% ---- 供水/回水：（热源/负荷）管道终点温度=节点温度 ----
for t = 1:T
    for ii = 1:length(src_nodes)
        n = src_nodes(ii);

        % 所有“终点在该热源节点”的回水管段
        inE = find(data.ret_to == n);

        for k = 1:length(inE)
            e = inE(k);
            C = [C, Tr_ret_to(e,t) == Tr_node(n,t)];
        end
    end
end
for t = 1:T
    for ii = 1:length(load_nodes)
        n = load_nodes(ii);

        % 所有“终点在该负荷节点”的供水管段
        inR = find(data.sup_to == n);

        for k = 1:length(inR)
            e = inR(k);
            C = [C, Ts_sup_to(e,t) == Ts_node(n,t)];
        end
    end
end




% ---- 管道温降公式 ----

for t = 1:T
    for e = 1:data.Es
        u = data.sup_from(e);
        m = data.sup_m(e);
        cw = data.cw(u);
        alpha = exp( -data.Heat_transfer_rate * data.sup_len(e) / (MW2W*cw*m)) ;
        C = [C, Ts_sup_to(e,t) == data.T_out_pipeline_equivalent + (Ts_sup_from(e,t) - data.T_out_pipeline_equivalent) * alpha ];
    end
    for e = 1:data.Er
        u = data.ret_from(e);
        m = data.ret_m(e);
        cw = data.cw(u);
        alpha = exp( -data.Heat_transfer_rate * data.ret_len(e) /  (MW2W*cw*m)) ;
        C = [C, Tr_ret_to(e,t) == data.T_out_pipeline_equivalent + (Tr_ret_from(e,t) - data.T_out_pipeline_equivalent) * alpha ];
    end
end

% ---- 源/荷节点换热公式 ----

src_nodes  = unique([data.nI(:); data.nW(:); data.nTu(:)]);
load_nodes = unique(data.nM(:));

con_src = cell(length(src_nodes), T);
con_load = cell(length(load_nodes), T);

for t = 1:T
    % 每个热源节点：Q_src = cw*mcir*(Ts-Tr)
    for a = 1:length(src_nodes)
        n = src_nodes(a);
        Qsrc = 0;
        % 蓄热体 -> 居民侧供热
        idxI = find(data.nI == n);
        for ii = 1:length(idxI)
            Qsrc = Qsrc + Q_i2n(idxI(ii), t);
        end
        % 居民锅炉
        idxW = find(data.nW == n);
        for ww = 1:length(idxW)
            Qsrc = Qsrc + Qw(idxW(ww), t);
        end
        %汽轮机余热注入
        idxTuH = find(data.nTu == n);
        for jj = 1:length(idxTuH)
            Qsrc = Qsrc + Qtu_h(idxTuH(jj), t);
        end
        con_src{a,t} = ( Qsrc  == data.cw(n) * data.mcir(n) * (Ts_node(n,t) - Tr_node(n,t)) );
        C = [C, con_src{a,t}];
    end 

    % 每个负荷节点：Q_load = cw*mcir*(Ts-Tr)
    for b = 1:length(load_nodes)
        n = load_nodes(b);
        Qload = 0;
        idxM = find(data.nM == n);
        for mm = 1:length(idxM)
            Qload = Qload + data.Qre_dem_m(idxM(mm), t);
        end
        con_load{b,t} = ( Qload  == data.cw(n) * data.mcir(n) * (Ts_node(n,t) - Tr_node(n,t)) );
        C = [C, con_load{b,t}];
    end
end

% ---- 节点混合约束（只对中间节点 mid_nodes 加） ----
all_nodes  = (1:data.Nheat).';
src_nodes  = unique([data.nI(:); data.nW(:); data.nTu(:)]);
load_nodes = unique(data.nM(:));
mid_nodes  = setdiff(all_nodes, union(src_nodes, load_nodes));

for t = 1:T
    for nn = 1:length(mid_nodes)
        n = mid_nodes(nn);

        % ---------- 供水侧：进入该节点的管段混合 ----------
        inE = find(data.sup_to == n);   % 供水流入该节点的管段
        if ~isempty(inE)
            m_in = sum(data.sup_m(inE));      % 入流总质量流（常数）
            sumTin = 0;
            for ii = 1:length(inE)
                e = inE(ii);
                sumTin = sumTin + data.sup_m(e) * Ts_sup_to(e,t);
            end
            C = [C, m_in * Ts_node(n,t) == sumTin];
        end

        % ---------- 回水侧：进入该节点的管段混合 ----------
        inR = find(data.ret_to == n);   % 回水流入该节点的管段
        if ~isempty(inR)
            m_inR = sum(data.ret_m(inR));
            sumTrin = 0;
            for ii = 1:length(inR)
                e = inR(ii);
                sumTrin = sumTrin + data.ret_m(e) * Tr_ret_to(e,t);
            end
            C = [C, m_inR * Tr_node(n,t) == sumTrin];
        end
    end
end

% ---- 温度范围限制（节点、管道两端都加） ----
for t = 1:T
    for n = 1:data.Nheat
        C = [C, data.Tsup_min(n) <= Ts_node(n,t) <= data.Tsup_max(n)];
        C = [C, data.Tret_min(n) <= Tr_node(n,t) <= data.Tret_max(n)];
    end
    for e = 1:data.Es
        u = data.sup_from(e);
        v = data.sup_to(e);
        C = [C, data.Tsup_min(u) <= Ts_sup_from(e,t) <= data.Tsup_max(u)];
        C = [C, data.Tsup_min(v) <= Ts_sup_to(e,t)   <= data.Tsup_max(v)];
    end
    for e = 1:data.Er
        u = data.ret_from(e);
        v = data.ret_to(e);
        C = [C, data.Tret_min(u) <= Tr_ret_from(e,t) <= data.Tret_max(u)];
        C = [C, data.Tret_min(v) <= Tr_ret_to(e,t)   <= data.Tret_max(v)];
    end
end

% ------------------ 目标函数 ------------------
obj = 0;

for t = 1:T
    obj = obj + (data.price_buy(t) * Pbuy(1,t) - data.price_sell(t) * Psell(1,t));
end

for gn = 1:data.G_N
    for t = 1:T
        % 新能源发电成本 + 弃电成本（弃电量 x 单位弃电成本 c_curt）
        obj = obj + data.a_n(gn) * Pn(gn,t) + data.c_curt * (data.Gen_New_P(gn,t) - Pn(gn,t));
    end
end

for g = 1:data.G
    for t = 1:T
        obj = obj + data.a_g(g) * Pg(g,t) + data.a2_g(g) * Pg(g,t)^2;
    end
end

for j = 1:data.J
    for t = 1:T
        % 修正后燃料成本：只对锅炉燃料汽 H^FH = Qtu_c 计费
        % C^CHP = a_j*(H^FH)^2 + b_j*H^FH，  H^FH>=0 已由 Qtu_c_min>=0 保证非负
        % （原 P^EQ 五参数写法与线性耦合不自洽且会产生负燃料成本，已弃用）
        obj = obj + data.CHP_a(j) * Qtu_c(j,t)^2 + data.CHP_b(j) * Qtu_c(j,t);
    end
end

for i = 1:data.I
    for t = 1:T
        obj = obj + data.gamma_tu(i)*sum(Q_i2j(i,:,t),2) ...
                  + data.gamma_in(i)*sum(Q_i2k(i,:,t),2) ...
                  + data.gamma_re(i)*Q_i2n(i,t);
    end
end

for s = 1:data.S
    for t = 1:T
        obj = obj + data.gamma_GB_ind(s)*Qs(s,t) + data.gamma_GB_ind_2(s)*Qs(s,t)^2;
    end
end

for w = 1:data.W
    for t = 1:T
        obj = obj + data.gamma_GB_res(w)*Qw(w,t) + data.gamma_GB_res_2(w)*Qw(w,t)^2;
    end
end

% ------------------ 输出 ------------------
model = struct();
model.C = C;
model.obj = obj;

handles = struct();
handles.yL = yL; handles.yM = yM; handles.yH = yH;

handles.E = E; handles.Qch = Qch; handles.Qdis = Qdis; handles.Pes = Pes;
handles.Q_i2j = Q_i2j; handles.Q_i2k = Q_i2k; handles.Q_i2n = Q_i2n;
handles.Ptu = Ptu; handles.Pg = Pg;handles.Pn = Pn;handles.Qtu_r = Qtu_r;handles.Qtu_c = Qtu_c;handles.Pbuy = Pbuy;handles.Psell = Psell;handles.Qtu_dump = Qtu_dump;
handles.Qtu_h = Qtu_h;
handles.Qs = Qs; handles.Qw = Qw;
handles.Q_s2k = Q_s2k;
handles.theta = theta; handles.Pflow = Pflow;

handles.Ts_node = Ts_node;handles.Tr_node = Tr_node;
handles.Ts_sup_from = Ts_sup_from;handles.Ts_sup_to   = Ts_sup_to;
handles.Tr_ret_from = Tr_ret_from;handles.Tr_ret_to   = Tr_ret_to;




handles.con_tu = con_tu;
handles.con_in = con_in;
handles.con_load   = con_load;
handles.load_nodes = load_nodes;  
handles.con_src   = con_src;
handles.src_nodes = src_nodes;
handles.con_elec = con_elec;
end