function tbl = run_degr_sensitivity(xlsxPath)
%RUN_DEGR_SENSITIVITY  放热成本系数取值对调度与定价的影响（论文附录B7 表B8、表B9）
%  论文基准算例（日初储能固定），三品级配置；推导值见论文附录B6 表B7。
if nargin < 1 || isempty(xlsxPath), xlsxPath = 'case_14bus_6heat.xlsx'; end
outDir = 'mat_results';
if ~exist(outDir, 'dir'), mkdir(outDir); end
base = read_config_xlsx(xlsxPath);

%        方案                 发电级  工业级  建筑级
SCH = { '算例采用值',           30,     20,     10;
        '推导值',               27.45,  19.67,  9.62;
        '低值(设计寿命30a)',    22.88,  16.39,  8.01;
        '高值(设计寿命20a)',    34.32,  24.58,  12.02 };
n = size(SCH,1);
[Cost, QP, QI, QB, Gen, Ind, Bld] = deal(zeros(n,1));
for k = 1:n
    d = base;
    d.gamma_tu(:) = SCH{k,2}; d.gamma_in(:) = SCH{k,3}; d.gamma_re(:) = SCH{k,4};
    R = solve_dispatch_milp(d);
    save(fullfile(outDir, sprintf('results_degr_%d.mat', k)), 'R');
    Cost(k) = R.Objective / 1e4;
    QP(k) = sum(R.Q_i2j(:)) * d.dt; QI(k) = sum(R.Q_i2k(:)) * d.dt; QB(k) = sum(R.Q_i2n(:)) * d.dt;
    p = price_means(R); Gen(k) = p.Gen; Ind(k) = p.Ind; Bld(k) = p.Bld;
end
rel = @(x) 100*(x - x(1)) ./ x(1);
tbl = table(string(SCH(:,1)), Cost, rel(Cost), QP, QI, QB, rel(Gen), rel(Ind), rel(Bld), ...
    'VariableNames', {'方案','总运行成本_万元','相对偏差_pct','发电级放热_MWh','工业级放热_MWh', ...
                      '建筑级放热_MWh','发电级热价变化_pct','工业级热价变化_pct','建筑级热价变化_pct'});
disp(tbl);
writetable(tbl, 'results_summary.xlsx', 'Sheet', '附录B7_放热成本系数', 'WriteMode', 'overwritesheet');
end
