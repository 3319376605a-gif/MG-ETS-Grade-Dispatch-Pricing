function st = fig_style()
%FIG_STYLE  四季与全寿命周期图的统一样式：配色取自 plot_section42_figures.m，
%  字体策略同论文其余各图：中文宋体、数字字母 Times New Roman。st.mix 按字符自动插入 \fontname 切换，
%  任何含中文的字符串（坐标轴标签、刻度、图例、分图名）都应先经 st.mix 处理，避免中文显示为方框。
c.charge        = [0.929, 0.490, 0.192];   % 橙：充热 / 换热设备投资
c.discharge_tu  = [0.180, 0.545, 0.549];   % 青：发电级 / 三品级供热
c.discharge_ind = [0.557, 0.267, 0.537];   % 紫：工业级
c.discharge_res = [0.843, 0.522, 0.522];   % 玫瑰：建筑级
c.energy_line   = [0.122, 0.267, 0.537];   % 深蓝：储能量 / 电价
c.band_high     = [0.957, 0.898, 0.898];
c.band_mid      = [0.969, 0.949, 0.910];
c.band_low      = [0.910, 0.945, 0.969];
c.other_gen     = [0.329, 0.431, 0.639];   % 钢蓝：仅建筑级供热 / 加热器与储热体投资
c.renewable     = [0.302, 0.686, 0.290];   % 翠绿：燃料成本节约
c.curt          = [0.929, 0.686, 0.133];   % 金：弃电成本节约
c.gray_bar      = [0.62, 0.62, 0.62];      % 灰：无电蓄热 / 固定运维
c.gray_dark     = [0.35, 0.35, 0.35];
c.zero_line     = [0.50, 0.50, 0.50];
% 7 种品级配置的曲线颜色（取自论文 plot_heat_prices_journal.m 的 lineColors）
c.lines = [0.180 0.545 0.549; 0.557 0.267 0.537; 0.843 0.522 0.522; 0.929 0.490 0.192;
           0.122 0.267 0.537; 0.400 0.706 0.710; 0.550 0.550 0.550];
st.c = c;
st.fsTick = 16;
st.mix = @mix_fn;
st.cn  = @(cells) cellfun(@mix_fn, cells, 'UniformOutput', false);
st.sub = @(k, txt) mix_fn(sprintf('(%c) %s', 'a'+k-1, txt));
st.newfig = @(w, h) figure('Units', 'centimeters', 'Position', [2 2 w h], 'Color', 'w', ...
                           'PaperPositionMode', 'auto');
st.axfmt  = @(ax) set(ax, 'FontName', 'Times New Roman', 'FontSize', st.fsTick, 'TickDir', 'in', ...
                      'Box', 'on', 'LineWidth', 0.8, 'XColor', 'k', 'TickLabelInterpreter', 'tex');
st.legend = @legend_fn;
st.save   = @save_fn;
end

function s = mix_fn(s)
% 中文字符段用宋体，其余（数字、字母、半角符号）用 Times New Roman
s = char(s);
if isempty(s), return; end
isCN = s >= 11904;                      % U+2E80 起：中日韩文字及全角符号
out = ''; cur = -1;
for k = 1:numel(s)
    if isCN(k) ~= cur
        if isCN(k), out = [out, '\fontname{宋体}']; else, out = [out, '\fontname{Times New Roman}']; end %#ok<AGROW>
        cur = isCN(k);
    end
    out = [out, s(k)]; %#ok<AGROW>
end
s = out;
end

function legend_fn(ax, entries, pos, nCol)
lgd = legend(ax, cellfun(@mix_fn, entries, 'UniformOutput', false), 'Orientation', 'horizontal', ...
             'NumColumns', nCol, 'FontSize', 16, 'Box', 'off', 'Interpreter', 'tex');
lgd.ItemTokenSize = [14, 8];
if ~isempty(pos), set(lgd, 'Units', 'normalized', 'Position', pos); end
end

function save_fn(fig, outDir, name)
exportgraphics(fig, fullfile(outDir, [name '.png']), 'Resolution', 600);
exportgraphics(fig, fullfile(outDir, [name '.pdf']), 'ContentType', 'vector');
saveas(fig, fullfile(outDir, [name '.fig']));
fprintf('已保存: %s\n', name);
end
