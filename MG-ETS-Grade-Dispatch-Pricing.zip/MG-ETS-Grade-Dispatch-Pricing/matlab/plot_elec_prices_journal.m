function plot_elec_prices_journal(resultsPath, outDir, plotType)
%PLOT_ELEC_PRICES_JOURNAL  科研论文级节点边际电价图
%
% 现在支持：
%   - plotType = 'lines'   只画曲线图
%   - plotType = 'heatmap' 只画热力图
%   - plotType = 'both'    同时画两张图（默认）
%
% 输入参数：
%   resultsPath - results.mat 路径（默认当前目录）
%   outDir      - 输出目录（默认 'figs'）
%   plotType    - 'lines' / 'heatmap' / 'both'（默认 'both'）

%% ==================== 参数初始化 ====================
if nargin < 1 || isempty(resultsPath), resultsPath = fullfile('mat_results','results.mat'); end
if nargin < 2 || isempty(outDir),      outDir      = 'figs';        end
if nargin < 3 || isempty(plotType),    plotType    = 'both';        end

%% ==================== 加载数据 ====================
S = load(resultsPath);
assert(isfield(S,'results'), 'results.mat 中未找到变量 results');
R = S.results;

assert(isfield(R,'ElecPrices'), 'results 中未找到 ElecPrices');
pi_bus = R.ElecPrices.pi_bus;  % N_bus × T

[N_bus, T] = size(pi_bus);
t = 1:T;

%% ==================== 输出目录 ====================
if ~exist(outDir,'dir'), mkdir(outDir); end

%% ==================== 科研绘图全局设置 ====================
set(groot, 'defaultFigureColor', 'w');
set(groot, 'defaultAxesBox', 'on');
set(groot, 'defaultAxesTickDir', 'out');

%% ==================== 配色方案 ====================
% 节点颜色（14种不同颜色）
nodeColors = [
    0.122, 0.267, 0.537;   % 深蓝
    0.929, 0.490, 0.192;   % 橙色
    0.180, 0.545, 0.549;   % 青色
    0.557, 0.267, 0.537;   % 紫色
    0.843, 0.522, 0.522;   % 玫瑰
    0.400, 0.706, 0.710;   % 浅青
    0.737, 0.478, 0.690;   % 浅紫
    0.200, 0.400, 0.600;   % 蓝灰
    0.850, 0.370, 0.370;   % 红
    0.350, 0.550, 0.350;   % 绿
    0.550, 0.550, 0.350;   % 橄榄
    0.750, 0.550, 0.350;   % 棕
    0.450, 0.350, 0.550;   % 靛
    0.350, 0.450, 0.550;   % 石板蓝
];

%% ==================== 字体配置（放大） ====================
fontConfig = struct();
fontConfig.family     = '宋体';
fontConfig.sizeAxis   = 18;        % 放大
fontConfig.sizeTitle  = 18;        % 放大
fontConfig.sizeLegend = 14;        % 放大
fontConfig.sizeTick   = 16;        % 放大

%% ==================== 根据类型绘图 ====================
plotType = lower(string(plotType));

switch plotType
    case "lines"
        plot_lines(pi_bus, t, N_bus, T, nodeColors, fontConfig, outDir);
    case "heatmap"
        plot_heatmap(pi_bus, N_bus, T, fontConfig, outDir);
    case "both"
        % 同时画两张图（拆成两个 figure）
        plot_lines(pi_bus, t, N_bus, T, nodeColors, fontConfig, outDir);
        plot_heatmap(pi_bus, N_bus, T, fontConfig, outDir);
    otherwise
        error("plotType 只能是 'lines' / 'heatmap' / 'both'。当前为: %s", plotType);
end

end

%% ==================== 曲线图函数 ====================
function plot_lines(pi_bus, t, N_bus, T, nodeColors, fontConfig, outDir)

fig = figure('Units', 'pixels', ...
             'Position', [100, 100, 700, 500], ...
             'Color', 'w', ...
             'Renderer', 'painters');

ax = axes(fig, 'Units', 'normalized', ...
               'Position', [0.12, 0.15, 0.65, 0.75]);
hold(ax, 'on');

% 绘制各节点曲线
h = gobjects(N_bus, 1);
labels = cell(N_bus, 1);

for i = 1:N_bus
    colorIdx = mod(i-1, size(nodeColors,1)) + 1;
    h(i) = plot(ax, t, pi_bus(i,:), '-o', ...
                'Color', nodeColors(colorIdx,:), ...
                'LineWidth', 1.8, ...
                'MarkerSize', 4, ...
                'MarkerFaceColor', 'w', ...
                'MarkerEdgeColor', nodeColors(colorIdx,:));
    labels{i} = sprintf('\\fontname{宋体}节点 \\fontname{Times New Roman}%d', i);
end

% 绘制系统均价（虚线）
mean_price = mean(pi_bus, 1);
h_mean = plot(ax, t, mean_price, '--', ...
              'Color', [0.35, 0.35, 0.35], ...
              'LineWidth', 2.0);

% 坐标轴设置 - X轴范围改为 [0, T]
ax.XLim = [0, T+0.5];
ax.YLim = [0, max(pi_bus(:)) * 1.08];

xlabel(ax, '\fontname{宋体}时刻', 'FontSize', fontConfig.sizeAxis);
ylabel(ax, '\fontname{宋体}节点边际电价/(\fontname{Times New Roman}¥/MWh)', ...
       'FontSize', fontConfig.sizeAxis);

% 刻度（数字用 Times New Roman）
ax.XTick = [0, 4, 8, 12, 16, 20, 24];
ax.XTickLabel = {'0:00','4:00','8:00','12:00','16:00','20:00','24:00'};
ax.FontName = 'Times New Roman';
ax.FontSize = fontConfig.sizeTick;
ax.TickDir = 'in';
ax.Box = 'on';
ax.LineWidth = 0.8;

% 图例（中文宋体，数字新罗马）
lg = legend(ax, [h; h_mean], [labels; {'\fontname{宋体}系统均价'}], ...
            'Location', 'eastoutside', ...
            'FontSize', fontConfig.sizeLegend, ...
            'FontName', '宋体');
lg.Box = 'off';

hold(ax, 'off');

% 导出
baseName = fullfile(outDir, 'LMP_ElecPrices_Lines');
exportgraphics(fig, [baseName, '.png'], 'Resolution', 600);
exportgraphics(fig, [baseName, '.pdf'], 'ContentType', 'vector');
fprintf('已保存: %s.png / .pdf\n', baseName);

end

%% ==================== 热力图函数 ====================
function plot_heatmap(pi_bus, N_bus, T, fontConfig, outDir)

fig = figure('Units', 'pixels', ...
             'Position', [100, 100, 700, 500], ...
             'Color', 'w', ...
             'Renderer', 'painters');

ax = axes(fig, 'Units', 'normalized', ...
               'Position', [0.12, 0.15, 0.68, 0.75]);

% 绘制热力图
imagesc(ax, 1:T, 1:N_bus, pi_bus);
ax.YDir = 'reverse';

% 自定义colormap：蓝->青->黄->橙->红
colors_cmap = [
    0.910, 0.945, 0.969;   % 淡蓝（低价）
    0.180, 0.545, 0.549;   % 青色
    0.969, 0.949, 0.910;   % 淡黄（中价）
    0.929, 0.490, 0.192;   % 橙色
    0.843, 0.302, 0.302;   % 深红（高价）
];
n = 256;
cmap = interp1(linspace(0,1,size(colors_cmap,1)), colors_cmap, linspace(0,1,n));
colormap(ax, cmap);

% Colorbar
cb = colorbar(ax, 'Position', [0.82, 0.15, 0.03, 0.75]);
cb.Label.String = '\fontname{宋体}电价/(\fontname{Times New Roman}¥/MWh)';
cb.Label.FontSize = fontConfig.sizeAxis;
cb.FontSize = fontConfig.sizeTick;
cb.FontName = 'Times New Roman';

% 坐标轴设置
xlabel(ax, '\fontname{宋体}时刻', 'FontSize', fontConfig.sizeAxis);
ylabel(ax, '\fontname{宋体}节点', 'FontSize', fontConfig.sizeAxis);

% 刻度（数字用 Times New Roman）
ax.XTick = [0, 4, 8, 12, 16, 20, 24];
ax.XTickLabel = {'0:00','4:00','8:00','12:00','16:00','20:00','24:00'};
ax.XLim = [0.5, T + 0.5];
ax.YTick = 1:N_bus;
ax.FontName = 'Times New Roman';
ax.FontSize = fontConfig.sizeTick;
ax.TickDir = 'in';
ax.Box = 'on';
ax.LineWidth = 0.8;

% 导出
baseName = fullfile(outDir, 'LMP_ElecPrices_Heatmap');
exportgraphics(fig, [baseName, '.png'], 'Resolution', 600);
exportgraphics(fig, [baseName, '.pdf'], 'ContentType', 'vector');
fprintf('已保存: %s.png / .pdf\n', baseName);

end