function [T1, T2] = run_param_sensitivity(xlsxPath)
%RUN_PARAM_SENSITIVITY  关键参数敏感性分析（论文附录C 表C1、表C2）
%  论文基准日（日初储能固定，计入弃电成本），三品级配置，每次只改变一个参数：
%    储热容量     cap  : Emax、Emin、EL、EH、E0 同比例缩放（同一显热映射）
%    储热充电功率 pow  : 两台电蓄热输入电功率上限 Pes_max 缩放
%    能量区阈值   thr  : EL、EH 同时平移（MWh）
%    燃料成本     fuel : 常规机组、CHP燃煤锅炉、工业及居民锅炉的一次、二次成本系数同比例缩放
%    新能源出力   ren  : 风电、光伏可用出力缩放
%    单位弃电成本 curt : c_curt 取值（元/MWh）
%    Big-M        bigm : M 取值（求解条件说明，不列入表C1）
%  结果逐个保存为 mat_results/sens/<工况>.mat，已存在的工况自动跳过（可断点续跑）。
if nargin < 1 || isempty(xlsxPath), xlsxPath = 'case_14bus_6heat.xlsx'; end
outDir = fullfile('mat_results', 'sens');
if ~exist(outDir, 'dir'), mkdir(outDir); end
base = read_config_xlsx(xlsxPath);

%      名称                  类型    取值
C = { '基准',                'base', 1;
      '储热容量×0.6',        'cap',  0.6;  '储热容量×0.8',     'cap',  0.8;
      '储热容量×1.2',        'cap',  1.2;  '储热容量×1.4',     'cap',  1.4;
      '储热充电功率×0.6',    'pow',  0.6;  '储热充电功率×0.8', 'pow',  0.8;
      '储热充电功率×1.2',    'pow',  1.2;  '储热充电功率×1.4', 'pow',  1.4;
      '能量区阈值−20 MWh',   'thr',  -20;  '能量区阈值＋20 MWh', 'thr', 20;
      '燃料成本×0.8',        'fuel', 0.8;  '燃料成本×0.9',     'fuel', 0.9;
      '燃料成本×1.1',        'fuel', 1.1;  '燃料成本×1.2',     'fuel', 1.2;
      '新能源出力×0.8',      'ren',  0.8;  '新能源出力×0.9',   'ren',  0.9;
      '新能源出力×1.1',      'ren',  1.1;  '新能源出力×1.2',   'ren',  1.2;
      '单位弃电成本0',       'curt', 0;    '单位弃电成本200',  'curt', 200;
      '单位弃电成本500',     'curt', 500;
      'Big-M=450',           'bigm', 450 };
n = size(C, 1);
[Cost, Curt, QP, QI, QB, Gen, Ind, Bld, Elec, Ladder] = deal(zeros(n, 1));
for k = 1:n
    f = fullfile(outDir, sprintf('%s_%g.mat', C{k,2}, C{k,3}));
    if exist(f, 'file')
        load(f, 'R', 'd');
    else
        d = sens_case(base, C{k,2}, C{k,3});
        t0 = tic;
        R = solve_dispatch_milp(d);
        fprintf('[%-18s] 总运行成本 = %.2f 万元，用时 %.0f s\n', C{k,1}, R.Objective/1e4, toc(t0));
        save(f, 'R', 'd');
    end
    Cost(k) = R.Objective / 1e4;
    Curt(k) = sum(d.Gen_New_P(:)) - sum(R.Pn(:));
    QP(k) = sum(R.Q_i2j(:)) * d.dt; QI(k) = sum(R.Q_i2k(:)) * d.dt; QB(k) = sum(R.Q_i2n(:)) * d.dt;
    p = price_means(R);
    Gen(k) = p.Gen; Ind(k) = p.Ind; Bld(k) = p.Bld; Elec(k) = p.Elec;
    % 逐时热价梯级关系“发电级≥工业级≥建筑级”成立的时段数
    HP = R.HeatPrices;
    pt = mean(HP.pi_tu, 1); pin = mean(HP.pi_in, 1); pb = mean(HP.pi_node(unique(d.nM), :), 1);
    Ladder(k) = sum(pt >= pin - 1e-6 & pin >= pb - 1e-6);
end
dCost = 100 * (Cost / Cost(1) - 1);
names = string(C(:,1));
T1 = table(names, Cost, dCost, Curt, QP, QI, QB, Ladder, 'VariableNames', ...
    {'工况','总运行成本_万元','变化率_pct','弃电量_MWh','发电级放热_MWh','工业级放热_MWh','建筑级放热_MWh','梯级成立时段数'});
T2 = table(names, Gen, Ind, Bld, Elec, 'VariableNames', ...
    {'工况','发电级热价','工业级热价','建筑级热价','节点电价'});
disp(T1); disp(T2);
writetable(T1, 'results_summary.xlsx', 'Sheet', '附录C_表C1', 'WriteMode', 'overwritesheet');
writetable(T2, 'results_summary.xlsx', 'Sheet', '附录C_表C2', 'WriteMode', 'overwritesheet');
end

function d = sens_case(base, kind, v)
d = base;
switch kind
    case 'base'
    case 'cap'
        for f = {'Emax','Emin','EL','EH','E0'}, d.(f{1}) = d.(f{1}) * v; end
    case 'pow'
        d.Pes_max = d.Pes_max * v;
    case 'thr'
        d.EL = d.EL + v; d.EH = d.EH + v;
    case 'fuel'
        for f = {'a_g','a2_g','CHP_b','CHP_a','gamma_GB_ind','gamma_GB_ind_2','gamma_GB_res','gamma_GB_res_2'}
            d.(f{1}) = d.(f{1}) * v;
        end
    case 'ren'
        d.Gen_New_P = d.Gen_New_P * v;
    case 'curt'
        d.c_curt = v;
    case 'bigm'
        d.BigM = v;
    otherwise
        error('未知工况类型：%s', kind);
end
end
