function d = season_data(base, season)
%SEASON_DATA  由论文算例(冬季典型日)构造指定季节的典型日数据
%  d = season_data(base, 'spring' | 'summer' | 'autumn' | 'winter')
S = season_table();
k = find(strcmp({S.name}, season));
if isempty(k), error('未知季节：%s', season); end
s = S(k);
d = base;
d.Gen_New_P(1,:) = d.Gen_New_P(1,:) * s.wind;   % 第1台新能源为风电
d.Gen_New_P(2,:) = d.Gen_New_P(2,:) * s.pv;     % 第2台新能源为光伏
d.Pd        = d.Pd        * s.elec;
d.Qre_dem_m = d.Qre_dem_m * s.res;
d.Qin_dem   = d.Qin_dem   * s.ind;
if s.res < 1
    % 非供暖季居民热水锅炉不再强制运行
    d.Qw_min = zeros(size(d.Qw_min));
end
end
