function d = scenario_capacity_reuse(d, opt)
%SCENARIO_CAPACITY_REUSE  "新能源大发 + 建筑负荷高 + 发电/工业级需求低谷" 容量复用场景
%
%  目的：制造一个让"机械分区(专用化)"吃亏、"共享池(容量复用)"占优的【可行】场景。
%  机理 —— 品级需求错配：
%     · 风光大发(windScale)：制造富余风电，使储能充电便宜、值得多用；
%     · 建筑(居民)负荷抬高(resScale)：超过单台分区子器件(L,容量仅1/3)的供热能力，
%       逼出"建筑级容量短缺"；
%     · 发电/工业级需求压低(indScale + 高风光使汽轮机退出 -> 发电级再热需求趋零)：
%       使分区里高/中品级两台蓄热体闲置浪费，而共享池可把这部分容量【下沉复用】于建筑级。
%  此时分区只有1/3容量可供建筑、其余闲置；共享池可把整池容量下沉，故占优。
%
%  ★ 可行性保护：工业负荷【不置零】(置零会与工业锅炉最小出力 Qmin 冲突而不可行)，
%    仅按 indScale 压低，并自动抬升到工业锅炉最小出力之上。
%
%  opt 字段(均可缺省):
%     windScale (默认 1.5)  风光可用出力倍数
%     resScale  (默认 2.0)  居民(建筑级)负荷倍数
%     indScale  (默认 0.4)  工业(中品级)负荷倍数(压低，腾出中品级容量)

if nargin < 2, opt = struct; end
windScale = 1.5;  resScale = 2.0;  indScale = 0.4;
if isfield(opt,'windScale'), windScale = opt.windScale; end
if isfield(opt,'resScale'),  resScale  = opt.resScale;  end
if isfield(opt,'indScale'),  indScale  = opt.indScale;  end

% --- 风光大发 ---
d.Gen_New_P = d.Gen_New_P * windScale;

% --- 建筑级负荷抬高(热网余量充足，可大胆抬) ---
d.Qre_dem_m = d.Qre_dem_m * resScale;

% --- 工业级负荷压低，但自动抬到工业锅炉最小出力之上，保证可行 ---
d.Qin_dem = d.Qin_dem * indScale;
qmin = 1.1 * sum(d.Qs_min);                 % 工业锅炉最小出力总和(留10%裕度)
colsum = sum(d.Qin_dem, 1);                 % 各时段工业级总需求
bad = colsum < qmin;
if any(bad)
    up = ones(1, numel(colsum));
    up(bad) = qmin ./ max(colsum(bad), eps);
    d.Qin_dem = d.Qin_dem .* up;            % 按列抬升，避开 Qmin 不可行
    fprintf('[scenario] 工业负荷过低，已自动抬升 %d 个时段至锅炉最小出力之上(%.1f)。\n', ...
            nnz(bad), qmin);
end
end
